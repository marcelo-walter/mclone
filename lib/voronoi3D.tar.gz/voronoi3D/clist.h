
#ifndef _clist_h_

#define _clist_h_

#include "globals.h"

#define CLIST_NullNode  (NULL)

#define _CLIST_HeadTag GLBL_Tag('c', 'l', 's', 'S')
#define _CLIST_TailTag GLBL_Tag('c', 'l', 's', 'E')

typedef struct _CLIST_AListEntry {
#ifdef paranoid
  UInt32                   headGuard;
#endif
  struct _CLIST_AListEntry *previous;
  struct _CLIST_AListEntry *next;
  Ptr                      dataPtr;
#ifdef paranoid
  UInt32                   tailGuard;
#endif
  } _CLIST_NodeInfoType;

typedef _CLIST_NodeInfoType *CLIST_NodeType;

#ifdef __cplusplus
extern "C" {
#endif

CLIST_NodeType CLIST_NewNode (Ptr userDataPtr);
void           CLIST_FreeNode (CLIST_NodeType theNode);

CLIST_NodeType CLIST_Previous (CLIST_NodeType theNode);
CLIST_NodeType CLIST_Next (CLIST_NodeType theNode);

Ptr CLIST_GetData (CLIST_NodeType theNode);

Boolean CLIST_MergeCycles (CLIST_NodeType node1, CLIST_NodeType node2);
Boolean CLIST_BreakCycles (CLIST_NodeType node1, CLIST_NodeType node2);
Boolean CLIST_AddAfter(CLIST_NodeType nodeToAdd, CLIST_NodeType referenceNode);

Boolean CLIST_DetachFromCycle (CLIST_NodeType theNode);

Boolean CLIST_Audit (CLIST_NodeType theNode);

#ifdef __cplusplus
}
#endif

#endif

