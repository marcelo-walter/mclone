
#ifndef _sweepAlarms_h_
#define _sweepAlarms_h_

#include "subsystems.h"
#include "alarm.h"

#define SWP_BaseAlarm      AL_BaseAlarm(SYS_VoronoiSweep)
#define SWP_BaseFunction   AL_BaseAlarm(SYS_VoronoiSweep)

#define AL_Id_SWP_NoUserRoutine        (SWP_BaseAlarm + 0x01)
#define AL_Id_SWP_NoInfrastructure     (SWP_BaseAlarm + 0x02)
#define AL_Id_SWP_BadParameters        (SWP_BaseAlarm + 0x03)
#define AL_Id_SWP_NoDataInArc          (SWP_BaseAlarm + 0x04)
#define AL_Id_SWP_NullEvent            (SWP_BaseAlarm + 0x05)

#define AL_Fn_SWP_FindVorVertices      (SWP_BaseFunction + 0x01)
#define AL_Fn_SWP_CloseArcForSite      (SWP_BaseFunction + 0x02)
#define AL_Fn_SWP_SiteEvent            (SWP_BaseFunction + 0x03)
#define AL_Fn_SWP_CircleEvent          (SWP_BaseFunction + 0x04)

#endif

