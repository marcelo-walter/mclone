
/******************************************************************
; Module:  Sweep 
;
; description:
;   This module implements Fortune's plane sweep algorithm to find
;   the Voronoi vertices of a set of sites.  The sites must be 
;   disjoint convex polygons (this includes point sites and line 
;   segments as sites).
;
; history:
;   95.03.01 / M. McAllister / Created
;   95.03.18 / M. McAllister / CleanUpSweepFront, CircleEvents
;   95.05.07 / M. McAllister / CompareEvents
;   95.05.08 / M. McAllister / StartSweepFront
;   95.05.18 / M. McAllister / CompareSpokeAngles, CircleEvents,
;   95.10.10 / M. McAllister / CloseArcForSite
;   96.03.04 / M. McAllister / Added CheckSanity as a temoorary measure
;   96.09.04 / M. McAllister / CloseArcForSite
;   96.12.13 / M. McAllister / CleanUpSweepFront, InfiniteVoronoiCell
;   97.01.28 / M. McAllister / Removed RDS events and drawing abilities
;                              for a Facet-specific implementation.
;                              Removed CheckSanity, CompareSpokeAngles,
;                              HigherSite, MergeEvent since not used.
;   97.05.05 / M. McAllister / CompareEvents, SWP_FindVoronoiVertices
*******************************************************************/

#include <stdlib.h>

#include "globals.h"
#include "alarm.h"
#include "clist.h"
#include "distance.h"
#include "heap.h"
#include "front.h"
#include "polygon.h"
#include "schedule.h"
#include "sweepAlarms.h"
#include "sweepDefs.h"
#include "sweep.h"
#include "rbtree.h"

/*****************************************************************
; Forward declaration of all local routines.
******************************************************************/

static SInt16 CompareEvents (Ptr arg1, Ptr arg2);

static Boolean StartSweepFront (FRONT_FrontType theFront, 
                 UInt16 howManySites, Pgon **siteArray, 
                 HEAP_Heap siteSchedule, HEAP_Heap circleSchedule,
                 Real *sweepStartXValue);

static Boolean CloseArcForSite (FRONT_FrontType theFront, 
                 FRONT_ArcType theArc, HEAP_Heap circleEvents,
                 SWP_UserRoutinesType *configRtns, 
                 Boolean vtxRefOkay, Ptr voronoiVtxRef);

static Boolean InfiniteVoronoiCell (FRONT_ArcType theArc, Ptr contextPtr);

static Boolean CleanUpSweepFront (FRONT_FrontType theFront, 
                   HEAP_Heap circleEvents, HEAP_Heap mergeEvents, 
                   SWP_UserRoutinesType *rtnPtr);

static Boolean SiteEvent (FRONT_FrontType theFront, HEAP_Heap circleEvents, 
                          HEAP_Heap mergeEvents, scheduleInfo *theEvent, 
                          SWP_UserRoutinesType *rtnPtr);

static Boolean CircleEvent (FRONT_FrontType theFront, HEAP_Heap circleEvents, 
             HEAP_Heap mergeEvents, scheduleInfo *theEvent, 
             SWP_UserRoutinesType *rtnPtr);

#if 0
#define ShowFront 1
#endif

#ifdef ShowFront
static Boolean 
showListOfVorVertices (FRONT_ArcType theArc, Ptr contextPtr)
{
  _SWP_SiteOrderType  *orderInfo;
  CLIST_NodeType      run;

  orderInfo = (_SWP_SiteOrderType *) FRONT_GetData (theArc);

  printf ("Arc for %4.1f %4.1f (top %d, bottom %d) (me %x, prev %x, next %x): ",
             XVal(orderInfo->generator->points[0]),
             YVal(orderInfo->generator->points[0]),
             CLIST_GetData(orderInfo->top), CLIST_GetData(orderInfo->bottom),
             (UInt32) theArc, (UInt32) theArc->prevArc, 
             (UInt32) theArc->nextArc);
  run = CLIST_Next(orderInfo->reference);
  while (run != orderInfo->reference) {
    printf ("%d ", CLIST_GetData (run));
    run = CLIST_Next(run);
  }
  printf ("\n");

  return True;
}
#endif

/*****************************************************************
; Begin with the actual routines now.
******************************************************************/

/******************************************************************
; routine:  SWP_FindVoronoiVertices
;
; description:
;   Locate the Voronoi vertices for a set of convex disjoint
;   polygonal sites.
;
;   As the entire set of Voronoi vertices around a site are discovered,
;   the sweep algorithm invokes a user-supplied callback routine
;   once for each vertex around the site to relay the information out
;   of the sweep routine.
;
; in:
;   numSites : UInt16 -- the number of sites in the site array.
;   siteArray : Pgon ** -- an array of pointers to polygons that are
;                         the sites for the sweep algorithm
;   routinePtr : SWP_UserRoutinesType * -- a structure of callback
;                        routines.  The callback routines are the
;                        mechanism for returning lists of Voronoi
;                        vertices and for animating the algorithm.
;
; out:
;   returns : Boolean -- False if an error occurred while computing
;                        the set of Voronoi vertices.  In such a case,
;                        the caller should not trust any data that was
;                        communicated via the callback routines.
;
; history:
;   95.03.01 / M. McAllister / Created
;   97.05.05 / M. McAllister / Changed interface to HEAP_Allocate
*******************************************************************/

Boolean
SWP_FindVoronoiVertices(
  UInt16               numSites, 
  Pgon                 **siteArray,
  SWP_UserRoutinesType *routinePtr)
{
  HEAP_Heap             siteSchedule = HEAP_NullHeap;
  HEAP_Heap             circleSchedule = HEAP_NullHeap;
  FRONT_FrontType       sweepFront = FRONT_NullFront;
  Boolean               sweepSucceeded = False;
  Real                  sweepLocation;
  Real                  nextLocation;
  FRONT_UserRoutineType frontRoutines;
  scheduleInfo          *siteEvent, *circleEvent;
  Boolean               eventRetrieved;

  /* Don't do anything if the user hasn't supplied any routines. */

  if (routinePtr == NULL) {
    AL_SoftwareAlarm (AL_Id_SWP_NoUserRoutine, AL_Fn_SWP_FindVorVertices, 
                      0, 0, 0, 0);
  } else {

	/* Initialize all the memory structures that the sweep algorithm uses.  */

	if (startSchedule(numSites) == False) {
      AL_SoftwareAlarm (AL_Id_SWP_NoInfrastructure, AL_Fn_NullFunction,
                        (UInt32) numSites, 0, 0, 0);
    } else {
	
	  siteSchedule = HEAP_Allocate (numSites, CompareEvents, "sites");
	  circleSchedule = HEAP_Allocate (2*numSites, CompareEvents, "circles");

	  /* Two of the user callback routines belong to the sweep front and
		 must be passed in via a special data structure. */

	  frontRoutines.spokeSearchRtn = routinePtr->spokeSearchRtn;
	  frontRoutines.vorVtxSearchRtn = routinePtr->vorVtxSearchRtn;
	  if ((FRONT_Create (&frontRoutines, &sweepFront) == True) && 
		  (siteSchedule != HEAP_NullHeap) && (circleSchedule != HEAP_NullHeap)){

		/* All the requisite data structures are set for the sweep
		   algorithm.  Fill in the sweep front and then start the
		   plane sweep. */

		if (StartSweepFront(sweepFront, numSites, siteArray,
					  siteSchedule, circleSchedule, &sweepLocation) == True) {

		  sweepSucceeded = True;
		  eventRetrieved  = HEAP_PeekTop (siteSchedule, (Ptr *)(&siteEvent));
		  eventRetrieved |= HEAP_PeekTop (circleSchedule, (Ptr *)(&circleEvent));
		  if ((routinePtr != NULL) && (routinePtr->sweepRtn != NULL)) {
			(*(routinePtr->sweepRtn))(sweepFront, (Real) sweepLocation - 10.0, 
                                      sweepLocation);
		  }

		  while (eventRetrieved && sweepSucceeded) {
#ifdef ShowFront
printf ("\n");
FRONT_Traverse (sweepFront, showListOfVorVertices, NULL);
printf ("Circle heap size is %d\n", HEAP_Size (circleSchedule));
#endif
			if ((siteEvent != NULL) && ((circleEvent == NULL) || (
				!Greater(XVal(siteEvent->eventPt), 
                         XVal(circleEvent->eventPt))))) {
			  /* The site event gets done first. */

			  nextLocation = XVal(siteEvent->eventPt);

              if (siteEvent->whatEvent == EVT_SiteEvent) {
                sweepSucceeded = FRONT_Advance (sweepFront, nextLocation);
			    sweepSucceeded &= HEAP_PopTop(siteSchedule,(Ptr *)(&siteEvent));
			    sweepSucceeded &= SiteEvent (sweepFront, circleSchedule,
										     siteSchedule, siteEvent, 
                                             routinePtr);
              } else {
                /* We're actually merging two sites together.  Get rid
                   of one front arc. */
                sweepSucceeded = FRONT_Advance (sweepFront, nextLocation);
			    sweepSucceeded &= HEAP_PopTop(siteSchedule,(Ptr *)(&siteEvent));
				/* Ignore the actual event.  */
              }
			} else {
			  /* Do the circle event. */

			  nextLocation = XVal(circleEvent->eventPt);

              sweepSucceeded = FRONT_Advance (sweepFront, nextLocation);
			  sweepSucceeded &= HEAP_PopTop (circleSchedule, 
                                             (Ptr *)(&circleEvent));
			  sweepSucceeded &= CircleEvent (sweepFront, circleSchedule,
											 siteSchedule, circleEvent, 
                                             routinePtr);
			}

			/* Let the user know that the sweep is moving forward. */

			if ((routinePtr != NULL) && (routinePtr->sweepRtn != NULL)) {
			  (*(routinePtr->sweepRtn))(sweepFront, sweepLocation,nextLocation);
			}

			sweepLocation = nextLocation;
			eventRetrieved  = HEAP_PeekTop (siteSchedule, (Ptr *)(&siteEvent));
			eventRetrieved |= HEAP_PeekTop (circleSchedule, (Ptr *)(&circleEvent));
		  } 
#ifdef ShowFront
printf ("\n");
FRONT_Traverse (sweepFront, showListOfVorVertices, NULL);
#endif

		  if (sweepSucceeded == True) {

#ifdef Hack
            {
              /* Admit the possibility that an arc may still appear
                 more than once in the sweep front, but the multiple
                 occurences had better be between colinear points. */

              RBTREE_NodeType  node, pred, succ;
              FRONT_ArcType    nodeInfo, predInfo, succInfo;
              Line             aLine;

              pred = RBTREE_Next(sweepFront->balancedTree, NULL);
              predInfo = (FRONT_ArcType) RBTREE_GetData(pred);
              node = RBTREE_Next(sweepFront->balancedTree, pred);
              nodeInfo = (FRONT_ArcType) RBTREE_GetData(node);
              while (node != RBTREE_NullNode) {
                succ = RBTREE_Next(sweepFront->balancedTree, node);
                succInfo = (FRONT_ArcType) RBTREE_GetData(succ);

                if (succ != RBTREE_NullNode) {
                  if ((nodeInfo->prevArc != NULL) || 
                      (nodeInfo->nextArc != NULL)) {
                    /* This guy is in here too often.  See if we're
                       allowed to knock him out. */
                    LineOf (&(predInfo->generator->points[0]), 
                            &(succInfo->generator->points[0]), &aLine);
                    if (OnTheLine(&aLine, 
                            &(nodeInfo->generator->points[0])) == True) {
                      /* Let's bump him off. */
#ifdef verbose
printf ("Eliminating a redundant arc in the sweep for %f %f.\n",
nodeInfo->generator->points[0].x, nodeInfo->generator->points[0].y);
#endif
                    CloseArcForSite (sweepFront, nodeInfo, circleSchedule, 
                                     routinePtr, False, NULL);
                    FRONT_RemoveArc (sweepFront, nodeInfo,
                                      circleSchedule, siteSchedule, True);
                    } else {
                      pred = node;  predInfo = nodeInfo;
                    }
                  }
                }

                node = succ;  nodeInfo = succInfo;
              }
            }
#endif
			/* No more events exist so the remaining front arcs are the
			   infinite Voronoi cells (i.e. sites on the convex hull).
			   Take care of those front arcs before we leave. */

			sweepSucceeded = CleanUpSweepFront(sweepFront, circleSchedule, 
											   siteSchedule, routinePtr);
		  }
		}
	  }
	}

	/* Time to free all allocated resources, whether the sweep algorithm
	   ran to completion or it aborted for some reason. */

	if (sweepFront != FRONT_NullFront) {
	  FRONT_Free (sweepFront);
	}
    endSchedule();
	if (siteSchedule != HEAP_NullHeap) {
	  HEAP_Free (siteSchedule);
	}
	if (circleSchedule != HEAP_NullHeap) {
	  HEAP_Free (circleSchedule);
	}
  }

  return sweepSucceeded;
}

/******************************************************************
; routine:  CompareEvents
;
; description:
;   Determines the order of two sweep events.  The routine assumes
;   that the two events are of the same type (eithe both site
;   events or both circle events).
;
;   The order is according to the criteria
;     - increasing x-coordinate
;     - decreasing y-coordinate
;     - for circle events only, the angle of the slope of a spoke
;       associated with the event.  Site events will not reach
;       this case since the sites are assumed to be disjoint;
;       either the x-coordinate or y-coordinate above will distinguish
;       them from one another.
;
;   The routine returns a value of 
;     -1 if arc1 is ``before'' arc2
;      0 if the two arcs are indistinguishable
;      1 if arc2 is before arc1
;
; in:
;   arg1 : Ptr -- The first sweep front arc to compare.  The true
;                 type of the argument is FRONT_ArcType.
;   arg2 : Ptr -- The second sweep front arc to compare.  The true
;                 type of the argument is FRONT_ArcType.
;
; out:
;   returns : SInt16 -- A value of -1, 0, or 1 as in the description above.
;
; interface note:
;   The interface to the function must conform with the comparison
;   routine needed dictated by FRONT_Create.
;
; history:
;   95.03.01 / M. McAllister / Created
;   95.05.07 / M. McAllister / Was comparing XVals when YVals
;                              determined the difference.
;   97.05.02 / M. McAllister / Added a context pointer for the heap.
;                              This routine doesn't make use of it.
*******************************************************************/

static SInt16 
CompareEvents (Ptr arg1, Ptr arg2)
{
  SInt16  compareResult;
  Pt      *pt1, *pt2;
  Vector  v1, v2;
  Real    theLength;

  if (arg1 == arg2) {
    compareResult = 0;
  } else if (arg1 == NULL) {
    compareResult = 1;
  } else if (arg2 == NULL) {
    compareResult = -1;
  } else {

    /* Most events will occur at different physical points in the
       plane so comparing their x-coordinates or y-coordinates will
       be sufficient to order them. */

    pt1 = &(((scheduleInfo *)arg1)->eventPt);
    pt2 = &(((scheduleInfo *)arg2)->eventPt);

    if (!(Equal(XVal(*pt1), XVal(*pt2)))) {
      compareResult = Sign(XVal(*pt1) - XVal(*pt2));
    } else if (!(Equal(YVal(*pt1), YVal(*pt2)))) {
      compareResult = Sign(YVal(*pt2) - YVal(*pt1));
    } else {

	  if ((((scheduleInfo *)arg1)->whatEvent == EVT_SiteEvent) ||
		  (((scheduleInfo *)arg2)->whatEvent == EVT_SiteEvent)) {
		  /* We want the site event to be first. */ 
		  if (((scheduleInfo *)arg1)->whatEvent == EVT_SiteEvent) {
			compareResult = -1;
		  } else {
			compareResult = 1;
		  }
	  } else {

		/* Only circle events should make it this far.  We now
		   compare slopes of the spokes.  Get the normalized vectors. */

		SubPoints(((scheduleInfo *)arg1)->midSpoke.attachment,
				  ((scheduleInfo *)arg1)->midSpoke.otherPt, v1);
		vectorLength(&v1, &theLength);
		ScaleVector (v1, theLength);

		SubPoints(((scheduleInfo *)arg2)->midSpoke.attachment,
				  ((scheduleInfo *)arg2)->midSpoke.otherPt, v2);
		vectorLength(&v2, &theLength);
		ScaleVector (v2, theLength);

		/* Since the vectors now have the same magnitude, we can
		   compare them based on their x and y coordinates rather
		   than actually compute the angle of the spoke. */

		if (Greater (YVal(v1)*YVal(v2), 0)) {
		  compareResult = Sign(YVal(v1)) * Sign(XVal(v1) - XVal(v2));
		} else if (Greater (XVal(v1)*XVal(v2), 0)) {
		  compareResult = Sign(XVal(v1)) * Sign(YVal(v2) - YVal(v1));
		} else {
		  compareResult = Sign(YVal(v2));
		}
      }
    }
  }

  return compareResult;
}

/******************************************************************
; routine:  StartSweepFront
;
; description:
;   Initialises the sweep front and the event schedules to start
;   the sweep process.  All the leftmost sites must begin in the 
;   sweep front, the remaining sites must appear in the site event
;   schedule, and circle events must appear in the circle event
;   schedule for any finite Voronoi vertex in the sweep front.
;
; in:
;   theFront : FRONT_FrontType -- a sweep front where the sites can be added
;   howManySites : UInt16 -- the number of sites that appear in the site array
;   siteArray : Pgon ** -- an array of pointers to all the sites involved
;                          in the Voronoi diagram
;   siteSchedule : HEAP_Heap -- the schedule where site events go
;   circleSchedule : HEAP_Heap -- the schedule where circle events go
;
; out:
;   theFront : Front arcs are added to the sweep front
;   siteSchedule : site events are added to the schedule
;   circleSchedule : circle events may be added to the schedule
;   sweepStartXVal : Real * -- the x-coordinate where the sweep
;                        begins.
;   returns : Boolean -- False if the sweep front or schedules could not be 
;                        initialized.  True otherwise.
;
; history:
;   95.03.01 / M. McAllister / Created
;   95.05.08 / M. McAllister / Add in an infinite Voronoi vertex for
;                              each site that isn't the topmost or lowest
*******************************************************************/

static Boolean 
StartSweepFront (FRONT_FrontType theFront, 
                 UInt16 howManySites, Pgon **siteArray, 
                 HEAP_Heap siteSchedule, HEAP_Heap circleSchedule,
                 Real *sweepStartXVal)
{
  Boolean            okayToStart = True;
  HEAP_HeapId        ignoreId;
  FRONT_ArcType      newArc, prevArc, nextArc, arcForInfiniteVtx;
  Pgon               *currentSite;
  scheduleInfo       *schedule;
  UInt16             i;
  _SWP_SiteOrderType *siteInfoPtr;
  _SWP_SiteOrderType *infiniteInfoPtr;
  CLIST_NodeType     infiniteVtxNode;

  /* Start by adding all the sites to the site schedule.  This will
     draw all the leftmost ones to the top for us. */

  for (i = 0; (i < howManySites) && (okayToStart == True); i++) {
    schedule = newSchedule();
    if (schedule == NULL) {
      /* Game over -- couldn't get everybody into the schedule. */
      okayToStart = False;
    } else {
      schedule->whatEvent = EVT_SiteEvent;

      currentSite = siteArray[i];
      PointAssign(schedule->eventPt, LeftPoint(currentSite));
      schedule->poly[EVT_NewSiteIdx] = currentSite;
      okayToStart &= HEAP_Add(siteSchedule, (Ptr)schedule, &ignoreId);
    }
  }

  /* Add all the leftmost sites (now at the top of the site schedule)
     to the sweep front. */

  okayToStart &= HEAP_PeekTop (siteSchedule, (Ptr *)(&schedule));
  *sweepStartXVal = XVal(schedule->eventPt);

  while ((okayToStart) && (XVal(schedule->eventPt) == *sweepStartXVal) && 
         (schedule->whatEvent == EVT_SiteEvent)) {
    okayToStart &= HEAP_PopTop (siteSchedule, (Ptr *)(&schedule));

    /* Create a cycle of Voronoi vertices for the front arc. */

    siteInfoPtr = (_SWP_SiteOrderType *) malloc(sizeof(_SWP_SiteOrderType));
    if (siteInfoPtr == NULL) {
      okayToStart = False;
    } else {
      siteInfoPtr->reference = CLIST_NewNode (NULL);
      siteInfoPtr->top       = siteInfoPtr->reference;
      siteInfoPtr->bottom    = siteInfoPtr->reference;
      siteInfoPtr->generator = schedule->poly[EVT_NewSiteIdx];
    }

    okayToStart &= FRONT_LoadSite (theFront, schedule->poly[EVT_NewSiteIdx],
                     circleSchedule, siteSchedule, (Ptr)siteInfoPtr, &newArc);

    /* If the new arc isn't the topmost or bottommost then it should
       get an infinite Voronoi vertex. */

    prevArc = FRONT_PreviousArc (theFront, newArc);
    nextArc = FRONT_NextArc (theFront, newArc);

    arcForInfiniteVtx = FRONT_NullArc;

    if ((prevArc != FRONT_NullArc) && (nextArc != FRONT_NullArc)) {
      arcForInfiniteVtx = newArc;
    } else if ((prevArc == FRONT_NullArc) && (nextArc == FRONT_NullArc)) {
      /* I am the only arc in the tree.  Nothing to do. */
    } else if (prevArc == FRONT_NullArc) {
      /* I am the topmost arc. */

      if (nextArc != FRONT_BottomArc (theFront)) {
        arcForInfiniteVtx = nextArc;
      }
    } else {
      /* I am the lowest arc. */

      if (prevArc != FRONT_TopArc (theFront)) {
        arcForInfiniteVtx = prevArc;
      }
    }

    /* Assign the infinite Voronoi vertex if I need to. */

    if (arcForInfiniteVtx != FRONT_NullArc) {
      infiniteVtxNode = CLIST_NewNode (0); /* TBD -- not really 0 */
      infiniteInfoPtr = (_SWP_SiteOrderType *) FRONT_GetData(arcForInfiniteVtx);
      CLIST_AddAfter (infiniteVtxNode, infiniteInfoPtr->reference);
    }

    freeSchedule (&schedule);
    okayToStart &= HEAP_PeekTop (siteSchedule, (Ptr *)(&schedule));
  }

  return okayToStart;
}

/******************************************************************
; routine:  CloseArcForSite
;
; description:
;   Removes a site from the sweep front when its very last front
;   arc is deleted.  The clean-up tasks involve copying the 
;   Voronoi vertices found for the site out to the program using
;   the sweep module; the copy is done through the user callback
;   routines.
;
;   This routine will NOT remove the front arc from the sweep front;
;   it just gets rid of all the user-data in it.  Upon return, the
;   caller can safely invoke FRONT_RemoveArc on the arc.
;
; in:
;   theFront : FRONT_FrontType -- the front that is losing the arc.
;   theArc : FRONT_ArcType -- the last arc for the site that we want
;                             to remove from the sweep front.
;   circleEvents : HEAP_Heap -- the schedule of circle events.
;   configRtns : SWP_UserRoutinesType * -- the user callback routines.
;   voronoiVtxRef : Ptr -- the Voronoi vertex that was last found for
;                             this site (i.e. the one that caused the 
;                             site to lose its last front arc from the 
;                             sweep front).
;
; out:
;   the sweep front referenced through theArc will have an arc changed.
;   theFront : FRONT_FrontType * -- the allocated sweep front or
;                        FRONT_NullFront if the allocation failed.
;   returns : Boolean -- Returns False if the arc could not be removed
;                        from the sweep front.
;
; history:
;   95.03.01 / M. McAllister / Created
;   95.10.10 / M. McAllister / When resetting mergePtr->top/bottom after
;                              cycles are merged, if the first list was empty
;                              then set top/bottom beyond mergePtr reference too
;   96.09.04 / M. McAllister / freeNode was being free'ed twice
*******************************************************************/

static Boolean 
CloseArcForSite (FRONT_FrontType theFront, FRONT_ArcType theArc, 
                 HEAP_Heap circleEvents, SWP_UserRoutinesType *configRtns, 
                 Boolean vtxRefOkay, Ptr voronoiVtxRef)
{
  Boolean            arcClosed = False;
  _SWP_SiteOrderType *orderPtr, *mergePtr;
  CLIST_NodeType     newNode;
  CLIST_NodeType     runnerNode;
  CLIST_NodeType     holdNode;
  CLIST_NodeType     freeNode;
  FRONT_ArcType      prevArc, nextArc;

  if ((theArc == FRONT_NullArc) || (circleEvents == HEAP_NullHeap)) {
    AL_SoftwareAlarm (AL_Id_SWP_BadParameters, AL_Fn_SWP_CloseArcForSite,
                      (UInt32) theArc, (UInt32) circleEvents, 0, 0);
  } else {
    orderPtr = (_SWP_SiteOrderType *) FRONT_GetData (theArc);
    if (orderPtr == NULL) {
      AL_SoftwareAlarm (AL_Id_SWP_NoDataInArc, AL_Fn_SWP_CloseArcForSite,
                        (UInt32) theArc, 0, 0, 0);
    } else {

      if (vtxRefOkay == True) {
        /* Add the Voronoi vertex to the set of vertices about the arc. */

        newNode = CLIST_NewNode (voronoiVtxRef);
      }

      if ((vtxRefOkay == False) || ((newNode != CLIST_NullNode) && 
          (CLIST_AddAfter(newNode, orderPtr->bottom) == True))) {

        /* See if I can combine this front's Voronoi list with another
           arc in the sweep front. */

        prevArc = FRONT_PrevArcForSite (theFront, theArc);
        if (prevArc != FRONT_NullArc) {
          /* Merge my list of vertices with my prececessor's. */
          mergePtr = (_SWP_SiteOrderType *)FRONT_GetData(prevArc);
          CLIST_MergeCycles(mergePtr->reference,
                            orderPtr->reference);
          if (mergePtr->bottom == mergePtr->reference) {
            mergePtr->bottom = CLIST_Previous(orderPtr->reference);
            if (mergePtr->bottom == mergePtr->reference) {
              mergePtr->bottom = CLIST_Previous(mergePtr->reference);
            }
          }
          freeNode = orderPtr->reference;
          CLIST_DetachFromCycle (orderPtr->reference);
        } else {
          nextArc = FRONT_NextArcForSite (theFront, theArc);
          if (nextArc != FRONT_NullArc) {
            /* Merge my list of vertices with my successor's. */
            mergePtr = (_SWP_SiteOrderType *)FRONT_GetData(nextArc);
            CLIST_MergeCycles(orderPtr->reference,
                              mergePtr->reference);

            if (mergePtr->top == mergePtr->reference) {
              mergePtr->top = CLIST_Next(orderPtr->reference);
              if (mergePtr->top == mergePtr->reference) {
                mergePtr->top = CLIST_Next(mergePtr->reference);
              }
            }

            /* It is important here to delete the "reference" of the
               lower of the two arcs.  In this case, orderPtr reference.
               To do that, we need this extra step of ensuring
               that we have no more references to mergePtr->reference
               in the cycle.  */

            if (mergePtr->bottom == mergePtr->reference) {
              mergePtr->bottom = CLIST_Previous(mergePtr->top);
              if (mergePtr->bottom == mergePtr->reference) {
                mergePtr->bottom = CLIST_Previous(mergePtr->bottom);
              }
            }

            freeNode = mergePtr->reference;
            mergePtr->reference = orderPtr->reference;
        
            CLIST_DetachFromCycle (freeNode);
          } else {
            /* Go through all the vertices in the list and let the user
               know about them. */
  
            if (configRtns->vorVtxForSiteRtn != NULL) {
              runnerNode = CLIST_Next(orderPtr->reference);
              while ((runnerNode != orderPtr->reference) && 
                     (runnerNode != CLIST_NullNode)) {
		        (*(configRtns->vorVtxForSiteRtn))(theArc->generator, 
                                                  CLIST_GetData(runnerNode),
                                                  configRtns->contextPtr);
                runnerNode = CLIST_Next(runnerNode);
              }
		    }

            /* Dispose of the front arc information and the list of Voronoi 
               vertices. */

            runnerNode = CLIST_Next(orderPtr->reference);
            while ((runnerNode != orderPtr->reference) && 
                   (runnerNode != CLIST_NullNode)) {
              holdNode = CLIST_Next(runnerNode);
              CLIST_DetachFromCycle (runnerNode);
              CLIST_FreeNode (runnerNode);
              runnerNode = holdNode;
            }

            freeNode = orderPtr->reference;
          }
        }
      }

      CLIST_FreeNode (freeNode);
      free( orderPtr );

      arcClosed = True;
    }
  }

  return arcClosed;
}

/******************************************************************
; routine:  InfiniteVoronoiCell
;
; description:
;   This routine removes an front arc for an infinite Voronoi cell
;   from the sweep front.  The routine assumes that the arc provided
;   does correspond to such a Voronoi cell.
;
;   The tasks of the routine are to report the Voronoi vertices
;   in the arc to the site generating the arc and also to report
;   the site as one belonging to the convex hull.
;
;   Although much of the work is done by CloseArcForSite, this
;   routine is kept separate so that it can be used as a parameter
;   to a generic traversal routine of the sweep front.
;
; in:
;   theArc : FRONT_ArcType -- the front arc corresponding to an
;                        infinite Voronoi cell
;   contextPtr : Ptr -- an information block passed through the
;                       sweep front module.  It contains the schedule
;                       of circle events, the id for the Voronoi vertex
;                       at infinity, and some user callback routines.
;
; out:
;   returns : Boolean -- False if CloseArcForSite fails; True otherwise.
;
; interface note:
;   The interface must be suitable as a parameter to FRONT_ForEachNode.
;
; history:
;   95.03.01 / M. McAllister / Created
;   96.12.13 / M. McAllister / Add context parameter to convex hull
;                              routine call.
*******************************************************************/

static Boolean 
InfiniteVoronoiCell (FRONT_ArcType theArc, Ptr contextPtr)
{
  Pgon                     *sitePtr;
  _SWP_SiteOrderType       *orderPtr;
  _SWP_InfiniteArcInfoType *infoBlockPtr;
  Boolean                  deleteOkay;

  /* Get the site that generated the arc.  */ 
  orderPtr = (_SWP_SiteOrderType *) FRONT_GetData (theArc); 
  sitePtr = (orderPtr == NULL ? NULL : orderPtr->generator);

  /* Cast the contextPtr into a separate variable so we don't have 
     to continue casting it everywhere. */

  infoBlockPtr = (_SWP_InfiniteArcInfoType *)contextPtr;

  /* Now get rid of the arc. */

  deleteOkay = CloseArcForSite (infoBlockPtr->theFront, theArc, 
                 infoBlockPtr->circleEvents, infoBlockPtr->routinePtrs, 
                 True, infoBlockPtr->infinitePointId);

  /* Finally, report that the site is on the convex hull, now that
     its information is complete.  */

  if ((sitePtr != NULL) && (infoBlockPtr->routinePtrs->convexHullRtn != NULL)) {
      (*(infoBlockPtr->routinePtrs->convexHullRtn))(sitePtr, infoBlockPtr->routinePtrs->contextPtr);
  }

  return deleteOkay;
}

/******************************************************************
; routine:  CleanUpSweepFront
;
; description:
;   Once the sweep has no finite circle events left, the remaining
;   front arcs represent infinite Voronoi cells.  This routine ensures
;   that InfiniteVoronoiCell is invoked for each such arc exactly once.
;
;   The bulk of the work is in merging the highest and lowest front
;   arcs in the sweep front if they are generated by the same site.
;   Having done this, then every front arc in the sweep front is
;   generated by a distinct site and calling InfiniteVoronoiCell on
;   each remaining arc is safe.  (Calling the routine twice on
;   the same site may cause the Voronoi vertices to be reported in
;   an incorrect order.)
;
; in:
;   theFront : FRONT_FrontType -- the sweep front of front arcs for
;                        infinite Voronoi cells.
;   circleEvents : HEAP_Heap -- the schedule of circle events.
;   mergeEvents : HEAP_Heap -- the schedule of site merging events.
;   rtnPtr : SWP_UserRoutinesType * -- the user callback routines used
;                        to report Voronoi vertices for the sites.
;
; out:
;   theFront : all front arcs are removed from the sweep front
;   returns : Boolean -- False if an error occured while removing
;                        the front arcs.
;
; history:
;   95.03.01 / M. McAllister / Created
;   95.03.18 / M. McAllister / Let the caller invoke FRONT_RemoveArc so
;                              this routine can be used in a traversal
;                              of the sweep front.
;   96.12.13 / M. McAllister / For the merge of top and bottom front arcs, 
;                              keep the reference for the top arc since
;                              that is the one guaranteed to be at infinity.
*******************************************************************/

static Boolean 
CleanUpSweepFront (FRONT_FrontType theFront, HEAP_Heap circleEvents, 
                   HEAP_Heap mergeEvents, SWP_UserRoutinesType *rtnPtr)
{
  FRONT_ArcType            topArc;
  FRONT_ArcType            bottomArc;
  _SWP_SiteOrderType       *topOrder;
  _SWP_SiteOrderType       *bottomOrder;
  _SWP_InfiniteArcInfoType infiniteInfo;
  Pt                       dummyPt;
  Boolean                  cleanUpOkay = True;

  topArc    = FRONT_TopArc(theFront);
  bottomArc = FRONT_BottomArc(theFront);

  if (topArc != bottomArc) {
    topOrder    = (_SWP_SiteOrderType *)FRONT_GetData (topArc);
    bottomOrder = (_SWP_SiteOrderType *)FRONT_GetData (bottomArc);

    if (topOrder->generator == bottomOrder->generator) {
      /* The two arcs must be combined into one */

      if ((CLIST_MergeCycles (topOrder->reference, bottomOrder->reference) 
                   == False) || 
          (CLIST_DetachFromCycle (bottomOrder->reference) == False)) {
        cleanUpOkay = False;
      }
      CLIST_FreeNode (bottomOrder->reference);

      cleanUpOkay &= FRONT_RemoveArc(theFront, bottomArc, circleEvents, 
                                     mergeEvents, False);
      free (bottomOrder);
    }
  }

  /* Load up all the information that the callback routine will need. */

  if (cleanUpOkay != False) {
    if ((rtnPtr->foundVorVtxRtn == NULL) && (rtnPtr->convexHullRtn == NULL)) {
      /* If I don't do it right, they'll never know so I may as well
         say that it's okay and just not do anything. */
      cleanUpOkay = True;
    } else {
      dummyPt.w = 0.0;
      infiniteInfo.infinitePointId = (*(rtnPtr->foundVorVtxRtn))
                                         (&dummyPt, SWP_InfiniteVertex,
                                          rtnPtr->contextPtr);
      infiniteInfo.circleEvents = circleEvents;
      infiniteInfo.routinePtrs = rtnPtr;
      infiniteInfo.theFront = theFront;

      cleanUpOkay = FRONT_Traverse (theFront,InfiniteVoronoiCell,&infiniteInfo);
    }
  }

  return cleanUpOkay;
}

/******************************************************************
; routine:  SiteEvent
;
; description:
;   Handle all the tasks for adding a site to the sweep front.  Most
;   of the work is actually done by the sweep front module.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to which the site
;                        is added.
;   circleEvents : HEAP_Heap -- the schedule of circle events
;   mergeEvents : HEAP_Heap -- the schedule of site merging events
;   theEvent : scheduleInfo * -- the site event that is being added
;                        to the sweep front.
;   rtnPtr : SWP_UserRoutinesType * -- the set of user callback
;                        routines.  The routine that indicates the start
;                        of a site event is used.
;
; out:
;   theFront : an arc is added to the sweep front and an existing arc
;              is split into two parts.
;   circleEvents : events are added and deleted to the schedule for
;                  the new arcs.
;   mergeEvents : events are added and deleted to the schedule for
;                 the new arcs.
;   returns : Boolean -- False if the sweep front module could not
;                        add the site to the sweep front.
;
; history:
;   95.03.01 / M. McAllister / Created
*******************************************************************/

static Boolean 
SiteEvent (FRONT_FrontType theFront, HEAP_Heap circleEvents, 
           HEAP_Heap mergeEvents,
           scheduleInfo *theEvent, SWP_UserRoutinesType *rtnPtr)
{
  Boolean             siteAdded = False;
  _SWP_SiteOrderType  *newSiteOrder;
  _SWP_SiteOrderType  *splitSiteOrder;
  _SWP_SiteOrderType  *topOrder;
  _SWP_SiteOrderType  holdTheData;
  FRONT_ArcType       ignoreArc;
  FRONT_ArcType       splitArcBottom;
  FRONT_ArcType       splitArcTop;

  if (theEvent == NULL) {
    AL_SoftwareAlarm (AL_Id_SWP_NullEvent, AL_Fn_SWP_SiteEvent, 0, 0, 0, 0);
  } else {

	/* Tell the user of the sweep module that we are having a site event.  */

	if (rtnPtr->startSiteEventRtn != NULL) {
	  (*(rtnPtr->startSiteEventRtn))(theEvent->poly[EVT_NewSiteIdx],
			   XVal(LeftPoint(theEvent->poly[EVT_NewSiteIdx])), theFront);
	}

	/* Actually add the site to the sweep front.  Before adding it, we
	   must allocate the data blocks where we will accumulate the Voronoi
	   vertices for the arc.  These data blocks are then stored as the
	   data in the front arcs. */

	newSiteOrder   =(_SWP_SiteOrderType *)malloc(sizeof(_SWP_SiteOrderType));
	splitSiteOrder =(_SWP_SiteOrderType *)malloc(sizeof(_SWP_SiteOrderType));
	if ((newSiteOrder != NULL) && (splitSiteOrder != NULL)) {
	  siteAdded = FRONT_NewSite (theFront, theEvent->poly[EVT_NewSiteIdx], 
				   circleEvents, mergeEvents, (Ptr) newSiteOrder, 
                   (Ptr) splitSiteOrder, &ignoreArc, &splitArcBottom);

	  /* Each new front arc gets a refrence node in its arc. */

	  newSiteOrder->reference = CLIST_NewNode (NULL);
	  newSiteOrder->top       = newSiteOrder->reference;
	  newSiteOrder->bottom    = newSiteOrder->reference;
	  newSiteOrder->generator = theEvent->poly[EVT_NewSiteIdx];

	  splitArcTop = FRONT_PrevArcForSite(theFront, splitArcBottom);
	  topOrder = (_SWP_SiteOrderType *)FRONT_GetData (splitArcTop);

	  if (topOrder == NULL) {
		AL_SoftwareAlarm (AL_Id_SWP_NoDataInArc, AL_Fn_SWP_SiteEvent,
						  (UInt32) splitArcTop, 0, 0, 0);
		siteAdded = False;
	  } else {
		splitSiteOrder->reference = CLIST_NewNode (NULL);
		splitSiteOrder->top       = splitSiteOrder->reference;
		splitSiteOrder->bottom    = splitSiteOrder->reference;
		splitSiteOrder->generator = topOrder->generator;

		/* Time to reshuffle the Voronoi vertices for the split arc. */

		if (topOrder->reference != topOrder->bottom) {
		  if (topOrder->reference == topOrder->top) {
			/* Just give the lower arc the cycle in the top arc. */

			holdTheData     = *splitSiteOrder;
			*splitSiteOrder = *topOrder;
			*topOrder       = holdTheData;
		  } else {

			/* Split the cycle for the top arc. */

			if (CLIST_BreakCycles(topOrder->reference, topOrder->bottom) ==False){
			  siteAdded = False;
			  /* It failed; what to do? TBD */
			} else {
			  siteAdded = CLIST_AddAfter (splitSiteOrder->reference, 
										  topOrder->bottom);
			  splitSiteOrder->bottom = topOrder->bottom;
			  topOrder->bottom = topOrder->reference;
			}
		  }
		}
	  }
	} else {
	  if (newSiteOrder != NULL)
         free( newSiteOrder );
      else if (splitSiteOrder != NULL)
        free( splitSiteOrder );
    }

	freeSchedule (&theEvent);
  }

  return siteAdded;
}

/******************************************************************
; routine:  CircleEvent
;
; description:
;   A Voronoi vertex has been discovered.  Report the vertex to
;   the user through a callback routine, keep track of the Voronoi
;   vertices around each front arc (allowing for Voronoi vertices
;   with degree higher than 3), and remove all the front arcs in the
;   sweep front that vanish as a result of this Voronoi vertex.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front.
;   circleEvents : HEAP_Heap -- the schedule of circle events
;   mergeEvents : HEAP_Heap -- the schedule of merging site events
;   theEvent : scheduleInfo * -- the circle event that is occurring
;                        on the sweep front.
;   rtnPtr : SWP_UserRoutinesType * -- the set of user callback
;                        routines.  The routines that indicate the start
;                        of a circle event and a new Voronoi vertex are used.
;
; out:
;   theFront : front arcs are removed from the sweep front.
;   circleEvents : events are added and deleted to the schedule for
;                  the new arcs.
;   mergeEvents : events are added and deleted to the schedule for
;                 the new arcs.
;   returns : Boolean -- False if the appropriate front arcs could not
;                        be removed from the sweep front or if circle
;                        events could not be rescheduled properly.
;
; history:
;   95.03.01 / M. McAllister / Created
;   95.03.18 / M. McAllister / Free the middle front arcs after they close
;   95.03.20 / M. McAllister / HEAP_Peek False if heap empty not an error case
;   95.05.18 / M. McAllister / Redo routine so that it captures Voronoi
;                              vertices generated by more than one site.
*******************************************************************/

static Boolean 
CircleEvent (FRONT_FrontType theFront, HEAP_Heap circleEvents, 
             HEAP_Heap mergeEvents, scheduleInfo *theEvent, 
             SWP_UserRoutinesType *rtnPtr)
{
  Boolean             arcDeleted = False;
  Ptr                 theVoronoiPointRef;
  _SWP_SiteOrderType  *siteOrderPtr;
  CLIST_NodeType      listNode;
  Pt                  theVoronoiPoint;

  if (theEvent == NULL) {
    AL_SoftwareAlarm (AL_Id_SWP_NullEvent, AL_Fn_SWP_CircleEvent, 0, 0, 0, 0);
  } else {

	/* Tell the user of the sweep module that we are having a circle event.  */

	if (rtnPtr->startCircleEventRtn != NULL) {
	  (*(rtnPtr->startCircleEventRtn))(&(theEvent->eventCentre),
			   XVal(theEvent->eventPt), theFront);
	}

	/* Record that we have the Voronoi vertex. */

    PointAssign (theVoronoiPoint, theEvent->eventCentre);
	if (rtnPtr->foundVorVtxRtn == NULL) {
	  theVoronoiPointRef = NULL;
	} else {
	  theVoronoiPointRef = (*(rtnPtr->foundVorVtxRtn))
							 (&(theEvent->eventCentre), SWP_FiniteVertex,
                              rtnPtr->contextPtr);
	}

	/* Let the topmost polygon know that it has one more Voronoi vertex */

	siteOrderPtr = (_SWP_SiteOrderType *) FRONT_GetData (theEvent->frontArcs[EVT_TopElement]);
    listNode = CLIST_NewNode(theVoronoiPointRef);
	if ((siteOrderPtr != NULL) && (listNode != CLIST_NullNode)){
      if (CLIST_AddAfter (listNode, siteOrderPtr->bottom) == True) {
        siteOrderPtr->bottom = listNode;

	    if (rtnPtr->siteForVorVtxRtn != NULL) {
	      (*(rtnPtr->siteForVorVtxRtn)) (theVoronoiPointRef, 
                                         theEvent->poly[EVT_TopElement],
                                         rtnPtr->contextPtr);
	    }

        /* Get rid of the middle arc, adding in the Voronoi vertex. */

        arcDeleted = CloseArcForSite(theFront, 
                                     theEvent->frontArcs[EVT_MiddleElement],
                                     circleEvents, rtnPtr, True, theVoronoiPointRef)
                  && FRONT_RemoveArc (theFront, 
                                      theEvent->frontArcs[EVT_MiddleElement],
                                      circleEvents, mergeEvents, False);
	    if (rtnPtr->siteForVorVtxRtn != NULL) {
	      (*(rtnPtr->siteForVorVtxRtn)) (theVoronoiPointRef, 
                                         theEvent->poly[EVT_MiddleElement],
                                         rtnPtr->contextPtr);
	    }

        /* Let the bottommost arc know that it has a new Voronoi point. */

        if (arcDeleted) {
	      siteOrderPtr = (_SWP_SiteOrderType *) FRONT_GetData (theEvent->frontArcs[EVT_BottomElement]);
          listNode = CLIST_NewNode(theVoronoiPointRef);
	      if ((siteOrderPtr != NULL) && (listNode != CLIST_NullNode)){
            if (CLIST_AddAfter (listNode, siteOrderPtr->bottom) == True) {
              siteOrderPtr->top = listNode;
              arcDeleted = True;

	          if (rtnPtr->siteForVorVtxRtn != NULL) {
	            (*(rtnPtr->siteForVorVtxRtn)) (theVoronoiPointRef, 
                                           theEvent->poly[EVT_BottomElement],
                                           rtnPtr->contextPtr);
              }
            }
          }
        } /* if arcDeleted */
      } /* if Voronoi vertex added for topmost front arc. */
	} /* if siteOrderPtr != NULL && listNode != CLIST_NullNode */
    /* Get rid of the latest event. */

    freeSchedule (&theEvent);
  } /* if theEvent != NULL */

  return arcDeleted;
}


