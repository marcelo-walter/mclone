/*******************************************************************************
 * NAME : TIN VAN NGUYEN                                                         
 * DATE : May 25, 1995                                                           
 *                                                                               
 * This program provides two subroutines:
 *
 * (0) threeSegment(point, center, i, j, k)
 *          pType point[7], center, i, j, k;
 *
 * (1) twoSegment(line, order, a, b, c, d, e, center, i, j)
 *          int line, order;
 *          pointType a, b, c, d, e, center, i, j; 
 *
 * (2) oneSegment(line, order, a, b, c, e, center, i)
 *          int line, order;
 *          pointType a, b, c, e, center, i;
 *
 * 'threeSegment' tries to find a circle that touches 3 given segment such that
 * the points are in CCW order. It returns TRUE if such a circle exists; the center 
 * and 3 touching points are then stored in 'center, i, j, and k'.  
 * Otherwise, it returns FALSE.
 *
 * 'twoSegment' tries to find a circle that goes through E and touches AB and CD. 
 * Touching means either the circle accepts the line segment as a supporting line 
 * or it goes through an endpoint of the line segment without containing the rest 
 * of the line segment.
 *
 * 'oneSegment' tries to find a circle that goes through C, E and touches the line
 * segment AB. On the resulting circle, direction from C -> E -> AB is always 
 * counter-clockwise.
 *
 * In 'twoSegment':   line  = ZERO ==> both are line segments.
 *                            ONE  ==> AB is a straight line.
 *                            TWO  ==> CD is a straight line.
 *
 *                    order = ZERO ==> E -> AB -> CD is CCW
 *                            ONE  ==> AB -> E -> CD is CCW
 *                            TWO  ==> AB -> CD -> E is CCW
 *
 * In 'oneSegment':   line = TRUE  ==> AB is a straight line; 
 *                           FALSE ==> AB is a line segment.
 *
 *                    order = ZERO ==> AB -> C -> E is CCW
 *                            ONE  ==> C -> AB -> E is CCW
 *                            TWO  ==> C -> E -> AB is CCW
 *
 *             a, b, c, d, e are co-ordinates of A, B, C, D, E.
 *             center, i, j are returned values.
 *
 * 
 * They return -1 if the given points are invalid.
 *              0 if no case works ===> w = 0;
 *              1 if case 1 works  ===> w = 1;
 *              2 ------- 2 -----  ===> w = 1;
 *              3 ------- 3 -----  ===> w = 1;
 *
 * In the case that the circle is found, the center's co-ordinates are stored 
 * in 'center'; the touching point on AB is stored in 'i'; on CD in 'j'.
 * 
 * TO TEST 'TWOSEGMENT': test  <a floating-point number> 
 *         'ONESEGMENT': test1 <a floating-point number>
 *
 ******************************************************************************/
#include "sub.h"
#include "main.h"
#include "geometry.h"
#include "degen.h"

#define deter2d(a, b, c, d)  (a*d - b*c)

/******************************************************************************/

int SAME_POINT(pType a, pType b)
{
  if ((fabs(a[X] - b[X]) < GEOM_EPSILON) && (fabs(a[Y] - b[Y]) < GEOM_EPSILON)
      && (fabs(a[W] - b[W]) < GEOM_EPSILON)) return TRUE;
  else return FALSE;
}

/******************************************************************************/
int validity(int flag, pointType a, pointType b, pointType c, 
             pointType d, pointType e)

/* This subroutine is to invoked at the beginning of 'twoSegment' or 'oneSegment' . 
 * It checks to see if A is not B; C is not D. More over, AB and CD are not 
 * the same; E is not one of A, B, C, or D.
 * It also check to see if a, b, c, d, e's w are 1.
 * flag = ONE ==> check for oneSegment subroutine ==> C == D.
          TWO ==> check for twoSegment subroutine.
 * It returns TRUE if the checking conditions are satisfied; FALSE otherwise.
 */
{
  if ((a[W] != 1.0) || (b[W] != 1.0) || (c[W] != 1.0) || (d[W] != 1.0) 
      || (e[W] != 1.0)) return FALSE; 

/*
  if (SAME_POINT(e, a)) return FALSE; 
  if (SAME_POINT(e, b)) return FALSE; 
  if (SAME_POINT(e, c)) return FALSE; 
  if (SAME_POINT(e, d)) return FALSE; 
*/
  if (flag == TWO)
    {
/*    if (SAME_POINT(e, d)) return FALSE;  */
      if (SAME_POINT(c, d)) return FALSE; 
      if (SAME_POINT(a, c) && SAME_POINT(b, d)) return FALSE; 
    };

  if (SAME_POINT(a, d) && SAME_POINT(b, c)) return FALSE; 
  return TRUE;
}
/*****************************************************************************/
int quaSolve(pointType co, pointType solution)

/* This subroutine solves the quadratic equation ax^2 + bx + c = 0. It returns
 * the number of solutions and stores the solutions (if there is any) in x1 and
 * x2. If a = b = c = 0, it returns 3.
 */

{
  coType delta;

  if (fabs(co[A]) < GEOM_EPSILON)
    {
      if (fabs(co[B]) < GEOM_EPSILON)
	{
	  if (fabs(co[C]) < GEOM_EPSILON)
	    {
	      return THREE;  /* Infinitely many solutions */
	    }
	  else return ZERO; /* No solution */
	}
      else
	{
	  solution[ONE] = -co[C]/co[B];
	  return ONE;
	}
    }
  else /* co[A] <> 0 */
    {
      coType rcoA = 1.0/co[A];

      delta = co[B]*co[B] - 4*co[A]*co[C];

      if (fabs(delta) < GEOM_EPSILON)
	{
	  solution[ONE] = -0.5*co[B]*rcoA;
	  return ONE;
	}
      else if (delta < 0.0) return ZERO;
      else /* 2 solutions */
	{
	  coType temp = sqrt(delta);

	  solution[ONE] = 0.5*(-co[B] + temp)*rcoA;
	  solution[TWO] = 0.5*(-co[B] - temp)*rcoA;
	  return TWO;
	}
    }
}
/*********************************************************************************/
coType deter3d(pointType a, pointType b, pointType c)
{
  coType temp1, temp2, temp3;

  temp1 = deter2d(b[Y], b[W], c[Y], c[W]);
  temp2 = deter2d(a[Y], a[W], c[Y], c[W]);
  temp3 = deter2d(a[Y], a[W], b[Y], b[W]);

  return (a[X]*temp1 - b[X]*temp2 + c[X]*temp3);
}
/**********************************************************************************/
int cramer(pointType co1, pointType co2, pointType solution)

/* This subroutine solves the following system of equations:
 *                       a1*x + b1*y = c1
 *                       a2*x + b2*y = c2
 * It returns TRUE if a solution exists; the solution is then stored in 'solution'
 * It return FALSE otherwise.
 */
{
  coType d, rd, dx, dy;
  
  d = deter2d(co1[A], co1[B], co2[A], co2[B]);
  if (fabs(d) < GEOM_EPSILON) return FALSE;
  rd = 1.0/d;

  dx = deter2d(co1[C], co1[B], co2[C], co2[B]);
  dy = deter2d(co1[A], co1[C], co2[A], co2[C]);

  solution[W] = 1.0;
  solution[X] = dx*rd;
  solution[Y] = dy*rd;

  return TRUE;
}
/**********************************************************************************/
int normalized(pointType one, pointType two, pointType para)

/* This subroutine accepts the co-ordinates of two points and returns the 
 * normalized first degree equation of the straight line passing through those 
 * two points in a, b, c.
 * Normalization means a^2 + b^2 = 1.
 * The function returns FALSE if two points are identical, TRUE otherwise
 */
{
  coType rLength;

  if (SAME_POINT(one, two)) return FALSE; /* 2 points are the same */

  if (fabs(one[X] - two[X]) < GEOM_EPSILON) /* Vertical line */
    {
      para[A] = 1.0;
      para[B] = 0.0;
      para[C] = -one[X];
      return TRUE;
    };

  if (fabs(one[Y] - two[Y]) < GEOM_EPSILON) /* Horizontal line */
    {
      para[A] = 0.0;
      para[B] = 1.0;
      para[C] = -one[Y];
      return TRUE;
    };

  /* Regular case */ 
  
  rLength = 1.0/sqrt((one[X]-two[X])*(one[X]-two[X]) + (one[Y]-two[Y])*(one[Y]-two[Y]));
  para[A] = (two[Y] - one[Y])*rLength;
  para[B] = (one[X] - two[X])*rLength;
  para[C] = (one[Y]*two[X] - two[Y]*one[X])*rLength;

  return TRUE;
}
/*********************************************************************************/
int shortest(int infi, pointType start, pointType end, pointType co, 
             pointType m, pointType base)

/* This subroutine find the point I on the straight line defined by the given
 * line segment such that MI is perpendicular to the line. 
 * If infi = TRUE  => (start, end) is a straight line.
 *           FALSE => (start, end) is a line segment. In this case, I is accepted
 * only if it falls inside the line segment.
 * The co-ordinates of I are stored in 'base'
 */
{
  int result;
  pointType temp1, temp2; 

  temp1[A] = end[X] - start[X];
  temp1[B] = end[Y] - start[Y];
  temp1[C] = m[X]*temp1[A] + m[Y]*temp1[B];

  temp2[A] = co[A]; temp2[B] = co[B]; temp2[C] = -co[C];

  result = cramer(temp1, temp2, base);
  if (!result) return FALSE;
  if (infi) return TRUE;

  if (((base[X]-start[X])*(base[X]-end[X]) + (base[Y]-start[Y])*(base[Y]-end[Y])) > GEOM_EPSILON) 
    return FALSE;

  return TRUE;
}
/**********************************************************************************/
int counterClock(pointType one, pointType two, pointType three)

/* This subroutine checks to see if the direction from 1 to 2 to 3 is 
 * counter-clockwise. If this is the case, it returns TRUE, FALSE otherwise.
 */
{
  one[W] = 1.0; two[W] = 1.0; three[W] = 1.0;
  if (deter3d(one, two, three) > 0.0) return TRUE;
  return FALSE;
}
/***********************************************************************************/
int inCircle(pointType a, pointType b, pointType c, pointType d)

/* This subroutine performs the in-circle test -- It checks to see the relative 
 * position of the fourth point  with respect to the circle defined by the
 * first 3 points.    
 *
 * This subroutine ensures that the result is consistent regardless of the order of
 * the given three points.
 *
 * It returns 1 if the fourth is outside the circle
 *            0 ---------------- on     ----------
 *           -1 ---------------- inside ----------
 */
{
  coType temp1, temp2, temp3, temp4, result;
  int flag;

  if (counterClock(a, b, c)) flag = 1;
  else flag = -1;
  
  temp1 = (a[X] - d[X])*(b[Y] - d[Y]) - (b[X] - d[X])*(a[Y] - d[Y]);
  temp2 = (a[X] - d[X])*(c[Y] - d[Y]) - (c[X] - d[X])*(a[Y] - d[Y]);
  temp3 = (b[X] - d[X])*(b[X] - a[X]) + (b[Y] - d[Y])*(b[Y] - a[Y]);
  temp4 = (c[X] - d[X])*(c[X] - a[X]) + (c[Y] - d[Y])*(c[Y] - a[Y]);

  result = deter2d(temp1, temp2, temp3, temp4);

  if (fabs(result) < GEOM_EPSILON) return 0;

  if (result < 0.0)
    {
      return flag;
    }
  else if (result > 0.0)
    {
      return -1*flag;
    }
  else return 0;
}
/**********************************************************************************/
void testPoint(pointType end, pointType one, pointType two, pointType point)

/* This subroutine computes the point on the lined segment 1--2 that is "next to"
 * 'end' such that the distance between the 2 points is not larger than 1.
 * This subroutine assumes that the given points 1 and 2 are not the same.
 */
{
  pointType start;
  coType slope;

  if (SAME_POINT(end, one))
    {
      start[X] = two[X]; start[Y] = two[Y];
    }
  else
    {
      start[X] = one[X]; start[Y] = one[Y];
    };

  if (fabs(end[X] - start[X]) < GEOM_EPSILON) /* Vertical line */
    {
      point[X] = end[X];
      if (end[Y] > start[Y]) point[Y] = end[Y] - 1.0;
      else  point[Y] = end[Y] + 1.0;

      return;
    };

 if (fabs(end[Y] - start[Y]) < GEOM_EPSILON) /* Horizontal line */
    {
      point[Y] = end[Y];
      if (end[X] > start[X]) point[X] = end[X] - 1.0;
      else  point[X] = end[X] + 1.0;

      return;
    };

  slope = (start[Y] - end[Y])/(start[X] - end[X]);

  if (fabs(slope) < 1.0) /* raise x */
    {
      if (end[X] > start[X]) point[X] = end[X] - 1.0;
      else point[X] = end[X] + 1.0;

      point[Y] = slope*(point[X] - start[X]) + start[Y];
      return;
    }
  else /* raise y */
    {
      if (end[Y] > start[Y]) point[Y] = end[Y] - 1.0;
      else point[Y] = end[Y] + 1.0;

      point[X] = (point[Y] - start[Y])/slope + start[X];
      return;
    }
}
/*********************************************************************************/
int threePointCircle(pointType a, pointType b, pointType c, pointType d)

/* This subroutine finds the circle that passes through a, b, and c. 
 * It returns TRUE if the circle is defined, the center's co-ordinates are then
 * stored in d
 * It returns FALSE if the given points are not distinct from one another or they
 * are distinct but co-linear.
 */
{
#if 1
  HOMOG bisAB, bisBC;
  Pt    pa, pb, pc, centre;

  if (fabs(deter3d(a, b, c)) < GEOM_EPSILON) return FALSE;

  /* Now we know the given points are distinct and not co-linear */

  pa.w = a[W]; pa.x = a[X]; pa.y = a[Y];
  pb.w = b[W]; pb.x = b[X]; pb.y = b[Y];
  pc.w = c[W]; pc.x = c[X]; pc.y = c[Y];

  BISECT_C(&pa, &pb, &bisAB);
  BISECT_C(&pb, &pc, &bisBC);
  CROSS_2H(&bisAB, &bisBC, &centre);

  d[W] = 1.0;
  d[X] = XVal(centre);
  d[Y] = YVal(centre);

  return TRUE;
#else
  pointType co1, co2;
  int result;

  if (SAME_POINT(a, b) || SAME_POINT(a, c) || SAME_POINT(b, c)) return FALSE;
  
  if (fabs(deter3d(a, b, c)) < GEOM_EPSILON) return FALSE;

  /* Now we know the given points are distinct and not co-linear */

  if (fabs(a[Y] - b[Y]) < GEOM_EPSILON)
    {
      d[W] = 1.0;
      d[X] = 0.5*(a[X] + b[X]);
      d[Y] = (c[X]-a[X])*(d[X] -0.5*(a[X]+c[X]))/(a[Y]-c[Y]) + 0.5*(a[Y] + c[Y]);
      return TRUE;
    }
  else if (fabs(a[Y] - c[Y]) < GEOM_EPSILON)
    {
      d[W] = 1.0;
      d[X] = 0.5*(a[X] + c[X]);
      d[Y] = (b[X]-a[X])*(d[X] -0.5*(a[X]+b[X]))/(a[Y]-b[Y]) + 0.5*(a[Y] + b[Y]);
      return TRUE;
    }
  else /* general case */
    {
      co1[A] = (b[X] - a[X])/(a[Y] - b[Y]);
      co1[B] = -1.0;
      co1[C] = 0.5*((a[X] + b[X])*co1[A] - a[Y] - b[Y]);
      co2[A] = (c[X] - a[X])/(a[Y] - c[Y]);
      co2[B] = -1.0;
      co2[C] = 0.5*((a[X] + c[X])*co2[A] - a[Y] - c[Y]);
   
      d[W] = 1.0;
      result = cramer(co1, co2, d);
      return (result);
    }
#endif
}
/**********************************************************************************/
int case1(int line, int order, pointType co1, pointType co2, pointType a, 
          pointType b, pointType c, pointType d, pointType e, pointType cen, 
          pointType i, pointType j)

/* This subroutine tries case 1. It returns TRUE if this is the case, FALSE otherwise
 */  
{
  coType a1, b1, c1, a2, b2, c2;
  coType alpha, beta, gamma;
  pointType k, sol;
  int counter, quaResult;
  int flag = TRUE; /* TRUE --> quaSolve solves for x; FALSE solves for y */
  int infi1, infi2;  /* TRUE means straight line */

  infi1 = FALSE; infi2 = FALSE;
  if (line == ONE) infi1 = TRUE;
  else if (line == TWO) infi2 = TRUE;

  a1 = co1[A]; b1 = co1[B]; c1 = co1[C]; a2 = co2[A]; b2 = co2[B]; c2 = co2[C];

  if ((fabs(a1*e[X] + b1*e[Y] + c1) < GEOM_EPSILON) && (fabs(a2*e[X] + b2*e[Y] + c2) < GEOM_EPSILON))
    {
      if (((a[X] - e[X])*(b[X] - e[X]) + (a[Y] - e[Y])*(b[Y] - e[Y]) <= 0.0)
	  && ((c[X] - e[X])*(d[X] - e[X]) + (c[Y] - e[Y])*(d[Y] - e[Y]) <= 0.0))
	{
	  cen[X] = e[X]; cen[Y] = e[Y]; cen[W] = e[W];
	  return TRUE;
	}
      else return FALSE;
    };

  if ((fabs(a1 - a2) < GEOM_EPSILON) && (fabs(b1 - b2) < GEOM_EPSILON))  /* Diff \\ lines ==> c1 <> c2 */
    {
      gamma = 0.25*(c1 - c2)*(c1 - c2);
      if (b1 != 0)
	{
	  coType rb1 = 1.0/b1;

	  alpha = -a1*rb1;
	  beta = -0.5*(c1 + c2)*rb1;
	  k[A] = alpha*alpha - 1.0;
	  k[B] = 2.0*(alpha*beta - e[X] - alpha*e[Y]);
	  k[C] = e[X]*e[X] + e[Y]*e[Y] + beta*beta - 2.0*e[Y]*beta - gamma;
	}
      else
	{
	  flag = FALSE;
	  cen[X] = -0.5*(c1 + c2)/a1;
	  k[A] = 1.0;
	  k[B] = -2.0*e[Y];
	  k[C] = e[Y]*e[Y] + (cen[X] - e[X])*(cen[X] - e[X]) - gamma;
	}
    }
  else 
    {
      coType a, b, c;

      if (fabs(a1*e[X] + b1*e[Y] + c1) < GEOM_EPSILON)  /* Sufficiently on the line */ 
	{
	  a = a2; b = b2; c = c2;
	}
      else 
	{
	  a = a1; b = b1; c = c1;
	};
      
      if (b1 != b2)
	{
	  coType rb21 = 1.0/(b2 - b1);
	  
	  alpha = (a1 - a2)*rb21;
	  beta = (c1 - c2)*rb21;
	  k[A] = a*a - 1.0 + alpha*alpha*(b*b - 1.0) + 2.0*alpha*a*b;
	  k[B] = 2.0*(a*c + e[X] + alpha*beta*(b*b-1.0)+ beta*a*b + alpha*(b*c+e[Y]));
	  k[C] = 2.0*beta*(b*c+e[Y])+ c*c - e[X]*e[X] - e[Y]*e[Y] + (b*b-1.0)*beta*beta;
	}
      else
	{
	  flag = FALSE;
	  cen[X] = (c2 - c1)/(a1 - a2);
	  k[A] = b*b - 1.0;
	  k[B] = 2.0*(b*c + e[Y] + a*b*cen[X]);
	  k[C] = (a*a-1.0)*cen[X]*cen[X]+2.0*(a*c+e[X])*cen[X]+c*c-e[X]*e[X] - e[Y]*e[Y];
	}
    };
     
  quaResult = quaSolve(k, sol);

  if ((quaResult != ONE) && (quaResult != TWO)) return FALSE;
      
  for (counter = 1; counter <= quaResult; counter++)
    {
      if (flag) 
	{
	  cen[X] = sol[counter];
	  cen[Y] = alpha*cen[X] + beta;
	}
      else cen[Y] = sol[counter];

      
      if (shortest(infi1, a, b, co1, cen, i) && shortest(infi2, c, d, co2, cen, j))
	{
	  if (SAME_POINT(e, i) || SAME_POINT(e, j)) return TRUE;
	  else 
	    {
	      if (order == ZERO)
		{
		  if (counterClock(e, i, j)) return TRUE;
		}
	      else if (order == ONE)
		{
		  if (counterClock(i, e, j)) return TRUE;
		}
	      else if (counterClock(i, j, e))return TRUE;
	    }
	}
    }
  return FALSE;
}
/************************************************************************************/
int ground2(int infi, int order, int direction, pointType co, pointType a, 
            pointType b, pointType e, pointType f, pointType cen, 
            pointType base)

/* This subroutine tries to find a circle that goes through F, E, and touches the 
 * line segment (a, b) such that the direction from F -> E -> (a, b) is 'direction'.
 * It returns TRUE if such a circle exists, FALSE otherwise.
 */
{
  coType alpha, beta;
  int counter, quaResult;
  pointType s, k, sol;
  int flag = TRUE; /* TRUE --> quaSolve solves for x; FALSE solves for y */

  s[X] = e[X]; s[Y] = e[Y]; s[W] = e[W];

  if (fabs(co[A]*e[X] + co[B]*e[Y] + co[C]) < GEOM_EPSILON) 
      {
	s[X] = f[X]; s[Y] = f[Y]; s[W] = f[W];
      };

  if (fabs(co[A]*f[X] + co[B]*f[Y] + co[C]) < GEOM_EPSILON) 
      {
	s[X] = e[X]; s[Y] = e[Y]; s[W] = e[W];
      };

  if (e[Y] != f[Y])
    {
      alpha = (e[X] - f[X])/(f[Y] - e[Y]);
      beta = 0.5*(f[Y] + e[Y] - alpha*(e[X] + f[X]));
      k[A] = co[A]*co[A] - 1.0 + alpha*alpha*(co[B]*co[B] - 1.0) + 2.0*alpha*co[A]*co[B];
      k[B] = 2.0*(co[A]*co[C] + s[X] + alpha*beta*(co[B]*co[B] - 1.0) 
		  + beta*co[A]*co[B] + alpha*(co[B]*co[C] + s[Y]));
      k[C] = 2.0*beta*(co[B]*co[C] + s[Y]) + co[C]*co[C] - s[X]*s[X] - s[Y]*s[Y] 
	          + (co[B]*co[B] - 1.0)*beta*beta;
    }
  else
    {
      flag = FALSE;
      cen[X] = 0.5*(e[X] + f[X]);
      k[A] = co[B]*co[B] - 1.0;
      k[B] = 2.0*(co[B]*co[C] + s[Y] + co[A]*co[B]*cen[X]);
      k[C] = (co[A]*co[A] - 1.0)*cen[X]*cen[X] + 2.0*(co[A]*co[C] + s[X])*cen[X] 
	        + co[C]*co[C] - s[X]*s[X] - s[Y]*s[Y];
    };

  quaResult = quaSolve(k, sol);

  if ((quaResult != ONE) && (quaResult != TWO)) return FALSE;
      
  for (counter = 1; counter <= quaResult; counter++)
    {
      if (flag)
	{
	  cen[X] = sol[counter];
	  cen[Y]= alpha*cen[X] + beta;
	}
      else cen[Y] = sol[counter];
     
      if (shortest(infi, a, b, co, cen, base))
	{
	  if (SAME_POINT(e, base) || SAME_POINT(f, base)) return TRUE; 
	  if (direction)
	    {
	      if (order == ZERO) 
		{
		  if (counterClock(e, base, f)) return TRUE;
		}
	      else if (order == ONE)
		{
		  if (counterClock(base, e, f)) return TRUE;
		}
	      else if (counterClock(base, f, e)) return TRUE;
	    }
	  else 
	    {
	      if (order == ZERO)
		{
		  if (counterClock(e, f, base)) return TRUE;
		}
	      else if (order == ONE)
		{
		  if (counterClock(f, e, base)) return TRUE;
		}
	      else if (counterClock(f, base, e)) return TRUE;
	    }
	}
    }
  return FALSE; 
}
/************************************************************************************/
int case2(int seg, int infi, int order, pointType co, pointType a, 
          pointType b, pointType c, pointType d, pointType e, pointType one, 
          pointType cen, pointType i, pointType j)

/* This case tries to find a circle that goes through E, (x1, y1) and touches the line
 * segment identified by "seg".
 *
 * seg = 1 ==> AB; seg = 2 ==> CD
 * infi = TRUE ==> 'seg' represents a straight line; FALSE ==> real line segment.
 * It returns TRUE if there is such a circle, FALSE otherwise.
 */
{
  pointType start, end, base, pTest;
  int direction;

  if (seg == 1)
    {
      direction = TRUE;
      start[X] = a[X]; start[Y] = a[Y]; end[X] = b[X]; end[Y] = b[Y];
    }
  else
    {
      direction = FALSE;
      start[X] = c[X]; start[Y] = c[Y]; end[X] = d[X]; end[Y] = d[Y];
    };

  if (ground2(infi, order, direction, co, start, end, e, one, cen, base))
    {
      if (seg == 1)
	{
	  i[X] = base[X]; i[Y] = base[Y]; j[X] = one[X]; j[Y] = one[Y];
	  testPoint(one, c, d, pTest);
	}
      else
	{
	  j[X] = base[X]; j[Y] = base[Y]; i[X] = one[X]; i[Y] = one[Y];		
	  testPoint(one, a, b, pTest);
	};
      
      if (inCircle(base, e, one, pTest) == 1) return TRUE;
    }

  return FALSE;
}
/************************************************************************************/
int case3(int flag, int order, pointType a, pointType b, pointType c, 
          pointType d, pointType e, pointType one, pointType two, pointType cen)

/* This subroutine tries to find a circle that goes through E and touches AB and CD at 
 * their endpoints without containing the rest of the line segments.
 * flag = ONE ==> case 3 for oneSegment
 *        TWO ==> case 3 for twoSegment
 * 'one' is either A or B
 * 'two' is either C or D
 *
 * This subroutine returns TRUE if such a circle exists, FALSE otherwise.
 */
{
  pointType test1, test2;
  int inCircle1, inCircle2;

  if (order == ZERO)
    {
      if (!counterClock(e, one, two)) return FALSE;
    }
  else if (order == ONE)
    {
      if (!counterClock(one, e, two)) return FALSE;
    }
  else if (!counterClock(one, two, e)) return FALSE;

  testPoint(one, a, b, test1);
  inCircle1  = inCircle(e, one, two, test1);

  if (flag == TWO) 
    {
      testPoint(two, c, d, test2);
      inCircle2 = inCircle(e, one, two, test2);
    }
  else inCircle2 = 1;

  if ((inCircle1 == 1) && (inCircle2 == 1))
    {
      if (!threePointCircle(e, one, two, cen)) return FALSE;
      else return TRUE;
    }
  else return FALSE;
}


/*************************************************************************************/
int twoSegment(int line, int order, Boolean checkDegen,pointType a, pointType b,
               pointType c, pointType d, pointType e, pointType possibleF, 
               pointType center, 
               pointType i, pointType j)

/* See comments at the beginning of the program */
{
  int result;
  pointType co1, co2, one, two;
  coType longest;
  int flag = TRUE;

  if (checkDegen == True) {
	if (SAME_POINT(e,a) || SAME_POINT(e,b)) {
	  return pointOnSegEnd2ndIsSeg(GEOM_CCW, a, b, c, d, e, possibleF, center, i, j);
	} else if (SAME_POINT(e,c) || SAME_POINT(e,d)) {
	  return pointOnSegEnd2ndIsSeg(GEOM_CW, c, d, a, b, e, possibleF, center, j, i);
	} else if (SAME_POINT(a,c) || SAME_POINT(a,d) ||
			   SAME_POINT(b,c) || SAME_POINT(b,d)){ 
	  return segOnSegEnd2ndIsPoint (GEOM_CCW, a, b, c, d, e, center, i, j);
	}
  }

  /* If checkDegen == True then we only fall through to here
     if there really isn't a degeneracy.  Otherwise, we have a
     return statement covering us. 
  */

	if (!validity(TWO, a, b, c, d, e)) return -1;

	center[W] = i[W] = j[W] = 1.0;
	normalized (a, b, co1);
	normalized (c, d, co2);

	/* Try case 1 */

	if ((co1[A]*e[X] + co1[B]*e[Y] + co1[C])*(co2[A]*e[X] + co2[B]*e[Y] + co2[C]) < 0.0)
	  {
		co1[A] = -co1[A]; co1[B] = -co1[B]; co1[C] = -co1[C]; 
		flag = FALSE;
	  };
	
	result = case1 (line, order, co1, co2, a, b, c, d, e, center, i, j) ;
	if (result) return ONE;
	
	if (!flag)  /* Switch co1 back */
	  {
		co1[A] = -co1[A]; co1[B] = -co1[B]; co1[C] = -co1[C]; 
		flag = TRUE;
	  };
	
	/*  Try case 2 */
	if (line != TWO)
	  {
		result = case2(1, line, order, co1, a, b, c, d, e, c, center, i, j);
		if (result) return TWO;
	
		result = case2(1, line, order, co1, a, b, c, d, e, d, center, i, j);
		if (result) return TWO;
	  };
	if (line != ONE)
	  {
		result = case2(2, line, order, co2, a, b, c, d, e, a, center, i, j);
		if (result) return TWO;
	
		result = case2(2, line, order, co2, a, b, c, d, e, b, center, i, j);
		if (result) return TWO;
	  };

	/* Try case 3 */
	if (!line)  /* case 3 only works when both are line segments */
	  {
		result = case3(TWO, order, a, b, c, d, e, a, c, center);
		if (result)
	  {
		i[X] = a[X]; i[Y] = a[Y];
		j[X] = c[X]; j[Y] = c[Y];
		return THREE;
	  };
		result = case3(TWO, order, a, b, c, d, e, a, d, center);
		if (result)
	  {
		i[X] = a[X]; i[Y] = a[Y];
		j[X] = d[X]; j[Y] = d[Y];
		return THREE;
	  };
		result = case3(TWO, order, a, b, c, d, e, b, c, center);
		if (result)
	  {
		i[X] = b[X]; i[Y] = b[Y];
		j[X] = c[X]; j[Y] = c[Y];
		return THREE;
	  };
		result = case3(TWO, order, a, b, c, d, e, b, d, center);
		if (result)
	  {
		i[X] = b[X]; i[Y] = b[Y];
		j[X] = d[X]; j[Y] = d[Y];
		return THREE;
	  }
	  };

	/* NO SOLUTION -- FIND THE DIRECTION OF INFINITY */

	center[W] = 0.0;
	if (line == ONE) 
	  {
		center[X] = co1[B]; center[Y] = -co1[A];
	  }
	else if (line == TWO)
	  {
		center[X] = co2[B]; center[Y] = -co2[A];
	  }
	else 
	  {
		if (!counterClock(c, e, a)) 
	  {
		one[X] = c[X]; one[Y] = c[Y]; two[X] = a[X]; two[Y] = a[Y];
	  }
		else if (!counterClock(d, e, a)) 
	  {
		one[X] = d[X]; one[Y] = d[Y]; two[X] = a[X]; two[Y] = a[Y];
	  }
		else if (!counterClock(d, e, b)) 
	  {
		one[X] = d[X]; one[Y] = d[Y]; two[X] = b[X]; two[Y] = b[Y];
	  }
		else if (!counterClock(c, e, b)) 
	  {
		one[X] = c[X]; one[Y] = c[Y]; two[X] = b[X]; two[Y] = b[Y];
	  }

		longest = (one[X]-two[X])*(one[X]-two[X])+(one[Y]-two[Y])*(one[Y]-two[Y]);
		center[X] = one[X]-two[X]; center[Y] = one[Y] - two[Y];

		if (longest < (e[X]-two[X])*(e[X]-two[X])+(e[Y]-two[Y])*(e[Y]-two[Y]))
	  center[X] = e[X]-two[X]; center[Y] = e[Y] - two[Y];

		if (longest < (e[X]-one[X])*(e[X]-one[X])+(e[Y]-one[Y])*(e[Y]-one[Y]))
	  center[X] = e[X]-one[X]; center[Y] = e[Y] - one[Y];
	  };

  return ZERO;  /* FIND A WAY TO REPRESENT THE DIRECTION OF INFINITY ..... */
}

/************************************************************************************/

int inTwoSegment(int line, int order, pointType point[6], pointType center, 
                 pointType i, pointType j)

/* This is twoSegment, but only case1 is considered */
{
  int result;
  pointType co1, co2;
  
  if (!validity(TWO, point[1], point[2], point[3], point[4], point[5])) return -1;

  center[W] = i[W] = j[W] = 1.0;
  normalized (point[1], point[2], co1);
  normalized (point[3], point[4], co2);

  result = case1 (line, order, co1, co2, point[1], point[2], point[3], point[4], 
		  point[5], center, i, j) ;

  if (result) return ONE;
  else 
    {
      pType temp;
      temp[A] = -co1[A]; temp[B] = -co1[B]; temp[C] = -co1[C];

      result = case1 (line, order, temp, co2, point[1], point[2], point[3], point[4], 
		      point[5], center, i, j) ;
      if (result) return ONE;
      else return ZERO;
    }
}

/************************************************************************************/
int oneSegment(int line, int order, pointType a, pointType b, 
               pointType c, pointType e, pointType center, pointType i)

/* See comments at the beginning of the program */
{
  pointType  co, one, two;
  coType longest;
  int result;

  if (SAME_POINT(a, c) || SAME_POINT(b, c)) {
    return pointOnSegEnd2ndIsPoint ((order == ONE ? GEOM_CW : GEOM_CCW), 
                          a, b, c, e, center, i);
  } else if (SAME_POINT(a, e) || SAME_POINT(b, e)) {
    return pointOnSegEnd2ndIsPoint ((order == ONE ? GEOM_CW : GEOM_CCW), 
                          a, b, e, c, center, i);
  } else {
	if (!validity(ONE, a, b, c, c, e)) return -1;

	center[W] = i[W] = 1.0;
	normalized (a, b, co);

	/* Try case 2 */
	result = ground2(line, order, TRUE, co, a, b, e, c, center, i);
	if (result) return TWO;

	if (!line) /* AB is a real line segment, check to see if case3 works. */
	  {
		result = case3(ONE, order, a, b, c, c, e, a, c, center);
		if (result)
	  {
		i[X] = a[X]; i[Y] = a[Y];
		return THREE;
	  };
		result = case3(ONE, order, a, b, c, c, e, b, c, center);
		if (result)
	  {
		i[X] = b[X]; i[Y] = b[Y];
		return THREE;
	  }
	  }
	/* NO SOLUTION */
	center[W] = 0.0;
   if (line) 
	  {
		center[X] = co[B]; center[Y] = -co[A];
	  }
	else 
	  {
		if (!counterClock(c, e, a)) 
	  {
		one[X] = c[X]; one[Y] = c[Y]; two[X] = a[X]; two[Y] = a[Y];
	  }
		else if (!counterClock(c, e, b)) 
	  {
		one[X] = c[X]; one[Y] = c[Y]; two[X] = b[X]; two[Y] = b[Y];
	  }

		longest = (one[X]-two[X])*(one[X]-two[X])+(one[Y]-two[Y])*(one[Y]-two[Y]);
		center[X] = one[X]-two[X]; center[Y] = one[Y] - two[Y];

		if (longest < (e[X]-two[X])*(e[X]-two[X])+(e[Y]-two[Y])*(e[Y]-two[Y]))
	  center[X] = e[X]-two[X]; center[Y] = e[Y] - two[Y];

		if (longest < (e[X]-one[X])*(e[X]-one[X])+(e[Y]-one[Y])*(e[Y]-one[Y]))
	  center[X] = e[X]-one[X]; center[Y] = e[Y] - one[Y];
	  };
	
	return ZERO;
  }
}
  /* Try case 2 */
/****************************************************************************/
int inOneSegment(int line, int order, pointType point[5], pointType center, 
                 pointType i)

/* This is same as 'oneSegment' but only case 2 is considered */
{
  pointType  co;
  int result;
    
  if (!validity(ONE, point[1], point[2], point[3], point[3], point[4])) return -1;

  center[W] = i[W] = 1.0;
  normalized (point[1], point[2], co);

  result = ground2(line, order, TRUE, co, point[1], point[2], point[4], point[3], 
		   center, i);
 
 if (result) return TWO;
  else return ZERO;
}

/****************************************************************************/

int inThreeSegment(pType point[7], pType center, pType i, pType j, pType k)

/* See comments at the beginning of the program */

{
  pType para[4], co1, co2;
  int result;

  normalized(point[1], point[2], para[1]);
  normalized(point[3], point[4], para[2]);
  normalized(point[5], point[6], para[3]);

  /* Try option #1 */
  co1[A] = para[1][A] - para[2][A];
  co1[B] = para[1][B] - para[2][B];
  co1[C] = para[2][C] - para[1][C];
  
  co2[A] = para[2][A] - para[3][A];
  co2[B] = para[2][B] - para[3][B];
  co2[C] = para[3][C] - para[2][C];

  result = cramer(co1, co2, center);

  if (shortest(FALSE, point[1], point[2], para[1], center, i)
      && shortest(FALSE, point[3], point[4], para[2], center, j)
      && shortest(FALSE, point[5], point[6], para[3], center, k))
    {
      if (counterClock(i, j, k)) return TRUE;
    };

  /* Try option #2 */

  co2[A] = para[2][A] + para[3][A];
  co2[B] = para[2][B] + para[3][B];
  co2[C] = - para[3][C] - para[2][C];

  result = cramer(co1, co2, center);

  if (shortest(FALSE, point[1], point[2], para[1], center, i)
      && shortest(FALSE, point[3], point[4], para[2], center, j)
      && shortest(FALSE, point[5], point[6], para[3], center, k))
    {
      if (counterClock(i, j, k)) return TRUE;
    };
  /* Try option #4 */

  co1[A] = para[1][A] + para[2][A];
  co1[B] = para[1][B] + para[2][B];
  co1[C] = - para[2][C] - para[1][C];

  result = cramer(co1, co2, center);

  if (shortest(FALSE, point[1], point[2], para[1], center, i)
      && shortest(FALSE, point[3], point[4], para[2], center, j)
      && shortest(FALSE, point[5], point[6], para[3], center, k))
    {
      if (counterClock(i, j, k)) return TRUE;
    };

  /* Try option #3 */

  co2[A] = para[2][A] - para[3][A];
  co2[B] = para[2][B] - para[3][B];
  co2[C] = para[3][C] - para[2][C];
  
  result = cramer(co1, co2, center);
  
  if (shortest(FALSE, point[1], point[2], para[1], center, i)
      && shortest(FALSE, point[3], point[4], para[2], center, j)
      && shortest(FALSE, point[5], point[6], para[3], center, k))
    {
      if (counterClock(i, j, k)) return TRUE;
    };

  return FALSE;
}

/****************************************************************************/

int threeSegmentOneEnd(pType point[7], pType center, pType i, pType j, pType k)
{
  pType vectorEF, radiusVector;

  vectorEF[W] = 1.0;
  vectorEF[X] = point[6][X] - point[5][X];
  vectorEF[Y] = point[6][Y] - point[5][Y];

  if (twoSegment (FALSE, ZERO, True, point[1], point[2], point[3], point[4], 
         point[5], point[6], center, i, j) > 0) {
    radiusVector[W] = 1.0;
    radiusVector[X] = center[X] - point[5][X];
    radiusVector[Y] = center[Y] - point[5][Y];
    if ((vectorEF[X]*radiusVector[X] + vectorEF[Y]*radiusVector[Y]) <= 0) {
      k[W] = 1.0;
      k[X] = point[5][X];
      k[Y] = point[5][Y];
      return TRUE;
    }
  }

  if (twoSegment (FALSE, ZERO, True, point[1], point[2], point[3], point[4], 
         point[6], point[5], center, i, j) > 0) {
    radiusVector[W] = 1.0;
    radiusVector[X] = center[X] - point[6][X];
    radiusVector[Y] = center[Y] - point[6][Y];
    if ((vectorEF[X]*radiusVector[X] + vectorEF[Y]*radiusVector[Y]) >= 0) {
      k[W] = 1.0;
      k[X] = point[6][X];
      k[Y] = point[6][Y];
      return TRUE;
    }
  }

  return inThreeSegment(point, center, i, j, k);
}

#define TransferPoint(To,From) \
  To[W] = From[W];\
  To[X] = From[X];\
  To[Y] = From[Y];

void
rotateLines(pType point[7])
{
  pType oldStart, oldEnd;

  TransferPoint(oldStart, point[1]);
  TransferPoint(oldEnd, point[2]);

  /* Do the shuffle. */

  TransferPoint(point[1], point[3]);
  TransferPoint(point[2], point[4]);
  TransferPoint(point[3], point[5]);
  TransferPoint(point[4], point[6]);
  TransferPoint(point[5], oldStart);
  TransferPoint(point[6], oldEnd);
}

int threeSegment(pType point[7], pType center, pType i, pType j, pType k)
{
  if (threeSegmentOneEnd(point, center, i, j, k)) {
    return TRUE;
  } else {
    rotateLines(point);
    if (threeSegmentOneEnd(point, center, j, k, i)) {
      return TRUE;
    }else {
      rotateLines(point);
      return threeSegmentOneEnd(point, center, k, i, j);
    }
  }
}

/**************************************************************************/
/*                               END OF SUB.C                             */
/**************************************************************************/



