
#ifndef _frontAlarms_h_
#define _frontAlarms_h_

#include "subsystems.h"
#include "alarm.h"

#define FRONT_BaseAlarm      AL_BaseAlarm(SYS_SweepFront)
#define FRONT_BaseFunction   AL_BaseAlarm(SYS_SweepFront)

#define AL_Id_FRONT_NoMainMemory         (FRONT_BaseAlarm + 0x01)
#define AL_Id_FRONT_NoArcMemory          (FRONT_BaseAlarm + 0x02)
#define AL_Id_FRONT_NullFront            (FRONT_BaseAlarm + 0x03)
#define AL_Id_FRONT_MoveBadDirection     (FRONT_BaseAlarm + 0x04)
#define AL_Id_FRONT_NullSite             (FRONT_BaseAlarm + 0x05)
#define AL_Id_FRONT_BadLoadState         (FRONT_BaseAlarm + 0x06)
#define AL_Id_FRONT_NullArc              (FRONT_BaseAlarm + 0x07)
#define AL_Id_FRONT_ArcInWrongFront      (FRONT_BaseAlarm + 0x08)

#define AL_Fn_FRONT_Free                 (FRONT_BaseFunction + 0x01)
#define AL_Fn_FRONT_Advance              (FRONT_BaseFunction + 0x02)
#define AL_Fn_FRONT_LoadSite             (FRONT_BaseFunction + 0x03)
#define AL_Fn_FRONT_NewSite              (FRONT_BaseFunction + 0x04)
#define AL_Fn_FRONT_RemoveArc            (FRONT_BaseFunction + 0x05)
#define AL_Fn_FRONT_PrevForSite          (FRONT_BaseFunction + 0x06)
#define AL_Fn_FRONT_NextForSite          (FRONT_BaseFunction + 0x07)
#define AL_Fn_FRONT_ArcFree              (FRONT_BaseFunction + 0x08)
#define AL_Fn_FRONT_FindProjection       (FRONT_BaseFunction + 0x09)
#define AL_Fn_FRONT_ArcCompare           (FRONT_BaseFunction + 0x0a)
#define AL_Fn_FRONT_ScheduleVoronoi      (FRONT_BaseFunction + 0x0b)
#define AL_Fn_FRONT_ScheduleMiddle       (FRONT_BaseFunction + 0x0c)
#define AL_Fn_FRONT_NewArcEvents         (FRONT_BaseFunction + 0x0d)

#endif

