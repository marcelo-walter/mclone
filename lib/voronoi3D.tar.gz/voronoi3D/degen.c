#include "sub.h"
#include "main.h"
#include "geometry.h"
#include "distance.h"


/* We have a segment AB with points c and e.  Point c is identical
   to either A or B.  Find the voronoi point (center) and the 
   attachment point to the segment, if it exists. */
 
int
pointOnSegEnd2ndIsPoint (GEOM_DirectionType direction,
                         pointType a, pointType b, pointType c, pointType e,
                         pointType center, pointType i)
{
  Pt     sharePt, otherSegPt, otherPt, vor;
  HOMOG  line, perp;
  GEOM_DirectionType realDir;

  /* Find the line that goes through the shared endpoint and
     is perpendicular to our line segment. */

  sharePt.w = 1.0;  sharePt.x = c[X];  sharePt.y = c[Y];
  otherSegPt.w = 1.0;
  if (SAME_POINT(a,c)) {
	otherSegPt.x = b[X];  otherSegPt.y = b[Y];
  } else {
	otherSegPt.x = a[X];  otherSegPt.y = a[Y];
  }

  CROSS_2CCH (&otherSegPt, &sharePt, &line);
  PERP_C (&line, &sharePt, &perp);

  /* A Voronoi vertex exists only if the non-shared point lies
     to the left of the perpenducular line (the other side from
     the non-shared segment end).

     This does NOT take into account the desired direction/orientation
     of the sites around the Voronoi vertex. */

  otherPt.w = 1.0;  otherPt.x = e[X];  otherPt.y = e[Y];

  if (DOT_2CH(&otherPt, &perp) >= 0) {
    /* We have a Voronoi vertex (actually, an entire line of them.
       Choose the one at the midpoint between the two point vertices
       since it's easy to compute. */

	MidPoint (sharePt, otherPt, vor);
	center[W] = 1.0;  center[X] = XVal(vor);  center[Y] = YVal(vor);
	i[W] = 1.0; i[X] = c[X]; i[Y] = c[Y];

#if 1
    /* TBD -- I'm not sure that the caller of this routine knows 
       about the order yet. */

    /* Make sure that the direction is appropriate. */

    CROSS_2CCH (&otherPt, &sharePt, &line);
    realDir = (DOT_2CH (&otherSegPt, &line) >= 0 ? GEOM_CW : GEOM_CCW);
    if (realDir == direction) {
	  return ONE;
    } else {
      return ZERO;
    }
#else
    return ONE;
#endif
  }

  return ZERO;
}

/* We have a segments AB and CD with point e.  Point e is identical
   to either A or B.  Find the voronoi point (center) and the 
   attachment point to the segment AB (i) and segment CD (j), if the 
   Voronoi point exists. */
 
int
pointOnSegEnd2ndIsSeg (GEOM_DirectionType direction,
                       pointType a, pointType b, pointType c, pointType d, 
                       pointType e, pointType f, pointType center, pointType i,
                       pointType j)
{
  Pt     sharePt, otherSegPt, vor, newC, newD, newF;
  Pt     cand1, cand2, *nearPt;
  HOMOG  line, perp, cdLine;
  Parabola  para;
  int    cand1Side, end;
  Vector radiusVector, lineVector;
  Boolean definedByCD = False;

  /* Find the line that goes through the shared endpoint and
     is perpendicular to our line segment. */

  sharePt.w = 1.0;  sharePt.x = e[X];  sharePt.y = e[Y];
  otherSegPt.w = 1.0;
  if (SAME_POINT(a,e)) {
	otherSegPt.x = b[X];  otherSegPt.y = b[Y];
  } else {
	otherSegPt.x = a[X];  otherSegPt.y = a[Y];
  }

  CROSS_2CCH (&otherSegPt, &sharePt, &line);
  PERP_C (&line, &sharePt, &perp);

  /* A Voronoi vertex exists only if some part of the segment CD lies
     to the left of the perpenducular line (the other side from
     the non-shared segment end).

     This does NOT take into account the desired direction/orientation
     of the sites around the Voronoi vertex. */

  newC.w = 1.0;  newC.x = c[X];  newC.y = c[Y];
  newD.w = 1.0;  newD.x = d[X];  newD.y = d[Y];

  i[W] = 1.0; i[X] = e[X]; i[Y] = e[Y];

  cand1Side = LineSide (&perp, &otherSegPt);
  if ((LineSide(&perp, &newC) != cand1Side) || 
      (LineSide(&perp, &newD) != cand1Side)) {

    CROSS_2CCH (&newC, &newD, &cdLine);
    createParabola (&sharePt, &cdLine, &para);
    intersectLineParabola (&perp, &para, &cand1, &cand2);

    /* Pretend that we have pulled the segment back a bit.
       The Voronoi vertex will be on the line perpendicular to
       the sharing segment, through the shared point, and on the
       side of the segment that gives the right order under the
       retraction assumption. */

    if (direction == GEOM_CCW) {
      cand1Side = RightSide;
    } else {
      cand1Side = LeftSide;
    }

    if (LineSide(&line, &cand1) == cand1Side) {
      PointAssign (vor, cand1);
    } else {
      PointAssign (vor, cand2);
    }

    /* Make sure that the candidate falls within the segment. */

    if (pastSegmentBounds (&vor, &newC, &newD, &end) == True) {
      /* Use the line through the closer end to intersect the parabola.  */

      definedByCD = True;
      nearPt = (end == 0 ? &newC : &newD);
      PERP_C (&cdLine, nearPt, &perp);
      
      intersectLineParabola (&perp, &para, &cand1, &cand2);
      /* Since the line is perpendicular to the directrix, there is only
         one distinct intersection point. */
      
      PointAssign (vor, cand1);

      /* Make sure that the order is the one that we want. */

#if 0
      LineOf(&vor, &sharePt, &line);

      if (direction == GEOM_CCW) {
/* mjm switched right and left sides in here recently. */
        if (LineSide (&line, &otherSegPt) == LeftSide) {
          return ZERO;
        }
      } else {
        if (LineSide (&line, &otherSegPt) == RightSide) {
          return ZERO;
        }
      }
#else
      LineOf(&otherSegPt, &sharePt, &line);
      if (f == NULL) {
        if (LineSide(&line, &vor) == LeftSide) {
          if (direction == GEOM_CW) {
            return ZERO;
          }
        } else {
          if (direction == GEOM_CCW) {
            return ZERO;
          }
        }
      } else {
        /* We have a third point to compare with. */
        newF.w = 1.0;  newF.x = f[X];  newF.y = f[Y];
        if (LineSide(&line, &newF) == RightSide) {
          if (direction == GEOM_CCW) {
            return ZERO;
          }
        } else {
          if (direction == GEOM_CW) {
            return ZERO;
          }
        }
      }
#endif
    }

    center[X] = XVal(vor);
    center[Y] = YVal(vor);
    center[W] = 1.0;

    /* Finally, make sure that the Voronoi circle doesn't cut through
       segment AB. */

    if (definedByCD == True) {
      SubPoints (vor, sharePt, radiusVector);
      SubPoints (otherSegPt, sharePt, lineVector);
      if (XVal(radiusVector)*XVal(lineVector) +
          YVal(radiusVector)*YVal(lineVector) > 0) {
        /* There is some overlap so the segment cuts the circle. */
        return ZERO;
      } else {
        j[W] = 1.0; j[X] = XVal(*nearPt); j[Y] = YVal(*nearPt);
        return ONE;
      }
    } else {
      Pt  intPt;
      /* CD and the point defined the parabola and AB to the radius
         is a perfect 90 degrees by construction.  We can't go wrong. */
      PERP_C (&cdLine, &vor, &perp);
      IntersectionOf (&perp, &cdLine, &intPt);
      j[W] = 1.0; j[X] = XVal(intPt); j[Y] = YVal(intPt);
      return ONE;
    }
  } 

  return ZERO;
}


/* We have a segments AB and CD with point e.  Segments AB and CD share
   an endpoint.  Find the voronoi point (center) and the shared
   point i between the segments.  This routine assumes that you
   want to find the Voronoi vertex that involves both segments at
   the shared point. */

int
segOnSegEnd2ndIsPoint (GEOM_DirectionType direction,
                       pointType a, pointType b, pointType c, pointType d, 
                       pointType e, pointType center, pointType i,
                       pointType j)
{
  Pt     sharePt, otherPt, otherPtAB, otherPtCD, vor;
  HOMOG  botLine, lineAB, lineCD, perpAB, perpCD;
  GEOM_DirectionType realDir;
  Boolean ccwOrder;

  /* Find the common point between the line segments. */

  if (SAME_POINT(a,c)) {
    sharePt.w = 1.0;  sharePt.x = a[X];  sharePt.y = a[Y];
    otherPtAB.w = 1.0;  otherPtAB.x = b[X];  otherPtAB.y = b[Y];
    otherPtCD.w = 1.0;  otherPtCD.x = d[X];  otherPtCD.y = d[Y];
  } else if (SAME_POINT(a,d)) {
    sharePt.w = 1.0;  sharePt.x = a[X];  sharePt.y = a[Y];
    otherPtAB.w = 1.0;  otherPtAB.x = b[X];  otherPtAB.y = b[Y];
    otherPtCD.w = 1.0;  otherPtCD.x = c[X];  otherPtCD.y = c[Y];
  } else if (SAME_POINT(b,c)) {
    sharePt.w = 1.0;  sharePt.x = b[X];  sharePt.y = b[Y];
    otherPtAB.w = 1.0;  otherPtAB.x = a[X];  otherPtAB.y = a[Y];
    otherPtCD.w = 1.0;  otherPtCD.x = d[X];  otherPtCD.y = d[Y];
  } else {
    sharePt.w = 1.0;  sharePt.x = b[X];  sharePt.y = b[Y];
    otherPtAB.w = 1.0;  otherPtAB.x = a[X];  otherPtAB.y = a[Y];
    otherPtCD.w = 1.0;  otherPtCD.x = c[X];  otherPtCD.y = c[Y];
  }

  /* Find the lines perpendicular to AB and CD through the
     shared point.  These lines delineate the set of possible
     positions for e. */

  CROSS_2CCH (&otherPtAB, &sharePt, &lineAB);
  PERP_C (&lineAB, &sharePt, &perpAB);
  CROSS_2CCH (&otherPtCD, &sharePt, &lineCD);
  PERP_C (&lineCD, &sharePt, &perpCD);

  /* A Voronoi vertex exists only if point e is to the left of both
     perpendicular lines. 

     This does NOT take into account the desired direction/orientation
     of the sites around the Voronoi vertex. */

  otherPt.w = 1.0; otherPt.x = e[X];  otherPt.y = e[Y];

  if ((LineSide(&perpAB, &otherPt) != LineSide (&perpAB, &otherPtAB)) &&
      (LineSide(&perpCD, &otherPt) != LineSide (&perpCD, &otherPtCD))) {
    /* We have a Voronoi vertex (actually, an entire line of them.
       Choose the one at the midpoint between the two point vertices
       since it's easy to compute. */

	MidPoint (sharePt, otherPt, vor);
	center[W] = 1.0;  center[X] = XVal(vor);  center[Y] = YVal(vor);
	i[W] = 1.0; i[X] = XVal(sharePt); i[Y] = YVal(sharePt);
	j[W] = 1.0; j[X] = i[X]; j[Y] = i[Y];

    /* Make sure that the circle is going in the right direction */

    realDir = (pointsCCW(&otherPt, &otherPtAB, &otherPtCD) == True ?
                GEOM_CCW : GEOM_CW);
    if (realDir == direction) {
      return ONE;
    } else {
      return ZERO;
    }
  }

  /* The Voronoi point may not use the common point after all. */

  /* There is a possible point if
	 1. point e is below the line formed by the distinct ends of the
		line segments.
	 2. point e is inside the wedge formed by the line segments. 
  */

  CROSS_2CCH (&otherPtAB, &otherPtCD, &botLine);
  if ((LineSide(&botLine, &sharePt) != LineSide(&botLine, &otherPt)) ||
	  (
	   (LineSide(&lineAB, &otherPt) == LineSide(&lineAB, &otherPtCD)) &&
	   (LineSide(&lineCD, &otherPt) == LineSide(&lineCD, &otherPtAB))
	  )) {
	if (direction == GEOM_CCW) {
	  return twoSegment(FALSE, ZERO, False, a, b, c, d, e, NULL, center, i, j);
	} else {
	  return twoSegment(FALSE, ZERO, False, c, d, a, b, e, NULL, center, i, j);
	}
  }

  /* The single point e is hidden from one of the edges by the other
     edge.  A Voronoi vertex is still possible. */

  ccwOrder = pointsCCW (&otherPtAB, &sharePt, &otherPtCD);
  if (((ccwOrder == False) && (direction == GEOM_CCW)) ||
      ((ccwOrder == True) && (direction == GEOM_CW))) {
    Real distAB, distCD;
    Pt   nearAB, nearCD, cand1, cand2;
    Parabola para;

    /* Find the nearer of the two edges. */

    ptNearestSegment (&otherPt, &sharePt, &otherPtAB, &nearAB);
    ptNearestSegment (&otherPt, &sharePt, &otherPtCD, &nearCD);
    squarePointDistance (&otherPt, &nearAB, &distAB);
    squarePointDistance (&otherPt, &nearCD, &distCD);
    if (distAB < distCD) {
      /* AB hides CD */
      createParabola (&otherPt, &lineAB, &para);
      intersectLineParabola (&perpAB, &para, &cand1, &cand2);
      PointAssign (vor, cand1);
    } else {
      /* CD hides AB */
      createParabola (&otherPt, &lineCD, &para);
      intersectLineParabola (&perpCD, &para, &cand1, &cand2);
      PointAssign (vor, cand1);
    }

	center[W] = 1.0;  center[X] = XVal(vor);  center[Y] = YVal(vor);
	i[W] = 1.0; i[X] = XVal(sharePt); i[Y] = YVal(sharePt);
	j[W] = 1.0; j[X] = i[X]; j[Y] = i[Y];

    return ONE;
  }

  return ZERO;
}




