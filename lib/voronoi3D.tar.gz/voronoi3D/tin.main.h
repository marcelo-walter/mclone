
/*
 * NAME    : TIN VAN NGUYEN                                                 
 * DATE    : July 13, 1995                    
 * FILENAME: main.h
 * PROJECT : THE MEDIAL AXIS OF A N-SIMPLE POLYGON                          
 * PAPER   : This is an implementation of D.T. Lee's paper of the same      
 *           title published in IEEE Transactions on Pattern Analysis and
 *           Machine Intelligence, Vol. PAMI-4, NO. 4, July 1982.
 *           
 *   This header file contains data structure declarations, define macros
 * for other source files.
 */

#include <stdio.h>
#include <math.h>
#ifdef SGI
#include <gl/gl.h>
#endif
#include "sub.h"

/* DEFINE CONSTANT        */

#define VER         1           /* => element is a reflex vertex  */
#define SEG         2           /* => element is a segment        */
#define X           0
#define Y           1
#define W           2
#define NO_DECISION 999

#define INFINITY 10E16

#define GROUND WHITE
#define BISECT BLACK


/* DEFINE DATA STRUCTURE */
/* Reminder: 
 * typedef double coType;
 * typedef coType pType[3];
 */

/* STRUCTURE FOR VORONOI REGIONS */
typedef struct VORONOI_EDGE voType;
struct VORONOI_EDGE {
  voType *pre;     /* points to the previous edge on the boundary        */
  short neighbor;  /* B(id, neighbor) is the bisector bearing this edge  */
  short mode;      /* 0: normal; 1: left point only; 2: right point only */
  pType start;     /* starting point of the edge in CCW                  */
  pType end;       /* ending point of the edge   in CCW                  */
  voType *next;    /* points to the next edge on the boundary            */
};

/* STRUCTURE FOR ELEMENTS */
typedef struct ELEMENT eleType;
struct ELEMENT {
  eleType *pre;        /* points to the previous element on ele's list   */
  short   kind;        /* VER or SEG                                     */
  short   id;          /* its index on eleArray                          */
  pType   start;       /* co. of reflex vertex or starting point of SEG  */
  pType   end;         /* co. of end point of SEG                        */
  voType *voHead;      /* points to its first voronoi edge in CCW        */
  voType *voTail;      /* -----------------------------------  CW        */
  eleType *next;       /* points to the next element on element list     */
};

/* STRUCTURE FOR CHAINS */
typedef struct CHAIN chType;
struct CHAIN {
  int head;             /* first element on chain in CCW                 */
  int tail;             /* last element on chain in CCW                  */
  chType *next;         /* points to the next chain                      */
};

/* DEFINE MACROS */

#define ELEMENT_TYPE(e)   (e->kind)
#define ELEMENT_ID(e)     (e->id)
#define ELEMENT_START(e)  (e->start)
#define ELEMENT_END(e)    (e->end)
#define ELEMENT_PRE(e)    (e->pre)
#define ELEMENT_NEXT(e)   (e->next)
#define ELEMENT_VOHEAD(e) (e->voHead)
#define ELEMENT_VOTAIL(e) (e->voTail)

#define CHAIN_HEAD(c) (c->head)
#define CHAIN_TAIL(c) (c->tail)
#define CHAIN_NEXT(c) (c->next)

#define VORONOI_PRE(v)      (v->pre)
#define VORONOI_NEXT(v)     (v->next)
#define VORONOI_START(v)    (v->start)
#define VORONOI_END(v)      (v->end)
#define VORONOI_NEIGHBOR(v) (v->neighbor)
#define VORONOI_MODE(v)     (v->mode)

/* DEFINE EXTERNAL SUBROUTINES */

extern eleType *Emalloc();
extern void Efree(eleType *e);
extern eleType *Eappend(eleType *i, eleType *j);

extern chType *Cmalloc();
extern void Cfree(chType *c);
extern chType *Cappend(chType *i, chType *j);

extern voType *Vmalloc();
extern void Vfree(voType *v);
extern voType *Vappend(voType *i, voType *j);

extern void EQUATE_POINT(pType a, pType b);
extern int inside(pType start, pType end, pType test);
extern coType sDistance(pType one, pType two);
extern void voronoiSegment(pType start, pType end, pType first, pType last);

/**********************************************************************/
/*                    THIS IS THE END OF MAIN.H                       */
/**********************************************************************/
