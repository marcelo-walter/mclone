
#include <stdlib.h>

#include "globals.h"
#include "clist.h"
#ifdef enableAlarms
#include "clistAlarms.h"
#include "alarm.h"
#endif /* enableAlarms */

CLIST_NodeType 
CLIST_NewNode (Ptr userDataPtr)
{
  CLIST_NodeType theNodePtr;

  theNodePtr = (CLIST_NodeType) malloc(sizeof(_CLIST_NodeInfoType));
  if (theNodePtr == NULL) {
    theNodePtr = CLIST_NullNode;
  } else {
#ifdef paranoid
    theNodePtr->headGuard = _CLIST_HeadTag;
    theNodePtr->tailGuard = _CLIST_TailTag;
#endif
    theNodePtr->previous = theNodePtr;
    theNodePtr->next = theNodePtr;
    theNodePtr->dataPtr = userDataPtr;
  }

  return theNodePtr;
}

void 
CLIST_FreeNode (CLIST_NodeType theNode)
{
#ifdef paranoidCheck
  if (CLIST_Audit (theNode) == True) {
#endif

    if (theNode != CLIST_NullNode) {
#ifdef paranoid
      theNode->headGuard = 0;
      theNode->tailGuard = 0;
#endif
      free (theNode);
    }

#ifdef paranoidCheck
  }
#endif
}

CLIST_NodeType 
CLIST_Previous (CLIST_NodeType theNode)
{
  CLIST_NodeType prevPtr = CLIST_NullNode;

#ifdef paranoidCheck
  if (CLIST_Audit(theNode) == True) {
#endif

    if (theNode != CLIST_NullNode) {
      prevPtr = theNode->previous;
    }

#ifdef paranoidCheck
  }
#endif

  return prevPtr;
}

CLIST_NodeType 
CLIST_Next (CLIST_NodeType theNode)
{
  CLIST_NodeType nextPtr = CLIST_NullNode;

#ifdef paranoidCheck
  if (CLIST_Audit(theNode) == True) {
#endif

    if (theNode != CLIST_NullNode) {
      nextPtr = theNode->next;
    }

#ifdef paranoidCheck
  }
#endif

  return nextPtr;
}


Ptr 
CLIST_GetData (CLIST_NodeType theNode)
{
  Ptr dataPtr = NULL;

#ifdef paranoidCheck
  if (CLIST_Audit(theNode) == True) {
#endif

    if (theNode != CLIST_NullNode) {
      dataPtr = theNode->dataPtr;
    }

#ifdef paranoidCheck
  }
#endif

  return dataPtr;
}

Boolean 
CLIST_MergeCycles (CLIST_NodeType node1, CLIST_NodeType node2)
{
  Boolean         mergeOk = False;
  CLIST_NodeType  holdPtr;

#ifdef paranoidCheck
  if ((CLIST_Audit(node1) == True) && (CLIST_Audit(node2) == True)) {
#endif

    if ((node1 != CLIST_NullNode) && (node2 != CLIST_NullNode)) {
      /* The case of single chains is best handled separately so we
         don't trounce our own pointers. */
  
      if (node1->next == node1) {
        mergeOk = CLIST_AddAfter(node1, node2);
      } else if (node2->next == node2) {
        mergeOk = CLIST_AddAfter(node2, node1);
      } else {
        holdPtr = node1->next;
        node1->next = node2->next;
        node2->next->previous = node1;
  
        node2->next = holdPtr;
        holdPtr->previous = node2;
 
#ifdef paranoidCheck
        /* Make sure that the resulting list is also sane. */

        if (CLIST_Audit(node1) == True) {
#endif 
          mergeOk = True;
#ifdef paranoidCheck
        }
#endif

      }
    }

#ifdef paranoidCheck
  }
#endif

  return mergeOk;
}

Boolean 
CLIST_AddAfter(CLIST_NodeType nodeToAdd, CLIST_NodeType referenceNode)
{
  Boolean        addSuccessful = False;

#ifdef paranoidCheck
  if ((CLIST_Audit (nodeToAdd) == True) && 
      (CLIST_Audit (referenceNode) == True)) {
#endif

    if (nodeToAdd != CLIST_NullNode) {
      if (nodeToAdd->next == nodeToAdd) {
        nodeToAdd->next = referenceNode->next;
        nodeToAdd->previous = referenceNode;
  
        referenceNode->next->previous = nodeToAdd;
        referenceNode->next = nodeToAdd;
  
        addSuccessful = True;
      }
    }

#ifdef paranoidCheck
  }
#endif

  return addSuccessful;
}

Boolean
CLIST_DetachFromCycle (CLIST_NodeType theNode)
{
  Boolean        detached = False; 
  CLIST_NodeType nextNode;

#ifdef paranoidCheck
  if (CLIST_Audit (theNode) == True) {
#endif

    if ((theNode == CLIST_NullNode) || (theNode->next == theNode)) {
      detached = True;
    } else {
      nextNode = theNode->next;
      theNode->next->previous = theNode->previous;
      theNode->previous->next = theNode->next;
  
      theNode->next = theNode;
      theNode->previous = theNode;

#ifdef paranoidCheck
      if ((CLIST_Audit (theNode) == True) && (CLIST_Audit (nextNode) == True)) {
#endif
        detached = True;
#ifdef paranoidCheck
      }
#endif
    }

#ifdef paranoidCheck
  }
#endif

  return detached;
}

/* Break the cycles right after the head of node1 and node2 */

Boolean 
CLIST_BreakCycles (CLIST_NodeType node1, CLIST_NodeType node2)
{
  Boolean         breakOkay = False;
  CLIST_NodeType  holdPtr;

#ifdef paranoidCheck
  if ((CLIST_Audit (node1) == True) && (CLIST_Audit(node2) == True)) {
#endif
    if ((node1 != CLIST_NullNode) && (node2 != CLIST_NullNode) && 
        (node1 != node2)) {
      /* Really should make sure that the nodes belong to the same cycle,
         but we'll trust it all for now. */
  
      holdPtr = node1->next;
      node1->next = node2->next;
      node2->next->previous = node1;
  
      node2->next = holdPtr;
      holdPtr->previous = node2;

#ifdef paranoidCheck  
      if ((CLIST_Audit (node1) == True) && (CLIST_Audit(node2) == True)) {
#endif
        breakOkay = True;
#ifdef paranoidCheck
      }
#endif
    }

#ifdef paranoidCheck
  }
#endif

  return breakOkay;
}

#define _CLIST_MaxNodesPerList   (200)

Boolean
CLIST_Audit (CLIST_NodeType startNode)
{
  Boolean         listOkay = False;
  Boolean         inconsistencyFound;
  CLIST_NodeType  runner, lag;
  UInt16          count;

  if (startNode == CLIST_NullNode) {
    listOkay = True;
  } else {
    /* We have some real checking to do. */

#ifdef paranoid
    if ((startNode->headGuard != _CLIST_HeadTag) ||
        (startNode->tailGuard != _CLIST_TailTag)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_CLIST_MemoryGuards, AL_Fn_CLIST_Audit,
                        (UInt32) startNode, startNode->headGuard, 
                        startNode->tailGuard, 0);
#endif /* enableAlarms */
    } else {
#endif
      /* First, make sure that the list really is circular.  For now, we
         have a hacked-in upper limit on how many nodes can be in one list. */
  
      runner = startNode->next;
      count = 0;
      while ((runner != startNode) && (count < _CLIST_MaxNodesPerList)) {
        runner = runner->next;
        count += 1;
      }
  
      if (runner != startNode) {
#ifdef enableAlarms
        AL_SoftwareAlarm (AL_Id_CLIST_NotCircular, AL_Fn_CLIST_Audit, 
                          (UInt32) startNode, 0, 0, 0);
#endif /* enableAlarms */
      } else {
        lag = startNode;
        runner = startNode->next;
        inconsistencyFound = False;
  
        while ((runner != startNode) && (inconsistencyFound == False)) {
          /* Check back pointers */
          if (runner->previous != lag) {
            inconsistencyFound = True;
#ifdef enableAlarms
            AL_SoftwareAlarm (AL_Id_CLIST_BackPointerCorrupt, AL_Fn_CLIST_Audit,
                              (UInt32) runner, (UInt32) lag, 0, 0);
#endif /* enableAlarms */
          }

#ifdef paranoid
          /* And check memory guards. */

          if ((runner->headGuard != _CLIST_HeadTag) ||
              (runner->tailGuard != _CLIST_TailTag)) {
#ifdef enableAlarms
            AL_SoftwareAlarm (AL_Id_CLIST_MemoryGuards, AL_Fn_CLIST_Audit,
                              (UInt32) runner, runner->headGuard, 
                              runner->tailGuard, 0);
#endif /* enableAlarms */
          }
#endif
          
          lag = runner;
          runner = runner->next;
        }
  
        if (inconsistencyFound == False) {
          listOkay = True;
        }
      }
#ifdef paranoid
    }
#endif
  }
  return listOkay;
}

