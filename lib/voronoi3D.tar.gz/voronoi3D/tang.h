
#ifndef _tang_h_
#define _tang_h_

#include "polygon.h"

void Tang(Pgon *P, Pgon *Q, int *pi, int *qi);

#endif /* _tang_h_ */

