
#ifndef _heapDefs_h_
#define _heapDefs_h_

#include "globals.h"

#define _HEAP_FirstHeapElt (1)
#define _HEAP_MaxNameSize  (10)

#define _HEAP_HeadTag GLBL_Tag('H', 'e', 'a', 'p')
#define _HEAP_TailTag GLBL_Tag('_', 'e', 'n', 'd')

#endif
