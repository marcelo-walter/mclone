
#include <math.h>

#include "globals.h"
#include "geometry.h"
#include "polygon.h"
#include "distance.h"
#include "tang.h"

void
squarePointDistance(Pt *point1, Pt *point2, Real *dist)
{
	Real	xdiff, ydiff;

#ifdef DEBUG_DISTANCE
	printf ("dst: square point distance is .. ");
#endif

	xdiff = XVal(*point1) - XVal(*point2);
	ydiff = YVal(*point1) - YVal(*point2);
	*dist = (xdiff*xdiff) + (ydiff*ydiff);

#ifdef DEBUG_DISTANCE
	printf ("%f\n", *dist);
#endif
}

void
pointDistance(Pt *point1, Pt *point2, Real *dist)
{
	Real	squaredist;

#ifdef DEBUG_DISTANCE
	printf ("dst: point distance is .. ");
#endif

	squarePointDistance(point1, point2, (double *) (&squaredist));
	*dist = (Real) sqrt((double)squaredist);

#ifdef DEBUG_DISTANCE
	printf ("%f\n", *dist);
#endif
}

/*	Find the point of tangency, relative to the origin of the convex
	distance function, of the convex distance function and the 
	vertical sweepline */

void
getSweeplineTan(Pt *tanPt)
{
	/*	The Euclidean case is really easy.  The sweepline is 
		vertical and to the left of the circle, so we use the
		x-intercept of the unit circle. */

	tanPt->w = 1.0;
	tanPt->x = 1.0;
	tanPt->y = 0.0;

	/* This extra component doesn't matter. */

	tanPt->z = 0.0;
}

/*	For a convex distance function, if we shoot a ray from the origin
	of the distance function in the vector direction from "start"
	to "end" then we exit the convex polygon at the point "exitPt". */

void
getExitPoint(Pt *start, Pt *end, Pt *exitPt)
{
	Real	len;

#ifdef DEBUG_DISTANCE
	printf ("dst: find the exit point from "
		"%2.2f %2.2f to %2.2f %2.2f\n",
		XVal(*start), YVal(*start), XVal(*end), YVal(*end));
#endif

	/*	The Euclidean case implies that we can use the angle/slope
		of the vector from "start" to "end" as the exit point along
		the unit circle. */

	exitPt->w = 1.0; 
	exitPt->x = XVal(*end) - XVal(*start);
	exitPt->y = YVal(*end) - YVal(*start);
	vectorLength (exitPt, &len);
	exitPt->w = (Coordinate) len;

	/* The extra z component doesn't matter. */

	exitPt->z = 0.0;

#ifdef DEBUG_DISTANCE
	printf ("dst: exit point is %2.2f %2.2f %2.2f\n", 
		exitPt->w, exitPt->x, exitPt->y);
#endif
}

#ifdef Hack
Boolean
segmentSharesPoint (Pgon *segment, Pt *point, UInt16 *segEnd)
{
  Boolean share = False;

  if ((SamePoint(&(segment->points[0]), point))) {
    share = True; *segEnd = 0; 
  } else if ((SamePoint(&(segment->points[1]), point))) {
    share = True; *segEnd = 1;
  }

  return share;
}

Boolean
segmentsShareCommonEnd (Pgon *p1, Pgon *p2, UInt16 *endP1, UInt16 *endP2)
{
  Boolean  share = False;

  if (segmentSharesPoint (p1, &(p2->points[0]), endP1) == True) {
    share = True; *endP2 = 0;
  } else if (segmentSharesPoint(p1, &(p2->points[1]), endP1) == True) {
    share = True; *endP2 = 1;
  }

  return share;
}
#endif

/*	Find the outer common tangent that has the polygons on its left
	(ccw orientation) when going from "head" to "tail".  Necessarily,
	"start" will be a point of polygon "head" and "end" will be a 
	point of polygon "tail". 

    If no unique tangent in the direction exists (i.e. the polygons share
    a point and that point would be the attachment points for the
    tangent) then the routine returns False and headIndex, tailIndex,
    start, and end all point to that common point. */

Boolean
outerCommonTangent(Pgon *head, Pgon *tail, Pt *start, Pt *end,
	int *headIndex, int *tailIndex)
{
  Boolean tangentIsOkay = True;
#ifdef Hack
  UInt16  headEnd, tailEnd;
  Line    compareLine;

  /* Do a hack so that two lines can share a common endpoint for now. */

  if ((head->numPoints == 2) && (tail->numPoints == 2)) {
    if (segmentsShareCommonEnd (head, tail, &headEnd, &tailEnd)) {
      LineOf (&(head->points[(headEnd+1)%2]), 
              &(head->points[headEnd]), &compareLine);
      if (LineSide(&compareLine, &(tail->points[(tailEnd+1)%2])) == LeftSide) {

        tangentIsOkay = False;

        *headIndex = headEnd;
        *tailIndex = tailEnd;
      }
    }
  }

  if (tangentIsOkay == True) {
    if ((head->numPoints == 1) && (tail->numPoints == 1)) {
      *headIndex = 0;
      *tailIndex = 0;
    } else {
#endif
      Tang (head, tail, headIndex, tailIndex);
#ifdef Hack
    }
  }
#endif

  PointAssign((*start), (head->points[*headIndex]));
  PointAssign((*end), (tail->points[*tailIndex]));

  return tangentIsOkay;
}

void
vectorLength(Pt *point, Real *length)
{
#ifdef DEBUG_DISTANCE
	printf ("dst: compute vector length of ");
#endif

	*length = (Real) sqrt((double)(point->x * point->x + 
				point->y * point->y)) / point->w;
	if (*length < 0)
		*length *= -1;

#ifdef DEBUG_DISTANCE
	printf ("%f\n", *length);
#endif
}

