
#include "main.h"
#include "voronoi.h"
#include "geometry.h"
#include "sub.h"
#include "distance.h"
#include "degen.h"


#define CopyPoint(A,B) /* A is in my format, B is a pType. */\
  (B)[W] = (A).w;\
  (B)[X] = (A).x;\
  (B)[Y] = (A).y;

#define UncopyPoint(A,B) /* B is in my format, A is a pType. */\
  (B).w = (A)[W];\
  (B).x = (A)[X];\
  (B).y = (A)[Y];

#define Share12  1
#define Share13  2
#define Share23  4

Boolean
sitesHaveCommonPoints(Pgon *p1, Pgon *p2, Pgon *p3, UInt16 flagMask, 
                      UInt16 *mask)
{
  UInt16    idx1, idx2, idx3;

  switch (flagMask) {
    case 1:
      *mask = (segmentSharesPoint (p1, &(p2->points[0]), &idx1) ? Share12 : 0) +
              (segmentSharesPoint (p1, &(p3->points[0]), &idx1) ? Share13 : 0);
      break;
    case 2:
      *mask = (segmentSharesPoint (p2, &(p1->points[0]), &idx2) ? Share12 : 0) +
              (segmentSharesPoint (p2, &(p3->points[0]), &idx2) ? Share23 : 0);
      break;
    case 3:
      *mask = (segmentSharesPoint (p1, &(p3->points[0]), &idx1) ? Share13 : 0) +
              (segmentSharesPoint (p2, &(p3->points[0]), &idx2) ? Share23 : 0) +
              (segmentsShareCommonEnd (p1, p2, &idx1, &idx2) ? Share12 : 0);
      break;
    case 4:
      *mask = (segmentSharesPoint (p3, &(p1->points[0]), &idx3) ? Share13 : 0) +
              (segmentSharesPoint (p3, &(p2->points[0]), &idx3) ? Share23 : 0);
      break;
    case 5:
      *mask = (segmentSharesPoint (p1, &(p2->points[0]), &idx1) ? Share12 : 0) +
              (segmentSharesPoint (p3, &(p2->points[0]), &idx3) ? Share23 : 0) +
              (segmentsShareCommonEnd (p1, p3, &idx1, &idx3) ? Share13 : 0);
      break;
    case 6:
      *mask = (segmentSharesPoint (p2, &(p1->points[0]), &idx2) ? Share12 : 0) +
              (segmentSharesPoint (p3, &(p1->points[0]), &idx3) ? Share13 : 0) +
              (segmentsShareCommonEnd (p2, p3, &idx2, &idx3) ? Share23 : 0);
      break;
    case 7:
      *mask = (segmentsShareCommonEnd (p1, p2, &idx1, &idx2) ? Share12 : 0) +
              (segmentsShareCommonEnd (p1, p3, &idx1, &idx3) ? Share12 : 0) +
              (segmentsShareCommonEnd (p2, p3, &idx2, &idx3) ? Share12 : 0);

      break;
    case 0:
      /* Don't handle identical sites. */
    default:
      *mask = 0;
      break;
  }

  return (*mask == 0 ? False : True);
}

Boolean
voronoiVertex(Pgon *P1, Pgon *P2, Pgon *P3, Pt *vorPoint, Pt *eventPoint, 
        spokeInfo *middleSpoke) /* Assumes all polygons are non-trivial */
{
  Boolean  answer = NormalVoronoi;
  UInt16   flagMask = 0;
  pType    points[7], voronoi, foo, bar, frotz;
  UInt16   commonMask = 0;
  Boolean  degenerate = False;

  /* Find out what sequence of polygons that we're dealing with. */

  if (P1->numPoints > 1) flagMask += 1;
  if (P2->numPoints > 1) flagMask += 2;
  if (P3->numPoints > 1) flagMask += 4;

  /* The value of flagMask now tells us exactly what P1, P2, and P3 are
	 (under the assumption of only lines and points. */

#if 0
  degenerate = sitesHaveCommonPoints(P1, P2, P3, flagMask, &commonMask);
#endif

  switch (flagMask) {
	case 0:
	  /* All points. */

	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P2->points[0], points[2]);
	  CopyPoint(P3->points[0], points[3]);

	  if (counterClock(points[1], points[2], points[3])) {
		answer = threePointCircle (points[1], points[2], points[3], voronoi);
		UncopyPoint(points[2], middleSpoke->attachment);
	  } else {
		/* TBD maybe need to set the spoke. */
		answer = InfiniteVoronoi;
	  }
	  break;
	case 1:
	  /* One line segment and two points. */

	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P1->points[1], points[2]);
	  CopyPoint(P2->points[0], points[3]);
	  CopyPoint(P3->points[0], points[4]);

      if (degenerate == False) {
	    if (oneSegment(FALSE, ZERO, points[1], points[2],
						    points[3], points[4], voronoi, foo) <= 0) {
		  answer = InfiniteVoronoi;
	    }
      } else {
        if (pointOnSegEnd2ndIsPoint (GEOM_CCW, points[1], points[2], 
                             points[3], points[4], voronoi, foo) <= 0) {
		  answer = InfiniteVoronoi;
        }
      }
	  UncopyPoint(points[3], middleSpoke->attachment);
	  break;
	case 2: 
	  /* One line segment and two points. */
	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P2->points[0], points[2]);
	  CopyPoint(P2->points[1], points[3]);
	  CopyPoint(P3->points[0], points[4]);

      if (degenerate == False) {
	    if (oneSegment(FALSE, ZERO, points[2], points[3],
						    points[4], points[1], voronoi, foo) <= 0) {
		  answer = InfiniteVoronoi;
	    }
      } else {
	    if (pointOnSegEnd2ndIsPoint(GEOM_CCW, points[2], points[3],
						    points[4], points[1], voronoi, foo) <= 0) {
		  answer = InfiniteVoronoi;
	    }
	  }
	  UncopyPoint(foo, middleSpoke->attachment);
	  break;
	case 4:
	  /* One line segment and two points. */
	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P2->points[0], points[2]);
	  CopyPoint(P3->points[0], points[3]);
	  CopyPoint(P3->points[1], points[4]);

      if (degenerate == False) {
	    if (oneSegment(FALSE, ZERO, points[3], points[4],
						    points[1], points[2], voronoi, foo) <= 0) {
		  answer = InfiniteVoronoi;
	    }
      } else {
	    if (pointOnSegEnd2ndIsPoint(GEOM_CCW, points[3], points[4],
						    points[1], points[2], voronoi, foo) <= 0) {
		  answer = InfiniteVoronoi;
	    }
	  }
	  UncopyPoint(points[2], middleSpoke->attachment);
	  break;
	case 3: 
	  /* Two line segments and one point. */
	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P1->points[1], points[2]);
	  CopyPoint(P2->points[0], points[3]);
	  CopyPoint(P2->points[1], points[4]);
	  CopyPoint(P3->points[0], points[5]);

      /* Here is a point that we shouldn't be needing. */
	  CopyPoint(P3->points[1], points[6]);

      if (degenerate == False) {
	    if (twoSegment(FALSE, ZERO, True, points[1], points[2], points[3], points[4], 
	  			 points[5], NULL, voronoi, foo, bar) <= 0) {
	      answer = InfiniteVoronoi;
	    }
      } else {
        if ((commonMask & Share13) != 0) {
	      if (pointOnSegEnd2ndIsSeg(GEOM_CCW, points[1], points[2], points[3], 
                   points[4], points[5], points[6], voronoi, foo, bar) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        } else if ((commonMask & Share12) != 0) {
	      if (pointOnSegEnd2ndIsSeg(GEOM_CW, points[3], points[4], points[1], 
                   points[2], points[5], points[6], voronoi, bar, foo) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        } else {
          /* The common end must be between the two segments. */
	      if (segOnSegEnd2ndIsPoint(GEOM_CCW, points[1], points[2], points[3], 
                   points[4], points[5], voronoi, foo, bar) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        }
	  }
	  UncopyPoint(bar, middleSpoke->attachment);
	  break;
	case 5: 
	  /* Two line segments and one point. */
	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P1->points[1], points[2]);
	  CopyPoint(P2->points[0], points[3]);
	  CopyPoint(P3->points[0], points[4]);
	  CopyPoint(P3->points[1], points[5]);

      /* This is a point that we shouldn't need in here. */
	  CopyPoint(P2->points[1], points[6]);

      if (degenerate == False) {
	    if (twoSegment(FALSE, ZERO, True, points[4], points[5], points[1], points[2], 
					   points[3], NULL, voronoi, foo, bar) <= 0) {
		  answer = InfiniteVoronoi;
	    }
      } else {
        if ((commonMask & Share12) != 0) {
	      if (pointOnSegEnd2ndIsSeg(GEOM_CW, points[1], points[2], points[4], 
                   points[5], points[3], points[6], voronoi, bar, foo) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        } else if ((commonMask & Share23) != 0) {
	      if (pointOnSegEnd2ndIsSeg(GEOM_CCW, points[4], points[5], points[1], 
                   points[2], points[3], points[6], voronoi, foo, bar) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        } else {
          /* The common end must be between the two segments. */
	      if (segOnSegEnd2ndIsPoint(GEOM_CCW, points[1], points[2], points[3], 
                   points[4], points[5], voronoi, bar, foo) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        }
      }

	  UncopyPoint(points[3], middleSpoke->attachment);
	  break;
	case 6:
	  /* Two line segments and one point. */
	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P2->points[0], points[2]);
	  CopyPoint(P2->points[1], points[3]);
	  CopyPoint(P3->points[0], points[4]);
	  CopyPoint(P3->points[1], points[5]);

      /* Here is a point that we shouldn't be needing. */
	  CopyPoint(P1->points[1], points[6]);

      if (degenerate == False) {
	    if (twoSegment(FALSE, ZERO, True, points[2], points[3], points[4], points[5], 
					   points[1], NULL, voronoi, foo, bar) <= 0) {
		  answer = InfiniteVoronoi;
	    }
      } else {
        if ((commonMask & Share12) != 0) {
	      if (pointOnSegEnd2ndIsSeg(GEOM_CCW, points[2], points[3], points[4], 
                   points[5], points[1], points[6], voronoi, foo, bar) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        } else if ((commonMask & Share13) != 0) {
	      if (pointOnSegEnd2ndIsSeg(GEOM_CW, points[4], points[5], points[2], 
                   points[3], points[1], points[6], voronoi, bar, foo) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        } else {
          /* The common end must be between the two segments. */
	      if (segOnSegEnd2ndIsPoint(GEOM_CCW, points[2], points[3], points[4], 
                   points[5], points[1], voronoi, foo, bar) <= 0) {
	        answer = InfiniteVoronoi;
	      }
        }
      }
	  UncopyPoint(foo, middleSpoke->attachment);
	  break;
	case 7:
	  /* Three line segments. */
	  /* Copy over the points. */

	  CopyPoint(P1->points[0], points[1]);
	  CopyPoint(P1->points[1], points[2]);
	  CopyPoint(P2->points[0], points[3]);
	  CopyPoint(P2->points[1], points[4]);
	  CopyPoint(P3->points[0], points[5]);
	  CopyPoint(P3->points[1], points[6]);

	  if (threeSegment(points, voronoi, foo, bar, frotz) <= 0) {
		answer = InfiniteVoronoi;
	  }
	  UncopyPoint(bar, middleSpoke->attachment);
	  break;
	default: 
	  printf ("Don't know what's going on\n");
	  answer = False;
	  break;
  }

  if (answer != 1) {
    Pt      tan1Start, tan1End, tan2Start, tan2End;
    int     headIdx, tailIdx, head1Idx, tail1Idx;
    Boolean ignore, tan1Okay, tan2Okay;
    Line    tangent, perp;

    /* Got to make an infinite spoke. */

    tan1Okay = outerCommonTangent(P2, P1, &tan1Start, &tan1End, &head1Idx, 
                                  &tail1Idx);
    tan2Okay = outerCommonTangent(P3, P2, &tan2Start, &tan2End, &headIdx, 
                                  &tailIdx);

    if (tan1Okay && tan2Okay) {
      ignore = objectsOnHull(&tan1End, &tan1Start, &tan2End, &tan2Start,
                             vorPoint, eventPoint, middleSpoke);
    } else {
#if 0
      ignore = objectsOnHull(&(P2->points[
                             (headIdx - 1 + P2->numPoints) % P2->numPoints]), 
                             &tan1Start, &tan2End, &(P3->points[
                             (headIdx - 1 + P3->numPoints) % P3->numPoints]),
                             vorPoint, eventPoint, middleSpoke);
#else
      /* Time to get nasty. */

      vorPoint->w = 0.0; vorPoint->x = 0.0; vorPoint->y = 0.0;
      eventPoint->w = 0.0; eventPoint->x = 1.0; eventPoint->y = 0.0;

      if (tan1Okay) {
        PointAssign (middleSpoke->attachment, tan2Start);
        LineOf (&tan1Start, &tan1End, &tangent);
        perpendicularLine(&tan2Start, &tangent, &perp);
        PointAssign (middleSpoke->otherPt, tan2Start);
        if (!Zero(perp.y)) {
          middleSpoke->otherPt.x += middleSpoke->otherPt.w;
          middleSpoke->otherPt.y = SolveLineForY(&perp, XVal(middleSpoke->otherPt))* middleSpoke->otherPt.w;
        } else {
          middleSpoke->otherPt.y += middleSpoke->otherPt.w;
        }
        if (LineSide (&tangent, &middleSpoke->otherPt) ==
            LineSide (&tangent, &(P1->points[(tail1Idx+1)%P1->numPoints]))) {
          PointAssign (middleSpoke->otherPt, tan2Start);
          if (!Zero(perp.y)) {
            middleSpoke->otherPt.x -= middleSpoke->otherPt.w;
            middleSpoke->otherPt.y = SolveLineForY(&perp, XVal(middleSpoke->otherPt))* middleSpoke->otherPt.w;
          } else {
            middleSpoke->otherPt.y -= middleSpoke->otherPt.w;
          }
        }
   
      } else {
        PointAssign (middleSpoke->attachment, tan1Start);
        if (tan2Okay) {
          LineOf (&tan2Start, &tan2End, &tangent);
        } else {
          LineOf (&(LeftPoint(P2)), &(RightPoint(P2)), &tangent);
        }
        perpendicularLine(&tan1Start, &tangent, &perp);
        PointAssign (middleSpoke->otherPt, tan1Start);
        if (!Zero(perp.y)) {
          middleSpoke->otherPt.x += middleSpoke->otherPt.w;
          middleSpoke->otherPt.y = SolveLineForY(&perp, XVal(middleSpoke->otherPt))* middleSpoke->otherPt.w;
        } else { 
          middleSpoke->otherPt.y += middleSpoke->otherPt.w;
        }
        if (LineSide (&tangent, &middleSpoke->otherPt) ==
            LineSide (&tangent, &(P3->points[(headIdx+1)%P3->numPoints]))) {
          PointAssign (middleSpoke->otherPt, tan1Start);
          if (!Zero(perp.y)) {
            middleSpoke->otherPt.x -= middleSpoke->otherPt.w;
            middleSpoke->otherPt.y = SolveLineForY(&perp, XVal(middleSpoke->otherPt))* middleSpoke->otherPt.w;
          } else {
            middleSpoke->otherPt.y -= middleSpoke->otherPt.w;
          }
        }
      }
#endif
    }
  } else {
    UncopyPoint(voronoi, *vorPoint);
    UncopyPoint(voronoi, middleSpoke->otherPt);
    getEventPoint(&middleSpoke->otherPt, &middleSpoke->attachment, eventPoint);
  }

  return answer;
}


