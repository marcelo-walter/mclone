
#ifndef _sweepDefs_h_

#define _sweepDefs_h_

#include "globals.h"

typedef enum {
    SWP_FiniteVertex
  , SWP_InfiniteVertex
  } SWP_VoronoiVertexType;

#endif

