
/******************************************************************
; Module:  Red-Black Trees
;
; description:
;   This module contains the external interfaces and data types for
;   the red-black tree module.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.01.13 / M. McAllister / Made prototype for RBTREE_ForEachNode
;                              ANSI compliant.
;   95.10.27 / M. McAllister / Added RBTREE_PreviousData, RBTREE_NextData
*******************************************************************/

#ifndef _rbtree_h_ 
#define _rbtree_h_ 

#include "globals.h"
#include "rbtreeDefs.h"

/********************************************************************
;  The externally visible data types and constants. 
*********************************************************************/

typedef _RBTREE_TreeInfoType *RBTREE_TreeType;
typedef _RBTREE_NodeInfoType *RBTREE_NodeType;

#define RBTREE_NullTree  (NULL)
#define RBTREE_NullNode  (NULL)


/********************************************************************
;  Declarations for all externally visible subroutines. 
*********************************************************************/

/********************************************************************
;  Routines that any sane person using the red-black tree would use
*********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

RBTREE_TreeType RBTREE_Alloc (SInt16 (*cmpRtn)(Ptr key1, Ptr key2), Char *name);

void            RBTREE_Free (RBTREE_TreeType theTree);

Boolean         RBTREE_Add (RBTREE_TreeType theTree, Ptr addDataPtr,
                        RBTREE_NodeType *addedNode);

Boolean         RBTREE_Delete (RBTREE_NodeType deleteNode);

RBTREE_NodeType RBTREE_Next (RBTREE_TreeType theTree, 
                        RBTREE_NodeType currentNode);

RBTREE_NodeType RBTREE_Previous (RBTREE_TreeType theTree, 
                        RBTREE_NodeType currentNode);

Boolean         RBTREE_FindNode (RBTREE_TreeType theTree, Ptr matchDataPtr, 
                        RBTREE_NodeType *nodePtr);

Ptr             RBTREE_GetData (RBTREE_NodeType theNode);

Boolean         RBTREE_ForEachNode (RBTREE_TreeType theTree, 
                        Boolean (*callRtn)(Ptr dataPtr, Ptr arg), Ptr arg);

UInt32          RBTREE_NumberOfNodes (RBTREE_TreeType theTree);

Boolean         RBTREE_Audit (RBTREE_TreeType theTree);

/********************************************************************
;  The following combinations are used so frequently that it's just
;  as well to provide macros for them.
*********************************************************************/

#define RBTREE_PreviousData(Tr,Nd)   RBTREE_GetData(RBTREE_Previous(Tr,Nd))

#define RBTREE_NextData(Tree,Node)   RBTREE_GetData(RBTREE_Next(Tree,Node))

/********************************************************************
;  Routines that somebody who is trying to work around the tree might
;  want to have around.
*********************************************************************/

Boolean         RBTREE_AddAfterNode (RBTREE_TreeType theTree, 
                        RBTREE_NodeType afterNode, Ptr addDataPtr,
                        RBTREE_NodeType *addedNode);

RBTREE_NodeType RBTREE_Parent (RBTREE_TreeType theTree, 
                        RBTREE_NodeType currentNode);

RBTREE_NodeType RBTREE_LeftChild (RBTREE_TreeType theTree, 
                        RBTREE_NodeType currentNode);

RBTREE_NodeType RBTREE_RightChild (RBTREE_TreeType theTree, 
                        RBTREE_NodeType currentNode);

#ifdef __cplusplus
}
#endif /* For extern "C" */

#endif

