
#ifndef _schedule_h_

#define _schedule_h_

#include "heap.h"
#include "geometry.h"
#include "polygon.h"
#include "voronoi.h"
#include "front.h"

#define EVT_TopElement       (0)
#define EVT_MiddleElement    (1)
#define EVT_BottomElement    (2)
#define EVT_NewSiteIdx       (0)
#define EVT_LostArcIdx       (0)

typedef enum {
  EVT_SiteEvent,
  EVT_CircleEvent,
  EVT_SiteMergeEvent
  } EVT_EventType;

typedef struct {
    EVT_EventType  whatEvent;
	Pt             eventPt;
	Pt             eventCentre;
	spokeInfo      midSpoke;
	Pgon           *poly[3];
	FRONT_ArcType  frontArcs[3];
	}	scheduleInfo;

scheduleInfo *newSchedule(void);
void         freeSchedule(scheduleInfo **sched);
Boolean      startSchedule(int sizeEst);
void         endSchedule(void);

#endif

