
#ifndef _sub_h_
#define _sub_h_

/*****************************************************************/
/*                                                               */
/*  NAME : TIN VAN NGUYEN                                        */
/*  DATE : May 17, 1995                                          */
/*                                                               */
/*  This header file contains user-type definition and function  */
/*  declarations of all subroutines                              */
/*                                                               */
/*****************************************************************/

#include <math.h>
#include <stdio.h>
#include "globals.h"

typedef double coType;
typedef coType pointType[3];
typedef pointType pType;

/*
#define EPSILON 1E-6
*/

#define WSIZE  800
#define FWSIZE 800.0
#define COL_POINT RED

#define X 0
#define Y 1
#define W 2

#define A 0
#define B 1
#define C 2

#define ZERO 0
#define ONE 1
#define TWO 2
#define THREE 3

/* EXTERNAL SUBROUTINES */

int validity(int flag, pType a, pType b, pType c, pType d, pType e);

int quaSolve(pType co, pType solution); 

coType deter3d(pType a, pType b, pType c);

int cramer(pType co1, pType co2, pType solution);

int normalized(pType one, pType two, pType para);

int shortest(int infi, pType start, pType end, pType co, 
		    pType m, pType base);

int counterClock(pType one, pType two, pType three);

int threePointCircle(pType a, pType b, pType c, pType d);

int inOneSegment(int line, int order, pType point[5], pType center, 
			pType i);

int inTwoSegment(int line, int order, pType point[6], pType center, 
			pType i, pType j);

int inThreeSegment(pType point[7], pType center, pType i, 
			  pType j, pType k);


int SAME_POINT(pType a, pType b);


int twoSegment(int line, int order, Boolean checkDegen, pointType a, pointType b, pointType
c, pointType d, pointType e, pointType possibleF, pointType center, pointType i, pointType j);

int oneSegment(int line, int order, pointType a, pointType b, pointType
c, pointType e, pointType center, pointType i);
 
int threeSegment(pType point[7], pType center, pType i, 
			  pType j, pType k);



#endif

