/* nosep.c   Jack Snoeyink  March 94   Common tangent without a separating line
 *
 */
#include "main.h"

#define Pv(m) (P->points+m)           /* Indexing into polygon vertices */
#define Qv(m) (Q->points+m)
#define Pvr(m) (P->points+((m) % P->numPoints)) /* Indexing mod $n$ */
#define Qvr(m) (Q->points+((m) % Q->numPoints))

#define CCW(xo) ((xo)->ccw == 1) /* Is $x$ oriented counterclockwise? */
#define DONE(xo) (((xo)->end - (xo)->tent) == (xo)->ccw) /* Any candidates left? */
#define REFINED(xo) ((xo)->st != (xo)->tent) /* Is $x$ refined? */

#define NO_DISC     -1           /* Actions in \op Refine() */
#define DISC_END     0
#define DISC_START   1


void Refine(P, Q, Po, Qo)
     Pgon *P, *Q;
     POLYGON *Po, *Qo;		/* We refine polygon $P$ checking against $Q$.  
We can assume that more than one candidates exist in $(\tentP,\enP\,]$
and the invariants hold. */
{
  HOMOG q0pm, mtang;
  register int mid, left_base, action = NO_DISC;
  register Pt *pm, *pm1, *qend, *qt;
  
  mid = Po->tent + (Po->end - Po->tent) / 2; /* Check \mid\ point.
                                            Round towards \tentP\ */
  pm = Pvr(mid);
  pm1 = Pvr(mid + Po->ccw);
  CROSS_2SCCH(Po->ccw, pm, pm1, &mtang); /* Generate $\tau_\mid$ */
  CROSS_2CCH(Qv(0), pm, &q0pm);
  left_base = RIGHT_PL(Pv(0), &q0pm); 

  if (REFINED(Qo) && !LEFT_PL(pm, &Qo->tang)) {
    qt = Qvr(Qo->tent);
    if (CCW(Qo) ^ LEFT_PPP(Pv(0), qt, pm)) /* Check $\sigma_\tentQ$ */
      Qo->st = Qo->tent;          /* Certify tentative to $Q$ */
    else {
      Qo->end = Qo->tent; 
      Qo->tent = Qo->st;          /* Revoke tentative to $Q$ */
      Po->st = Po->tent;	/* Certify tentatve on $P$ (if refined) */
    }
  }

  qend = Qvr(Qo->end);
  qt = Qvr(Qo->tent);

  if (Po->wrap && (left_base ^ (mid > P->numPoints))) /* Is $P$ wrapped around? */
    action = !left_base;
  else if (!LEFT_PL(Qv(0), &mtang)) /* Can we be tangent w.r.t $q_0$? */
    action = left_base;
  else if (!LEFT_PL(qend, &mtang)) /* Be tangent w.r.t $q_\enQ$? */
    action = LEFT_PL(qend, &q0pm);
  else if (REFINED(Qo) && !LEFT_PL(qt, &mtang)) /* Be tangent w.r.t $q_\tentQ$? */
    action = LEFT_PL(qt, &q0pm);
  
  if (action == NO_DISC) {
    Po->tent = mid;              /* We tentatively refine at \mid */        
    ASSIGN_H(&Po->tang, =, &mtang)
    }
  else if (CCW(Po) ^ action)
    Po->st = Po->tent = mid;      /* A discard at \stP\ occurred */
  else
    Po->end = mid;               /* A discard at \enP\ occurred */
}




void Tang(P, Q, pi, qi)
     Pgon *P, *Q;
     int *pi, *qi;
{                               /* Compute a tangent from $P$ to $Q$ */
  register int n1 = Q->numPoints - 1;
  POLYGON Po, Qo;

  Po.ccw = 1; Po.st = Po.tent = 0; Po.end = P->numPoints; /* Initialize $P$ */
  CROSS_2CCH(Pv(0), Pv(1), &Po.tang);
  if ((Po.wrap = LEFT_PL(Qv(0), &Po.tang))) /* Wrap $P$ initially */
    { Po.tent = P->numPoints; Po.end += P->numPoints; }

  Qo.ccw = -1; Qo.st = Qo.tent = Q->numPoints; Qo.end = 0; /* Initialize $Q$ */
  CROSS_2CCH(Qv(n1), Qv(0), &Qo.tang);
  if ((Qo.wrap = LEFT_PL(Pv(0), &Qo.tang))) /* Wrap $Q$ initially */
    Qo.st += Q->numPoints; 

  while (!DONE(&Po) || !DONE(&Qo)) {
    if (!DONE(&Po)) Refine(P, Q, &Po, &Qo);
    if (!DONE(&Qo)) Refine(Q, P, &Qo, &Po);
  }                             /* Finished. $\enQ$ and $\enP$ indicate tangent */
  *pi = Po.end % P->numPoints;
  *qi = Qo.end % Q->numPoints;
/*  if (gr_verbose) {color (BLUE); drawSeg(V(P,Po.end), V(Q,Qo.end));} */
}

