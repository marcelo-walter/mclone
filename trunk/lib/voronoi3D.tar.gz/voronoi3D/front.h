
#ifndef _front_h_
#define _front_h_

#include "globals.h"
#include "heap.h"
#include "polygon.h"
#include "frontDefs.h"

/********************************************************************
;  The externally visible data types and constants.
*********************************************************************/

#define FRONT_NullArc   (NULL)
#define FRONT_NullFront (NULL)

typedef _FRONT_FrontInfoType    *FRONT_FrontType;
typedef _FRONT_ArcInfoType      *FRONT_ArcType;

/********************************************************************
;  Declarations for all externally visible subroutines.
*********************************************************************/

Boolean FRONT_Create (FRONT_UserRoutineType *configRoutines,
                      FRONT_FrontType *theFront);

void FRONT_Free (FRONT_FrontType theFront);

Boolean FRONT_LoadSite (FRONT_FrontType theFront, Pgon *site, HEAP_Heap circles,
                        HEAP_Heap merges, Ptr siteData, FRONT_ArcType *theArc);

Boolean FRONT_NewSite(FRONT_FrontType theFront, Pgon *site, HEAP_Heap circles,
                      HEAP_Heap merges,
                      Ptr newSiteData, Ptr splitArcData, 
                      FRONT_ArcType *newSiteArc,
                      FRONT_ArcType *lowerSplitArc);

Boolean FRONT_RemoveArc (FRONT_FrontType theFront, FRONT_ArcType theArc,
                         HEAP_Heap circles, HEAP_Heap merges, 
                         Boolean removeMiddleVoronoi);

Boolean FRONT_Advance(FRONT_FrontType theFront, Real newPos);

Boolean FRONT_Traverse (FRONT_FrontType theFront, 
                        Boolean (*rtn)(FRONT_ArcType theArc, Ptr data), 
                        Ptr data);

FRONT_ArcType FRONT_TopArc    (FRONT_FrontType theFront);

FRONT_ArcType FRONT_BottomArc (FRONT_FrontType theFront);

FRONT_ArcType FRONT_PreviousArc(FRONT_FrontType theFront, FRONT_ArcType theArc);

FRONT_ArcType FRONT_NextArc  (FRONT_FrontType theFront, FRONT_ArcType theArc);

FRONT_ArcType FRONT_NextArcForSite (FRONT_FrontType theFront, 
                                    FRONT_ArcType theArc);

FRONT_ArcType FRONT_PrevArcForSite (FRONT_FrontType theFront,
                                    FRONT_ArcType theArc);

Ptr FRONT_GetData (FRONT_ArcType theArc);

#endif
	
