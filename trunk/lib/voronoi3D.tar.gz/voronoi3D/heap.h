
#ifndef _heap_h_
#define _heap_h_

#include "globals.h"
#include "heapDefs.h"

/*	Define the structure of a heap -- an item count, a key
    list, and a set of pointers for data. */

#define HEAP_NullHeap      (NULL)
#define HEAP_NullHeapId    (0)

typedef UInt32 HEAP_HeapId;

typedef struct _heap {
  UInt32       headGuard;    /* A memory guard */
  Char         name[_HEAP_MaxNameSize];
  UInt16       count;        /* The number of entries currently in the heap */
  UInt16       maxSize;      /* The max size of the heap. */
  HEAP_HeapId  lastUsedId;   /* The last id used for the idList and refList */
  HEAP_HeapId  *refList;     /* An xref from the id to the heap item */

  Ptr          *dataList;    /* The data that the heap is sorting. */
  HEAP_HeapId  *idList;      /* The ids for the heap elements */
  SInt16       (*cmpRtn)(Ptr, Ptr);   /* Key comparison routine */
  UInt32       tailGuard;    /* A memory guard */
  } HEAP_HeapInfo;

typedef HEAP_HeapInfo *HEAP_Heap;

HEAP_Heap	HEAP_Allocate(UInt16 size, SInt16 (*cmpRtn)(Ptr, Ptr), Char *name);
Boolean	HEAP_Add (HEAP_Heap heap, Ptr dataPtr, HEAP_HeapId *heapIdPtr);
Boolean	HEAP_PopTop (HEAP_Heap heap, Ptr *dataPtr);
Boolean	HEAP_PopNamed (HEAP_Heap heap, HEAP_HeapId heapId, Ptr *dataPtr);
Boolean	HEAP_PeekTop (HEAP_Heap heap, Ptr *dataPtr);
Boolean	HEAP_PeekNamed (HEAP_Heap heap, HEAP_HeapId heapId, Ptr *dataPtr);
void	HEAP_Free (HEAP_Heap heap);
void	HEAP_Print (HEAP_Heap heap);
UInt16  HEAP_Size(HEAP_Heap heap);
Boolean HEAP_Audit (HEAP_Heap heap);

#endif
