
#include <stdlib.h>

#include "globals.h"
#include "schedule.h"

scheduleInfo 
*newSchedule(void)
{
  return (scheduleInfo *)malloc(sizeof(scheduleInfo));
}

void         
freeSchedule(scheduleInfo **sched)
{
  free (*sched);
  *sched = NULL;
}

Boolean         
startSchedule(int sizeEst)
{
  /* Used to do pool stuff.  Use malloc directly instead. */
  return True;
}

void         
endSchedule(void)
{
  /* Used to do pool stuff.  Use malloc directly instead. */
}


