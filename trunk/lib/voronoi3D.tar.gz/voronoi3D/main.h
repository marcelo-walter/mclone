/* main.h   Jack Snoeyink   march 94
 * voronoi vertices
 */

#ifndef _main_h_
#define _main_h_

#include "geometry.h"
#include "voronoi.h"
#include <stdio.h>
#include <math.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define MAXPTS 2000		/* Maximum number of points per polyline */
/*#define GEOM_EPSILON 1.0e-14*/         /* Approximation of zero */
#define SQRhf M_SQRT1_2
#define TWO_PI 2*M_PI
#define PI6 M_PI/6.0
#define RADIUS 0.02

typedef double COORD;
/*typedef COORD POINT[2];*/         /* Most data is cartesian points */
/*typedef COORD HOMOG[3];*/         /* Some partial calculations are homogeneous */

#define POINT Pt
#define HOMOG Pt

/*#define XX 0
#define YY 1
#define WW 2*/
#define V(P, i) ((P)->points+((i) % (P)->numPoints))

typedef struct POLYGON { 
  int n,                        /* Number of vertices in polygon */
  st,				/* Tangent indices */
  tent,				/* Index of tentative refinement */
  end,				/* Tangent is in $(\st, \end]$ */
  ccw,				/* 1 = ccw  -1 = cw */
  wrap;                         /* Boolean indicates wraparound */
  int lo, hi;			/* Voronoi vertex indices */
  int result;
  HOMOG tang;			/* Current tangent when refined */
  POINT v[MAXPTS];
} POLYGON;

#define MIN(a,b) ( a < b ? a : b)
#define MAX(a,b) ( a > b ? a : b)
#define SGN(x) (x < 0 ? -1 : 1)

#define DET2x2(p, q, i, j) ((p)->i*(q)->j - (p)->j*(q)->i) /* Determinants */
#define DET2(p, q) DET2x2(p,q, x,y) 
#define DET3C(p, q, r) DET2(q,r) - DET2(p,r) + DET2(p,q)
#define DET3(p, q, r) (p)->w*DET2(q,r) - (q)->w*DET2(p,r) + (r)->w*DET2(p,q)

#define CROSS_2CCH(p, q, r) /* 2-d cartesian to homog cross product */\
  (r)->w =   DET2(p, q);\
  (r)->x = - (q)->y + (p)->y;\
  (r)->y =   (q)->x - (p)->x;
#define CROSS_2SCCH(s, p, q, r) /* 2-d cartesian to homog cross product with sign*/\
  (r)->w = s * DET2(p, q);\
  (r)->x = s * (- (q)->y + (p)->y);\
  (r)->y = s * ((q)->x - (p)->x);
#define CROSS_2H(p, q, r) /* 2-d cartesian to homog cross product */\
  (r)->w =   DET2x2(p, q, x, y);\
  (r)->x = - DET2x2(p, q, w, y);\
  (r)->y =   DET2x2(p, q, w, x);

#define DOT_2CH(p, q)       /* 2-d cartesian to homog dot product */\
  ((q)->w + (p)->x*(q)->x + (p)->y*(q)->y)
#define DOT_2C(p, q)       /* 2-d cartesian  dot product */\
  ((p)->x*(q)->x + (p)->y*(q)->y)
#define DOT_2H(p, q)       /* 2-d  homog dot product */\
  ((p)->w*(q)->w + (p)->x*(q)->x + (p)->y*(q)->y)


#define PERP_C(ln, a, lp) /* Make $lp$ perpendicular to $ln$ through $a$ (rotate cw) */\
	(lp)->x = (ln)->y; (lp)->y = - (ln)->x; (lp)->w = -DOT_2C(lp, a);

#define BISECT_C(a, b, ln) /* Make bisector of \seg{ab} w/ a LEFT, b RT */\
	(ln)->x = 2 * ((a)->x - (b)->x); (ln)->y = 2 * ((a)->y - (b)->y);\
	(ln)->w = DOT_2C(b, b) - DOT_2C(a, a);

#define PERP_H(ln, a, lp)	/* Make $lp$ perpendicular to $ln$ through $a$ (rotate cw) */\
  (lp)->x = (ln)->y * (a)->w; (lp)->y = - (ln)->x * (a)->w; \
  (lp)->w = -(ln)->y * (a)->x + (ln)->x * (a)->y;

#define BISECT_H(a, b, ln) /* Make bisector of \seg{ab} w/ a LEFT, b RT */\
	(ln)->x = 2 * (a)->w * (b)->w * ((b)->w * (a)->x - (a)->w * (b)->x); \
	(ln)->y = 2 * (a)->w * (b)->w * ((b)->w * (a)->y - (a)->w * (b)->y); \
	(ln)->w = (a)->w * (a)->w * DOT_2C(b, b) - (b)->w * (b)->w * DOT_2C(a, a);

#define BISECT_CH(a, b, ln) /* Make bisector of \seg{ab} w/ a LEFT, b RT */\
	(ln)->x = 2 * (b)->w * ((b)->w * (a)->x - (b)->x); \
	(ln)->y = 2 * (b)->w * ((b)->w * (a)->y - (b)->y); \
	(ln)->w = DOT_2C(b, b) - (b)->w * (b)->w * DOT_2C(a, a);

#define LEFT(x) (x > GEOM_EPSILON) /* Sidedness tests */
#define RIGHT(x) (x < -GEOM_EPSILON)
#define LEFT_PL(p, l) LEFT(DOT_2CH(p, l))
#define RIGHT_PL(p, l) RIGHT(DOT_2CH(p, l))
#define LEFT_PPP(p, q, r) LEFT(DET3C(p, q, r))
#define RIGHT_PPP(p, q, r) RIGHT(DET3C(p, q, r))

#define ASSIGN_H(p, op, q)	/* homog assignment */\
  (p)->w op (q)->w;  (p)->x op (q)->x;  (p)->y op (q)->y;

#define LINCOMB_2C(a, p, b, q, r) /* 2-d cartesian linear combination */\
  (r)->x = (a) * (p)->x + (b) * (q)->x;\
  (r)->y = (a) * (p)->y + (b) * (q)->y;

extern int gr_verbose, verbose; /* debugging */
extern double pr();
extern void Tang(), drawSeg(), drawLine(), displayAll();

#endif

