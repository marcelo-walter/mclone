
#ifndef DISTANCE_DEFS

#define DISTANCE_DEFS

#include "geometry.h"
#include "polygon.h"

#ifdef __cplusplus
extern "C" {
#endif

void getSweeplineTan(Pt *tanPt);
void getExitPoint(Pt *start, Pt *end, Pt *exitPt);

void pointDistance(Pt *point1, Pt *point2, Real *dist);
void squarePointDistance(Pt *point1, Pt *point2, Real *dist);
void vectorLength(Pt *point, Real *length);

Boolean outerCommonTangent(Pgon *startPgon, Pgon *finishPgon, Pt *start, 
        Pt *end, int *startIndex, int *finishIndex);

#ifdef Hack
Boolean segmentSharesPoint (Pgon *segment, Pt *point, UInt16 *segEnd);
Boolean segmentsShareCommonEnd (Pgon *p1, Pgon *p2, UInt16 *endP1, 
                                UInt16 *endP2);
#endif

#ifdef __cplusplus
}
#endif

#endif

