#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "geometry.h"
#include "polygon.h"
#include "sweep.h"
#include "voronoi.h"

/* Changed by Thompson Lied in 05/06/2002 
  #include "../oncaViewer/Macros.h"
  #include "../oncaViewer/Types.h"
*/
#include "Macros.h"
#include "Types.h"


void
endProgram(Pgon **polyPtrs, int numPoly)
{
  int	i;
  
  for (i = 0; i < numPoly; i++)
    killPolygon (&(polyPtrs[i]));
  free (polyPtrs);	
}

typedef struct {
  Pt      vorPoint;
  UInt32  count;
  Pgon    *polygon[3];
} VtxInfoType;

typedef struct {
  VtxInfoType  *vtxTable;
  UInt32       vtxCount;
  UInt32       maxVtxCount;
}  VorVtxListType;


/* Build up the Voronoi vertices in a giant array.  This procedure
   is called when a Voronoi vertex is found. */
static Ptr 
LAKE_FoundVoronoiVertex (Pt *theVertexPtr, SWP_VoronoiVertexType ignore, 
                         Ptr context)
{
	long            retVal = 0;
	VorVtxListType  *contextPtr = (VorVtxListType *) context;

	if ((theVertexPtr->w != 0.0) && 
		(contextPtr->vtxCount+1 < contextPtr->maxVtxCount)) {

		/* The vertex isn't at infinity and we have space for it.
		   Let's keep it. */

		contextPtr->vtxCount += 1;
		retVal = contextPtr->vtxCount;
		contextPtr->vtxTable[retVal].vorPoint = *theVertexPtr;
		contextPtr->vtxTable[retVal].count = 0;
	}

	return (Ptr) retVal;
}

/* Call this function once for each site around a Voronoi vertex.
   The sites should come in ccw order around the vertex.  These
   sites are stored with the Voronoi vertex. */

static void
LAKE_SiteForVertex (Ptr theVertexRef, Pgon *theSite, Ptr context)
{
	VorVtxListType  *contextPtr = (VorVtxListType *) context;

	contextPtr->vtxTable[(UInt32)theVertexRef].polygon
				[contextPtr->vtxTable[(UInt32)theVertexRef].count] = theSite;
	contextPtr->vtxTable[(UInt32)theVertexRef].count += 1;
	contextPtr->vtxTable[(UInt32)theVertexRef].vorPoint.z = theSite->points[0].z;
}

/* Call this routine once for each Voronoi vertex around a site.
   The Voronoi vertices should come in ccw order around the site.
   We cache these points in the polygon itself. */

static void
LAKE_VorVtxForSite (Pgon *theSite, Ptr vorVertexRef, Ptr ignored )
{
#if 0
	if (theSite->voronoiList == NULL) {
		theSite->voronoiList = Alloc_Array( int, 1 );
	} else {	
		theSite->voronoiList = Grow_Array( int, 1, theSite->voronoiList );
	}
#endif
	theSite->voronoiList[theSite->voronoiCount] = (int) vorVertexRef;
	theSite->voronoiCount += 1;
}


void
getContextSpace( int polyCount, VorVtxListType *vtxInfo, 
                 SWP_UserRoutinesType *rtns )
{

	/* I need some local space to build up the complete
	   Voronoi diagram before it is distilled into the medial axis. */

	vtxInfo->maxVtxCount = polyCount * 3;

	vtxInfo->vtxCount = 0;
	vtxInfo->vtxTable = (VtxInfoType *)malloc(
			   sizeof(VtxInfoType) * vtxInfo->maxVtxCount);
	memset(vtxInfo->vtxTable, 0, sizeof(VtxInfoType) * vtxInfo->maxVtxCount);

	/* Set up the routines to trap the Voronoi vertices. */

	rtns->convexHullRtn       = NULL;
	rtns->startSiteEventRtn   = NULL;
	rtns->startCircleEventRtn = NULL;
	rtns->sweepRtn            = NULL;
	rtns->spokeSearchRtn      = NULL;
	rtns->vorVtxSearchRtn     = NULL;
	rtns->vorVtxForSiteRtn    = LAKE_VorVtxForSite;
	rtns->foundVorVtxRtn      = LAKE_FoundVoronoiVertex;
	rtns->siteForVorVtxRtn    = LAKE_SiteForVertex;
	rtns->contextPtr          = (Ptr)(vtxInfo);
}

void
freeContextSpace( VorVtxListType *vtxInfo )
{
	free (vtxInfo->vtxTable);
}

		
void
getVoronoi(SCELL *headCell, SCELL *tailCell, 
           voronoiType **vorList, faceType **faceList, int *howManyVert)
{
  int  howManySites = 0;
  int  count = 0;
  Pt   pt;
  SCELL *runner;
  int  i, j;
  Pgon **polyPtrs;
#ifdef saveOutput
  FILE *outfile;
#endif
	SWP_UserRoutinesType rtns;
  VorVtxListType vtxInfo;
  Boolean useFast;
  
  useFast = True;

  /*print_list(headCell,tailCell);*/
  /* Find out how many sites I have. */

  runner = headCell->next;
  while (runner != tailCell) {
    howManySites += 1;
    runner = runner->next;
  }

  /* Convert all the sites into polygons. */
  
  if((polyPtrs = (Pgon **) malloc (sizeof(Pgon *) * howManySites))==NULL){
    printf("Problem with malloc in linkMyCode.c!\n");
    exit(0);
  }
#ifdef saveOutput
  outfile = fopen("list.of.points", "w");
#endif

  runner = headCell->next; 
  while (runner != tailCell) {
    pt.w = 1.0;
    pt.x = runner->p.x;
    pt.y = runner->p.y;
    polyPtrs[count] = newPolygon(1, &pt);
    polyPtrs[count]->origin = (Ptr) runner->originalCell;
#ifdef saveOutput
    fprintf(outfile, "%f %f\n", pt.x, pt.y);
#endif
    count++;
    runner = runner->next;
  }

  /* Allocate space for the Voronoi code. */

  getContextSpace( howManySites, &vtxInfo, &rtns );
	SWP_FindVoronoiVertices (howManySites, polyPtrs, &rtns);

  /* The whole Voronoi diagram has now been computed.  Translate
     all the information into the appropriate output format. */
  *vorList = (voronoiType *) malloc(sizeof(voronoiType) * (vtxInfo.vtxCount+1));
  *faceList = (faceType *) malloc(sizeof(faceType) * howManySites);
 
  if ((*vorList != NULL) && (*faceList != NULL)) {
    /* Transfer all the Voronoi points.  The structure for backVorPoints
       is in the file voronoi.h */

    for (i = 1; i <= vtxInfo.vtxCount; i++) {
      (*vorList)[i].x = XVal(vtxInfo.vtxTable[i].vorPoint);
      (*vorList)[i].y = YVal(vtxInfo.vtxTable[i].vorPoint);
      (*vorList)[i].sites[0] = (CELL *)vtxInfo.vtxTable[i].polygon[0]->origin;
      (*vorList)[i].sites[1] = (CELL *)vtxInfo.vtxTable[i].polygon[1]->origin;
      (*vorList)[i].sites[2] = (CELL *)vtxInfo.vtxTable[i].polygon[2]->origin;
    }

    *howManyVert = vtxInfo.vtxCount;

    /* Transfer the face information. */
    for (i = 0; i < howManySites; i++) {
      (*faceList)[i].faceSize = polyPtrs[i]->voronoiCount;
      for (j = 0; j < polyPtrs[i]->voronoiCount; j++) {
        (*faceList)[i].vorPts[j] = polyPtrs[i]->voronoiList[j];
      }
      (*faceList)[i].site = (CELL *)polyPtrs[i]->origin;
    }
  }
  else{
    printf("Problem with malloc in linkMyCode.c!\n");
    exit(2);
  }

  freeContextSpace( &vtxInfo );

#ifdef saveOutput
  fclose(outfile);
#endif 

  /* Get rid of the space allocated by the Voronoi routines. */
  endProgram(polyPtrs, howManySites);
}


