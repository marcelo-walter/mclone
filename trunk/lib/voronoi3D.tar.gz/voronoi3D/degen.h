
#ifndef _degen_h_
#define _degen_h_

#include "sub.h"
#include "geometry.h"

int pointOnSegEnd2ndIsPoint (GEOM_DirectionType direction, 
                             pointType a, pointType b, pointType c, pointType e,
                             pointType center, pointType i);
int pointOnSegEnd2ndIsSeg (GEOM_DirectionType direction,
                           pointType a, pointType b, pointType c, pointType d,
                           pointType e, pointType f, pointType center, 
                           pointType i, pointType j);
int segOnSegEnd2ndIsPoint (GEOM_DirectionType direction,
                           pointType a, pointType b, pointType c, pointType d,
                           pointType e, pointType center, pointType i,
                           pointType j);

#endif

