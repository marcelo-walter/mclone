
/******************************************************************
; Module:  Red-Black Trees
;
; description:
;   This module implements a red-black tree (a height-balanced
;   binary tree).
;
;   The code is based on an initial implementation by from Jim Boritz
;   where he states:
;
;     Based primarily on Red-Black Tree code in Corman, Leiserson & Rivest
;     Introduction to Algorithms p. 248 - 
;     The idea of having a dummy head node and a dummy common leaf
;     node comes from Sedgewick, Algorithms in C
;
;   Jim's original code was much, much, much shorter than what
;   appears here.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.01.13 / M. McAllister / RBTREE_Alloc
;   95.03.17 / M. McAllister / RBTREE_Delete
;   95.03.20 / M. McAllister / FreeAllTreeNodes
;   95.03.28 / M. McAllister / AllocateNode, RBTREE_Previous, RBTREE_FindNode,
;                              RBTREE_Delete
;   95.10.23 / M. McAllister / RotateLeft, RotateRight, RBTREE_AddAfterNode, 
;                              RBTREE_Delete, RecursiveNodeAudit, AllocateNode
;   96.03.04 / M. McAllister / Global change to allow tree size to be
;                              bigger than a UInt16
;   97.04.16 / M. McAllister / Make alarms optional at compile time
*******************************************************************/

#include <string.h>
#include <stdlib.h>

#include "globals.h"
#include "rbtreeDefs.h"
#include "rbtree.h"

#ifdef enableAlarms
#include "rbtreeAlarms.h"
#include "alarm.h"
#endif /* enableAlarms */

/*********************************************************************
; Forward declaration of all internal routines.
**********************************************************************/

static RBTREE_NodeType AllocateNode(RBTREE_TreeType theTree);
static void FreeNode (RBTREE_NodeType theNode);
static void RotateLeft (RBTREE_TreeType theTree, RBTREE_NodeType theNode);
static void RotateRight (RBTREE_TreeType theTree, RBTREE_NodeType theNode);
static void DeleteFixUp (RBTREE_TreeType theTree, RBTREE_NodeType theNode);
static Boolean ForEachNode (RBTREE_NodeType theNode,
                   Boolean (*callRtn)(Ptr dataPtr, Ptr arg), Ptr arg);
static void FreeAllTreeNodes (RBTREE_TreeType theTree, RBTREE_NodeType nodePtr);
static Boolean RebalanceAdd (RBTREE_TreeType theTree, RBTREE_NodeType theNode);
static Boolean RecursiveNodeAudit(RBTREE_TreeType theTree, 
                   RBTREE_NodeType theNode, RBTREE_NodeType parent, 
                   UInt32 *nodeCountPtr, UInt32 *blackCountToLeaf);

#ifdef paranoid
static Boolean InitSemaphore (SemaphoreType *theSem);
static Boolean ReadAccessSemaphore (SemaphoreType *theSem);
static Boolean ModifyAccessSemaphore (SemaphoreType *theSem);
static void UnlockSemaphore (SemaphoreType *theSem);
static void DestroySemaphore (SemaphoreType *theSem);
#endif /* paranoid */

/******************************************************************
; routine:  RBTREE_Alloc
;
; description:
;   Create an empty red-black tree.
;
; in:
;   cmpRtn -- the comparison routine to be used among the nodes
;             of the tree.
;   name : Char * -- an identification name for the tree; only used for
;                    debugging purposes.
;
; out:
;   returns : RBTREE_TreeType -- an identifier for the tree.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.01.13 / M. McAllister / Made function prototype ANSI compliant
*******************************************************************/
RBTREE_TreeType 
RBTREE_Alloc (SInt16 (*cmpRtn)(Ptr key1, Ptr key2), Char *name)
{
  RBTREE_TreeType theTree;
  UInt16          nameLength;
  
  theTree = (RBTREE_TreeType) malloc(sizeof(_RBTREE_TreeInfoType));
  if (theTree == NULL) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_NoMainMemory, AL_Fn_NullFunction, 0,0,0,0);
#endif /* enableAlarms */
    theTree = RBTREE_NullTree;
  } else {

#ifdef paranoid

    /* Memory guards for the tree information */

    theTree->headGuard = _RBTREE_TreeHeadTag;
    theTree->tailGuard = _RBTREE_TreeTailTag;
    
    if (InitSemaphore (&(theTree->treeLock)) == False) {
      /* Without a semaphore, we aren't going to use the tree. */

      free (theTree);
      theTree = RBTREE_NullTree;
    } else {

#endif /* paranoid */

      /* Set up the fields of the tree itself */

      theTree->count = 0;
      theTree->compareRoutine = cmpRtn;
      nameLength = strlen (name);
      strncpy (theTree->name, name, Min(nameLength, _RBTREE_MaxNameSize));
    
      theTree->nilNode = AllocateNode (theTree);

      /* The allocate node routine will fail to set up the proper set of
         nil node pointers since that is what the routine itself is
         allocating.  Set them properly on the nil node. */

      theTree->nilNode->rightPtr  = theTree->nilNode;
      theTree->nilNode->leftPtr   = theTree->nilNode;
      theTree->nilNode->parentPtr = theTree->nilNode;

      theTree->head = AllocateNode (theTree);
#ifdef paranoid
    } /* initSemaphore success/fail */
#endif /* paranoid */
  }

  return theTree;
}

/******************************************************************
; routine:  FreeAllTreeNodes
;
; description:
;   Performs a recursive descent of a binary tree and frees all the
;   nodes that it finds.  This includes releasing the root of the
;   tree.  The routine does not release any data pointers that are
;   stored in the data portion of the nodes.
;
;   The caller is responsible for deleting all references it has to
;   the tree's root. 
;
; in:
;   theTree : RBTREE_TreeType -- the tree to which all the nodes belong
;   nodePtr : RBTREE_NodeType -- the root of the binary tree that
;                                is to be released.
;
; out:
;   none
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.03.20 / M. McAllister / Was checking leftPtr to free right subtree.
*******************************************************************/
static void
FreeAllTreeNodes (RBTREE_TreeType theTree, RBTREE_NodeType nodePtr)
{
#ifdef paranoidCheck
  /* Don't release nodes when they don't belong to the given tree.
     When bad nodes are found, we really should send out an alarm. TBD */

  if (nodePtr->parentTreePtr != theTree) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_NodeInWrongTree, 
                      AL_Fn_RBTREE_FreeAllTreeNodes, 
                      (UInt32) nodePtr, (UInt32) theTree, 0, 0);
#endif /* enableAlarms */
  } else {
#endif /* paranoidCheck */

    if (nodePtr->leftPtr != theTree->nilNode) {
      FreeAllTreeNodes (theTree, nodePtr->leftPtr);
    }
    if (nodePtr->rightPtr != theTree->nilNode) {
      FreeAllTreeNodes (theTree, nodePtr->rightPtr);
    }

    if (nodePtr != theTree->nilNode) {
      FreeNode (nodePtr);
    }

#ifdef paranoidCheck
  }
#endif /* paranoidCheck */
}

/******************************************************************
; routine:  RBTREE_Free
;
; description:
;   Destroy a red-black tree.  All the nodes in the designated
;   tree are returned to the system and then the tree identifier
;   is releases.
;
; in:
;   theTree : RBTREE_TreeType -- the red-black tree to be released
;
; out:
;   none
;
; implementation note:
;   The routine does not release memory pointed to by the data
;   pointers in the nodes of the tree.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
void
RBTREE_Free (RBTREE_TreeType theTree)
{
  if (theTree == RBTREE_NullTree) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_NullTree, AL_Fn_RBTREE_Free, 0, 0, 0, 0);
#endif /* enableAlarms */
  } else {
#ifdef paranoidCheck
	/* Don't free up any memory if it has been corrupted.  It may
	   not even be a tree! */

	if ((theTree->headGuard != _RBTREE_TreeHeadTag) ||
		(theTree->tailGuard != _RBTREE_TreeTailTag)) {
#ifdef enableAlarms
	  AL_SoftwareAlarm (AL_Id_RBTREE_MemoryGuards, AL_Fn_RBTREE_Free,
						theTree->headGuard, theTree->tailGuard, 0, 0);
#endif /* enableAlarms */
	} else {
#endif /* paranoidCheck */

	  /* Get rid of any nodes attached to this tree.  This same
		 recursive pass will eliminate the tree's head node so
		 it does not need to be released later. */

	  FreeAllTreeNodes (theTree, theTree->head);

	  /* Destroy all the really relevant fields for the tree. */

	  theTree->count = 0;
	  theTree->compareRoutine = NULL;
	
	  FreeNode (theTree->nilNode);

#ifdef paranoid

	  /* Clear all relevant pointers in case of an old pointer lurking around */
	  theTree->nilNode = NULL;
	  theTree->head = NULL;
	
	  /* Get rid of all the safety features too */

	  DestroySemaphore (&theTree->treeLock);
	  theTree->headGuard = 0;
	  theTree->tailGuard = 0;

      free (theTree);

#endif /* paranoid */

#ifdef paranoidCheck
    } /* memory guard check */
#endif /* paranoidCheck */
  }
}

RBTREE_NodeType
TreeMinimum(RBTREE_TreeType theTree, RBTREE_NodeType x)
{
#ifdef paranoid
  if (x == NULL) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_BadNode, AL_Fn_RBTREE_TreeMinimum, 0,0,0,0);
#endif /* enableAlarms */
  } else {
#endif

    while (x->leftPtr != theTree->nilNode) {
      x = x->leftPtr;
    }
#ifdef paranoid
  }
#endif

  return x;
}

RBTREE_NodeType
TreeMaximum(RBTREE_TreeType theTree, RBTREE_NodeType x)
{
#ifdef paranoid
  if (x == NULL) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_BadNode, AL_Fn_RBTREE_TreeMaximum, 0,0,0,0);
#endif /* enableAlarms */
  } else {
#endif

  while (x->rightPtr != theTree->nilNode) {
    x = x->rightPtr;
  }
#ifdef paranoid
  }
#endif

  return x;
}

/******************************************************************
; routine:  RBTREE_Next
;
; description:
;   Find the node in the red-black tree that immediately follows
;   currentNode in the sequential ordering of the tree.
;
;   The routine returns a NULL value if currentNode is the last
;   node in the tree.
;
; in:
;   theTree : RBTREE_TreeType -- the tree in which we are searching
;   currentNode : RBTREE_NodeType -- the node whose successor we want
;                                    to find.  A value of RBTREE_NullNode
;                                    will produce the first node in the
;                                    ordering.
;
; out:
;   returns : RBTREE_NodeType -- the successor node.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
RBTREE_NodeType 
RBTREE_Next (RBTREE_TreeType theTree, RBTREE_NodeType currentNode)
{
  RBTREE_NodeType y;
  RBTREE_NodeType nextPtr = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit (theTree) == True) {
    if  ((currentNode != RBTREE_NullNode) && 
         (currentNode->parentTreePtr != theTree)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_RBTREE_NodeInWrongTree, AL_Fn_RBTREE_Next,
                        (UInt32) currentNode, (UInt32) theTree, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoidCheck */

	  if (currentNode == RBTREE_NullNode) {
		nextPtr = TreeMinimum(theTree, theTree->head->rightPtr);
	  } else {
		if (currentNode->rightPtr != theTree->nilNode) {
		  nextPtr = TreeMinimum(theTree, currentNode->rightPtr);
		} else {
		  y = currentNode->parentPtr;
		  while (y != theTree->head && currentNode == y->rightPtr) {
			currentNode = y;
			y = y->parentPtr;
		  }
		  nextPtr = (y == theTree->nilNode || y == theTree->head) ? 
					   RBTREE_NullNode : y;
		}
	  }

#ifdef paranoidCheck
    } /* check on currentNode */
  } /* structure audit */
#endif /* paranoidCheck */

  return nextPtr;
}

/******************************************************************
; routine:  RBTREE_Previous
;
; description:
;   Find the node in the red-black tree that immediately precedes
;   currentNode in the sequential ordering of the tree.
;
;   The routine returns a NULL value if currentNode is the first
;   node in the tree.
;
; in:
;   theTree : RBTREE_TreeType -- the tree in which we are searching
;   currentNode : RBTREE_NodeType -- the node whose predecessor we want
;                                    to find.  A value of RBTREE_NullNode
;                                    will produce the last node in the
;                                    ordering.
;
; out:
;   returns : RBTREE_NodeType -- the predecessor node.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.03.19 / M. McAllister / Removed "return" from middle of routine
;   95.03.28 / M. McAllister / Missing else inside the paranoidCheck clause
*******************************************************************/
RBTREE_NodeType 
RBTREE_Previous (RBTREE_TreeType theTree, RBTREE_NodeType currentNode)
{
  RBTREE_NodeType y;
  RBTREE_NodeType prevPtr = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit (theTree) == True) {
    if ((currentNode != RBTREE_NullNode) && 
       (currentNode->parentTreePtr != theTree)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_RBTREE_NodeInWrongTree, AL_Fn_RBTREE_Previous,
                        (UInt32) currentNode, (UInt32) theTree, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoidCheck */

	  if (currentNode == RBTREE_NullNode) {
		prevPtr = TreeMaximum(theTree, theTree->head->rightPtr);
	  } else {
		if (currentNode->leftPtr != theTree->nilNode) {
		  prevPtr = TreeMaximum(theTree, currentNode->leftPtr);
		} else {
		  y = currentNode->parentPtr;
		  while (y != theTree->head && currentNode == y->leftPtr) {
			currentNode = y;
			y = y->parentPtr;
		  }
		  prevPtr = (y == theTree->nilNode || y == theTree->head) ? NULL : y;
		}
	  }

#ifdef paranoidCheck
    } /* check on currentNode */
  } /* structure audit */
#endif /* paranoidCheck */

  return prevPtr;
}

/******************************************************************
; routine:  RotateLeft
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static void
RotateLeft(RBTREE_TreeType theTree, RBTREE_NodeType x)
{
  RBTREE_NodeType y, z;
  UInt32          alpha, beta, gamma;

  z = theTree->nilNode;
  y = x->rightPtr;

  /* Lastly, fix up the subtree sizes. */

  alpha = (x->leftPtr  == z ? 0 : x->leftPtr->subtreeSize);
  beta  = (y->leftPtr  == z ? 0 : y->leftPtr->subtreeSize);
  gamma = (y->rightPtr == z ? 0 : y->rightPtr->subtreeSize);

  x->subtreeSize = alpha + beta + 1;
  y->subtreeSize = x->subtreeSize + gamma + 1;

  /* Now do the pointer rotations. */

  x->rightPtr = y->leftPtr;
  if (y->leftPtr != z) {
    y->leftPtr->parentPtr = x;
  }
  y->parentPtr = x->parentPtr;

  /* some simplification here, code from the book does an explicit root op */
  if (x == x->parentPtr->leftPtr) {
    x->parentPtr->leftPtr = y;
  }
  else {
    x->parentPtr->rightPtr = y;
  }
  y->leftPtr = x;
  x->parentPtr = y;
}

/******************************************************************
; routine:  RotateRight
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static void
RotateRight(RBTREE_TreeType theTree, RBTREE_NodeType y)
{
  RBTREE_NodeType x, z;
  UInt32          alpha, beta, gamma;

  z = theTree->nilNode;
  x = y->leftPtr;

  /* First, fix up the subtree sizes. */

  alpha = (x->leftPtr  == z ? 0 : x->leftPtr->subtreeSize);
  beta  = (x->rightPtr == z ? 0 : x->rightPtr->subtreeSize);
  gamma = (y->rightPtr == z ? 0 : y->rightPtr->subtreeSize);

  y->subtreeSize = gamma + beta + 1;
  x->subtreeSize = y->subtreeSize + alpha + 1;

  /* Next, do the actual rotation. */

  y->leftPtr = x->rightPtr;
  if (x->rightPtr != z) {
    x->rightPtr->parentPtr = y;
  }
  x->parentPtr = y->parentPtr;
  if (y == y->parentPtr->rightPtr) {
    y->parentPtr->rightPtr = x;
  }
  else {
    y->parentPtr->leftPtr = x;
  }
  x->rightPtr = y;
  y->parentPtr = x;
}

/******************************************************************
; routine:  RebalanceAdd
;
; description:
;   Rebalances the red-black tree after a node has been inserted.
;   The inserted node, which must be a leaf node, is supplied
;   to this routine.
;
; in:
;   theTree : RBTREE_TreeType -- the red-black tree to which the
;                                data was added
;   theNode : RBTREE_NodeType -- the leaf node in the red-black
;                       tree that was added.
;
; out:
;   returns : Boolean -- True if the rebalancing succeeded, False
;                        if the rebalancing failed.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static Boolean
RebalanceAdd (RBTREE_TreeType theTree, RBTREE_NodeType theNode)
{
  RBTREE_NodeType x, y;
  Boolean         rebalanceOkay = True;

  x = theNode;
  x->colour = _RBTREE_Red;

  while (x->parentPtr->colour == _RBTREE_Red) {
    if (x->parentPtr == x->parentPtr->parentPtr->leftPtr) {
      y = x->parentPtr->parentPtr->rightPtr;
      if (y->colour == _RBTREE_Red) {
        x->parentPtr->colour = _RBTREE_Black;
        y->colour = _RBTREE_Black;
        x->parentPtr->parentPtr->colour = _RBTREE_Red;
        x = x->parentPtr->parentPtr;
      }
      else {
        if (x == x->parentPtr->rightPtr) {
          x = x->parentPtr;
          RotateLeft(theTree, x);
        }
        x->parentPtr->colour = _RBTREE_Black;
        x->parentPtr->parentPtr->colour = _RBTREE_Red;
        RotateRight(theTree, x->parentPtr->parentPtr);
      }
    }
    else {
      y = x->parentPtr->parentPtr->leftPtr;
      if (y->colour == _RBTREE_Red) {
        x->parentPtr->colour = _RBTREE_Black;
        y->colour = _RBTREE_Black;
        x->parentPtr->parentPtr->colour = _RBTREE_Red;
        x = x->parentPtr->parentPtr;
      }
      else {
        if (x == x->parentPtr->leftPtr) {
          x = x->parentPtr;
          RotateRight(theTree, x);
        }
        x->parentPtr->colour = _RBTREE_Black;
        x->parentPtr->parentPtr->colour = _RBTREE_Red;
        RotateLeft(theTree, x->parentPtr->parentPtr);
      }
    }
  }
  theTree->head->rightPtr->colour = _RBTREE_Black;

  return rebalanceOkay;
}

/******************************************************************
; routine:  RBTREE_AddAfterNode
;
; description:
;   Insert a value into the red-black tree so that it immediately
;   follows a particular node in the sequential ordering of the
;   tree.  The routine creates a completely new node for the data 
;   to be inserted.
;
;   Typically, the RBTREE_Add routine should always be used to 
;   insert data (since it ensures that all data remains sorted).
;   However, some applications may not have a simple ordering function
;   and may wish to control the insertion process more stringently.
;
;   The caller to this routine is responsible for ensuring that the
;   resulting data structure will pass the audit routine on the
;   red-black tree.
;
; in:
;   theTree : RBTREE_TreeType -- the red-black tree to which the
;                                data will be added
;   afterNode : RBTREE_NodeType -- the node after which the data
;                                  should appear in the sequential
;                                  ordering of the tree.
;   addDataPtr : Ptr -- the data to add to the tree.  This data
;                       must be suitable as a parameter to the
;                       tree's comparison routine
;
; out:
;   addedNode : RBTREE_NodeType * -- an identifier for the node added
;                                    to the tree.
;   returns : Boolean -- True if the insertion succeeded, False
;                        if the insertion failed.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.10.23 / M. McAllister / Increment subtreeSize in nodes from 
;                              added node to the root before rebalancing
*******************************************************************/
Boolean 
RBTREE_AddAfterNode (RBTREE_TreeType theTree, 
                     RBTREE_NodeType afterNode, Ptr addDataPtr,
                     RBTREE_NodeType *addedNode)
{
  RBTREE_NodeType parentPtr;
  RBTREE_NodeType runner;
  Boolean         insertOkay = False;

  *addedNode = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit (theTree) == True) {
    if ((afterNode != RBTREE_NullNode) && 
       (afterNode->parentTreePtr != theTree)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_RBTREE_NodeInWrongTree, AL_Fn_RBTREE_AddAfterNode,
                        (UInt32) afterNode, (UInt32) theTree, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoidCheck */

#ifdef paranoid
      if (ModifyAccessSemaphore(&(theTree->treeLock)) == True) {
#endif /* paranoid */

		/* Create and fill the new node. */

		*addedNode            = AllocateNode (theTree);
		(*addedNode)->dataPtr = addDataPtr;
	
		/* Find the new node's parent in the red-black tree and link in 
		   the parent/child pointers. */
	  
		if (afterNode == RBTREE_NullNode) {
		  if (theTree->head->rightPtr == theTree->nilNode) {
			parentPtr = theTree->head;
			theTree->head->rightPtr = *addedNode;
		  } else {
			parentPtr = TreeMinimum (theTree, theTree->head->rightPtr);
			parentPtr->leftPtr = *addedNode;
		  }
		} else {
		  if (afterNode->rightPtr == theTree->nilNode) {
			parentPtr = afterNode;
			afterNode->rightPtr = *addedNode;
		  } else {
			parentPtr = TreeMinimum (theTree, afterNode->rightPtr);
			parentPtr->leftPtr = *addedNode;
		  }
		}
	
		(*addedNode)->parentPtr = parentPtr;

        /* Update the subtree sizes along the path from this node to the
           tree root. */

        runner = (*addedNode)->parentPtr;
        while (runner != theTree->head) {
          runner->subtreeSize += 1;
          runner = runner->parentPtr;
        }
	
		/* Finish up by re-establishing the red-black properties on the tree. */

		theTree->count += 1;
		insertOkay = RebalanceAdd (theTree, *addedNode);

#ifdef paranoid
        UnlockSemaphore(&(theTree->treeLock));
      } /* get write semaphore */
#endif /* paranoid */

#ifdef paranoidCheck
    } /* check parentage of afterNode */
  } /* structure audit */
#endif

  return insertOkay;
}

/******************************************************************
; routine:  RBTREE_Add
;
; description:
;   Insert a value into the red-black tree.  The routine creates
;   a completely new node for the data to be inserted.
;
; in:
;   theTree : RBTREE_TreeType -- the red-black tree to which the
;                                data will be added
;   addDataPtr : Ptr -- the data to add to the tree.  This data
;                       must be suitable as a parameter to the
;                       tree's comparison routine
;
; out:
;   addedNode : RBTREE_NodeType * -- an identifier for the node added
;                                    to the tree.
;   returns : Boolean -- True if the insertion succeeded, False
;                        if the insertion failed.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
Boolean
RBTREE_Add (RBTREE_TreeType theTree, Ptr addDataPtr, RBTREE_NodeType *addedNode)
{
  RBTREE_NodeType predecessor;
  Boolean         ignored;
  Boolean         addOkay = False;

  *addedNode = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit (theTree) == True) {
#endif /* paranoidCheck */

    /* No locks on the tree are claimed here since this routine
       does no work on its own and only uses the same set of
       interfaces that any user would use.  Those interfaces take
       care of getting the appropriate locks. */
  
    ignored = RBTREE_FindNode (theTree, addDataPtr, &predecessor);
    addOkay = RBTREE_AddAfterNode (theTree, predecessor, addDataPtr, addedNode);

#ifdef paranoidCheck
  } /* structure audit */
#endif /* paranoidCheck */

  return addOkay;
}

/******************************************************************
; routine:  RBTREE_Delete
;
; description:
;   Remove a node from a red-black tree.  The node must belong
;   to a valid tree for the deletion to succeed.
;
; in:
;   deleteNode : RBTREE_NodeType -- the tree node to be removed
;
; out:
;   returns : Boolean -- True if the deletion succeeded, False
;                        if the deletion failed.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.03.17 / M. McAllister / Problem when deleteNode is a leaf left 
;                              child of the root.
;   95.03.17 / M. McAllister / Parent pointer on "x" reset to deleted node
;                          when deleting root and tree has root and right child
;   95.10.23 / M. McAllister / Decrement the subtreeSize on deletions
*******************************************************************/
Boolean
RBTREE_Delete (RBTREE_NodeType deleteNode)
{
  RBTREE_NodeType     x, y;
  RBTREE_NodeType     nilPtr;
  RBTREE_NodeType     runner;
  RBTREE_NodeType     yParent;
  RBTREE_TreeType     myTreePtr;
  Boolean             deleteOkay = False;
  _RBTREE_ColourType  oldColour;

  if (deleteNode == RBTREE_NullNode) {
    deleteOkay = True;
  } else {

    myTreePtr = deleteNode->parentTreePtr;

#ifdef paranoidCheck
    if (RBTREE_Audit (myTreePtr) == True) {
      if (myTreePtr == RBTREE_NullTree) {
#ifdef enableAlarms 
        AL_SoftwareAlarm (AL_Id_RBTREE_NullTree, AL_Fn_RBTREE_Delete, 
                          (UInt32) deleteNode, 0, 0, 0);
#endif /* enableAlarms */
      } else {
#endif

#ifdef paranoid
        if (ModifyAccessSemaphore(&(myTreePtr->treeLock))==True) {
#endif /* paranoid */

		  nilPtr = myTreePtr->nilNode;

		  if ((deleteNode->leftPtr  == nilPtr) || 
			  (deleteNode->rightPtr == nilPtr)) {
			y = deleteNode;
		  }
		  else {
			y = RBTREE_Next(myTreePtr, deleteNode);
		  }
	
		  if (y->leftPtr != nilPtr) {
			x = y->leftPtr;
		  }
		  else {
			x = y->rightPtr;
		  }

          if (y->parentPtr != deleteNode) {	
		    x->parentPtr = y->parentPtr;
          } else {
		    x->parentPtr = y;
          }
	  
		  if (y->parentPtr == myTreePtr->head) {
			myTreePtr->head->rightPtr = x;
		  }
		  else if (y == y->parentPtr->leftPtr) {
			y->parentPtr->leftPtr = x;
		  }
		  else {
			y->parentPtr->rightPtr = x;
		  }

		  /* Node y now takes the place of deleteNode in the tree. */

          yParent = y->parentPtr;

		  /* First, copy over all the tree pointers and node characteristics
			 from deleteNode to y */

		  y->parentPtr = deleteNode->parentPtr;
		  y->leftPtr   = deleteNode->leftPtr;
		  y->rightPtr  = deleteNode->rightPtr;

		  oldColour    = y->colour;
		  y->colour    = deleteNode->colour;

		  /* Now tell everybody who used to reference deleteNode to 
			 reference y instead. */

          if (deleteNode != y) {
		    if (deleteNode == deleteNode->parentPtr->leftPtr) {
			  deleteNode->parentPtr->leftPtr = y;
		    } else if (deleteNode == deleteNode->parentPtr->rightPtr) {
			  deleteNode->parentPtr->rightPtr = y;
		    }

		    if (deleteNode->leftPtr != nilPtr) {
			  deleteNode->leftPtr->parentPtr = y;
		    }
  
		    if (deleteNode->rightPtr != nilPtr) {
			  deleteNode->rightPtr->parentPtr = y;
		    }
		  }

          /* Decrement the sizes of the subtrees above the deleted node.
             Also, give the swapped-in node the old size of the deleted
             node's subtree (less 1 to account for the deleted node. */

          y->subtreeSize = deleteNode->subtreeSize;
          runner = (yParent == deleteNode ? y : yParent);
          while (runner != myTreePtr->head) {
            runner->subtreeSize -= 1;
            runner = runner->parentPtr;
          }

		  /* Time to rebalance the world now. */
	  
		  if (oldColour == _RBTREE_Black) {
			DeleteFixUp(myTreePtr, x);
		  }

		  FreeNode (deleteNode);

		  deleteOkay = True;
		  myTreePtr->count -= 1;

#ifdef paranoid
          UnlockSemaphore(&(myTreePtr->treeLock));
        } /* get write semaphore */
#endif /* paranoid */

#ifdef paranoidCheck
      } /* check for null parent */
    } /* structure audit */
#endif
  } /* make sure deleteNode is not NULL */

  return deleteOkay;
}

/******************************************************************
; routine:  DeleteFixUp
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static void
DeleteFixUp(RBTREE_TreeType theTree, RBTREE_NodeType x)
{
  RBTREE_NodeType w;
  
  while (x != theTree->head->rightPtr && x->colour == _RBTREE_Black) {
    if (x == x->parentPtr->leftPtr) {
      w = x->parentPtr->rightPtr;
      if (w->colour == _RBTREE_Red) {
        w->colour = _RBTREE_Black;
        x->parentPtr->colour = _RBTREE_Red;
        RotateLeft(theTree, x->parentPtr);
        w = x->parentPtr->rightPtr;
      }
      if ((w->leftPtr->colour == _RBTREE_Black) && 
          (w->rightPtr->colour == _RBTREE_Black)) {
        w->colour = _RBTREE_Red;
        x = x->parentPtr;
      }
      else {
        if (w->rightPtr->colour == _RBTREE_Black) {
          w->leftPtr->colour = _RBTREE_Black;
          w->colour = _RBTREE_Red;
          RotateRight(theTree, w);
          w = x->parentPtr->rightPtr;
        }
        w->colour = x->parentPtr->colour;
        x->parentPtr->colour = _RBTREE_Black;
        w->rightPtr->colour = _RBTREE_Black;
        RotateLeft(theTree, x->parentPtr);
        x = theTree->head->rightPtr;
      }
    }
    else {
      w = x->parentPtr->leftPtr;
      if (w->colour == _RBTREE_Red) {
        w->colour = _RBTREE_Black;
        x->parentPtr->colour = _RBTREE_Red;
        RotateRight(theTree, x->parentPtr);
        w = x->parentPtr->leftPtr;
      }
      if ((w->rightPtr->colour == _RBTREE_Black) && 
          (w->leftPtr->colour == _RBTREE_Black)) {
        w->colour = _RBTREE_Red;
        x = x->parentPtr;
      }
      else {
        if (w->leftPtr->colour == _RBTREE_Black) {
          w->rightPtr->colour = _RBTREE_Black;
          w->colour = _RBTREE_Red;
          RotateLeft(theTree, w);
          w = x->parentPtr->leftPtr;
        }
        w->colour = x->parentPtr->colour;
        x->parentPtr->colour = _RBTREE_Black;
        w->leftPtr->colour = _RBTREE_Black;
        RotateRight(theTree, x->parentPtr);
        x = theTree->head->rightPtr;
      }
    }
  }
  x->colour = _RBTREE_Black;
}

/******************************************************************
; routine:  RBTREE_FindNode
;
; description:
;   Locate the tree node whose data matches a given value.  If an exact
;   match cannot be made then the procedure returns with the node that
;   would immediately precede the data in a sequential ordering.
;
; in:
;   theTree : RBTREE_TreeType -- the tree in which we are searching
;   matchDataPtr : Ptr -- the data we are trying to find.  This data
;                         must be suitable for the tree's comparison
;                         routine.
;
; out:
;   nodePtr : RBTREE_NodeType * -- the last tree node in sequential order
;                                  that satisfies *nodePtr <= matchDataPtr
;   returns : Boolean -- True if an exact match occurred.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.03.28 / M. McAllister / Previous node not reported correctly when
;                              last branch at leaf was to the left.
*******************************************************************/
Boolean
RBTREE_FindNode (RBTREE_TreeType theTree, Ptr matchDataPtr, 
                 RBTREE_NodeType *nodePtr)
{
  RBTREE_NodeType x, y, z;
  SInt16          lastCompare = -1;
  Boolean         exactMatch = False;
  Boolean         treeMin = True;

  *nodePtr = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit (theTree) == True) {
#endif /* paranoidCheck */

    x = theTree->head->rightPtr; /* x points to the top tree node */
    y = theTree->head;    /* y is one up from x */
    z = theTree->nilNode;
    
    while ((x != z) && (lastCompare != 0)) {
      y = x;
      lastCompare = theTree->compareRoutine(matchDataPtr, x->dataPtr);
      if (lastCompare < 0) {
        x = x->leftPtr;
      } else {
        treeMin = False;
        if (lastCompare > 0) {
          x = x->rightPtr;
        }
      }
    }
  
    /* The search is over.  The node, or its predecessor, is in y. */

    *nodePtr = ((y == theTree->head) || (treeMin == True) ? 
                RBTREE_NullNode : 
                (lastCompare < 0 ? RBTREE_Previous(theTree, y) : y));

    if (lastCompare == 0) {
      exactMatch = True;
    } else {
      exactMatch = False;
    }

#ifdef paranoidCheck
  } /* structure audit */
#endif /* paranoidCheck */

  return exactMatch;
}

/******************************************************************
; routine:  RBTREE_GetData
;
; description:
;   Retrieve the data component of a tree node.
;
; in:
;   theNode : RBTREE_NodeType -- the node whose data we want.
;
; out:
;   returns : Ptr -- the data stored in theNode.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
Ptr
RBTREE_GetData (RBTREE_NodeType theNode)
{
  Ptr  dataPtr = NULL;

  if ((theNode == RBTREE_NullNode) || 
      (theNode == theNode->parentTreePtr->nilNode)){
    dataPtr = NULL;
  } else {
#ifdef paranoidCheck 
    /* Make sure that the memory guards are intact, otherwise we don't
       have a red-black tree node. */

    if ((theNode->headGuard != _RBTREE_NodeHeadTag) ||
        (theNode->headGuard != _RBTREE_NodeHeadTag)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_RBTREE_MemoryGuards, AL_Fn_RBTREE_GetData,
                        theNode->headGuard, theNode->tailGuard, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoidCheck */

      dataPtr = theNode->dataPtr;

#ifdef paranoidCheck 
    } /* memory guard check */
#endif /* paranoidCheck */
  }

  return dataPtr;
}

/******************************************************************
; routine:  ForEachNode
;
; description:
;   Invoke the callRtn function parameter on each node in the red-black
;   tree.  The callRtn function is passed the data from the node
;   and one parameter supplied to RBTREE_ForEachNode by the caller.
;
;   If the callRtn ever returns a value of False then the traversal of
;   the red-black tree halts immediately and a value of False is
;   returned.
;
; in:
;   theNode : RBTREE_NodeType -- the node from which the recursive
;                                descent of the tree starts
;   callRtn -- the function to invoke for each tree node
;   arg : Ptr -- the data to pass on to callRtn
;
; out:
;   returns : Boolean -- True if callRtn returned True for all nodes.
;                        False if any invocation of callRtn returned False.
;
; implementation notes:
;   The routine acts performs a recursive infix traversal of the tree.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static Boolean 
ForEachNode (RBTREE_NodeType theNode,
             Boolean (*callRtn)(Ptr dataPtr, Ptr arg), Ptr arg)
{
  Boolean allReturns = False;

  if (theNode == theNode->parentTreePtr->nilNode) {
    allReturns = True;
  } else {

    /* Time for actual traversals */

    if (ForEachNode(theNode->leftPtr, callRtn, arg) == True) {
      if ((*callRtn)(theNode->dataPtr, arg) == True) {
        allReturns = ForEachNode (theNode->rightPtr, callRtn, arg);
      }      
    }
  }

  return allReturns;
}

/******************************************************************
; routine:  RBTREE_ForEachNode
;
; description:
;   Invoke the callRtn function parameter on each node in the red-black
;   tree.  The callRtn function is passed the data from the node
;   and one parameter supplied to RBTREE_ForEachNode by the caller.
;
;   If the callRtn ever returns a value of False then the traversal of
;   the red-black tree halts immediately and a value of False is
;   returned.
;
; in:
;   theTree : RBTREE_TreeType -- the red-black tree to traverse
;   callRtn -- the function to invoke for each tree node
;   arg : Ptr -- the data to pass on to callRtn
;
; out:
;   returns : Boolean -- True if callRtn returned True for all nodes.
;                        False if any invocation of callRtn returned False.
;
; implementation notes:
;   The routine acts as a wrapper to a recursive infix traversal of the tree.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
Boolean 
RBTREE_ForEachNode (RBTREE_TreeType theTree, 
                    Boolean (*callRtn)(Ptr dataPtr, Ptr arg), Ptr arg)
{
  Boolean  returnValue = False;

#ifdef paranoidCheck
  if (RBTREE_Audit (theTree) == True) {
#endif /* paranoidCheck */

#ifdef paranoid
    /* Prevent the call routine from changing the tree structure as
       the tree is being traversed. */

    if (ReadAccessSemaphore (&(theTree->treeLock)) == True) {
#endif /* paranoid */

      returnValue = ForEachNode (theTree->head->rightPtr, *callRtn, arg);

#ifdef paranoid
      UnlockSemaphore (&(theTree->treeLock));
    }
#endif /* paranoid */

#ifdef paranoidCheck
  } /* structure audit */
#endif /* paranoidCheck */

  return returnValue;
}

/******************************************************************
; routine:  RBTREE_NumberOfNodes
;
; description:
;   Returns the number of nodes that are in the red-black tree.
;
; in:
;   theTree : RBTREE_TreeType -- the tree whose nodes we want to count
;
; out:
;   returns : UInt32 -- the number of nodes in the tree.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
UInt32
RBTREE_NumberOfNodes (RBTREE_TreeType theTree)
{
  UInt32  nodeCount = 0;

#ifdef paranoidCheck
  if (RBTREE_Audit (theTree) == True) {
#endif /* paranoidCheck */

    nodeCount = theTree->count;

#ifdef paranoidCheck
  } /* structure audit */
#endif /* paranoidCheck */

  return nodeCount;
}

/******************************************************************
; routine:  RecursiveNodeAudit
;
; description:
;   Verifies the node audit conditions for RBTREE_Audit
;   The following invariants are tested:
;    - the memory guards at the head and tail of each tree node are intact
;    - each tree node points to the correct tree information block
;    - each node is ``greater than'' its left child and ``smaller than''
;      its right child, relative to the comparison routine of the tree
;    - the number of black nodes along a path from the root to any leaf
;      is constant across the tree.
;    - each node in the tree is labeled as red or black
;    - each child points to its correct parent
;    - the child of a red node must be coloured black
;
; in:
;   theTree : RBTREE_TreeType -- the tree being audited
;   theNode : RBTREE_NodeType -- the node at the root of the tree to audit
;   parent : RBTREE_NodeType -- who the parent of theNode should be
;
; out:
;   nodeCountPtr : UInt32 * -- the number of nodes in the subtree.
;   blackCountToLeaf : UInt32 * -- the number of black nodes to
;                        the leaves.  
;   returns : Boolean -- True if all the properties hold for the tree
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.10.23 / M. McAllister / Check the subtree size value in each node
*******************************************************************/
static Boolean
RecursiveNodeAudit(RBTREE_TreeType theTree, RBTREE_NodeType theNode, 
    RBTREE_NodeType parent, UInt32 *nodeCountPtr, UInt32 *blackCountToLeaf)
{
  Boolean auditOkay = False;
  UInt32  leftCount = 0;
  UInt32  rightCount = 0;
  UInt32  leftBlackCount = 0;
  UInt32  rightBlackCount = 0;

  if (theNode == theTree->nilNode) {

    /* The tree is empty -- all its nodes vacuously pass the testss. */

    auditOkay = True;
    *nodeCountPtr = 0;
    *blackCountToLeaf = 1;
  } else {

    /* Do all the preliminary tests on this node before even thinking
       about its children. */

#ifdef paranoid
    /* Start with the memory guards to see if the rest of the audit
       has a prayer. */

    if ((theNode->headGuard != _RBTREE_NodeHeadTag) ||
        (theNode->tailGuard != _RBTREE_NodeTailTag)) {
#ifdef enableAlarms 
      AL_SoftwareAlarm (AL_Id_RBTREE_MemoryGuards,
                        AL_Fn_RBTREE_RecursiveNodeAudit, 
                        theNode->headGuard, theNode->tailGuard, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoind */

      /* Colour check.  Anybody with a red parent must be black. */

      if ((theNode->colour != _RBTREE_Black) &&
          ((theNode->colour != _RBTREE_Red) || (parent->colour==_RBTREE_Red))) {
#ifdef enableAlarms
        AL_SoftwareAlarm (AL_Id_RBTREE_WrongColourNode,
                          AL_Fn_RBTREE_RecursiveNodeAudit, 
                          (UInt32) theNode->colour, (UInt32) theNode, 0, 0);
#endif /* enableAlarms */
      } else {

		/* Check the parent and tree pointers */

		if ((theNode->parentPtr != parent) || 
            (theNode->parentTreePtr != theTree)) {
#ifdef enableAlarms 
          AL_SoftwareAlarm (AL_Id_RBTREE_ParentPointerCorrupt,
                            AL_Fn_RBTREE_RecursiveNodeAudit, 
                            (UInt32) theNode, (UInt32) parent, 
                            (UInt32) theTree, 0);
#endif /* enableAlarms */
        } else {

          /* Check the order of the nodes in the tree.  Each child must
             either be null or must follow the correct order for the
             tree: left child <= theNode <= right child. */

          if (((theNode->leftPtr != theTree->nilNode) && 
               (theTree->compareRoutine(theNode->leftPtr->dataPtr, 
                                        theNode->dataPtr) > 0)) 
              ||
              ((theNode->rightPtr != theTree->nilNode) && 
               (theTree->compareRoutine(theNode->dataPtr, 
                                        theNode->rightPtr->dataPtr) > 0))) {
#ifdef enableAlarms
            AL_SoftwareAlarm (AL_Id_RBTREE_OutOfOrder,
                              AL_Fn_RBTREE_RecursiveNodeAudit, 
                              (UInt32) theNode, 0, 0, 0);
#endif /* enableAlarms */
          } else {

			/* Time to check out the children. */
	  
			if ((RecursiveNodeAudit(theTree, theNode->leftPtr, theNode, 
                    &leftCount, &leftBlackCount) == True) &&
				(RecursiveNodeAudit(theTree, theNode->rightPtr, theNode, 
                    &rightCount, &rightBlackCount) == True)) {
	  
			  /* Do final comparison of results from the children subtrees. */
	  
			  if (leftBlackCount != rightBlackCount) {
#ifdef enableAlarms
                AL_SoftwareAlarm (AL_Id_RBTREE_BlackCountOff,
                                  AL_Fn_RBTREE_RecursiveNodeAudit, 
                                  (UInt32) leftBlackCount, 
                                  (UInt32) rightBlackCount, 
                                  (UInt32) theNode, 0);
#endif /* enableAlarms */
              } else {
				*nodeCountPtr = leftCount + rightCount + 1;
                if (*nodeCountPtr != theNode->subtreeSize) {
#ifdef enableAlarms
                  AL_SoftwareAlarm (AL_Id_RBTREE_SubtreeSizeIncorrect,
                                    AL_Fn_RBTREE_RecursiveNodeAudit, 
                                    (UInt32) leftCount, 
                                    (UInt32) rightCount, 
                                    (UInt32) theNode->subtreeSize, 
                                    (UInt32) theNode);
#endif /* enableAlarms */
                } else {
				  /* Nothing left to check.  I guess it's all okay. */
		
				  auditOkay = True;
				  *blackCountToLeaf = leftBlackCount;
				  if (theNode->colour == _RBTREE_Black) {
				    *blackCountToLeaf += 1;
			      }
			    }
			  } /* black node count to leaves is the same */
			} /* children nodes are sane. */
		  } /* tree order is sane. */
        } /* parent and tree pointers are sane. */
      } /* node colour is sane. */
#ifdef paranoid
    } /* memory guards are sane. */
#endif /* paranoid */
  } /* null tree check. */

  return auditOkay;
}

/******************************************************************
; routine:  RBTREE_Audit
;
; description:
;   Verifies the consistency of the data structure invariants
;   for a red-black tree.  The following invariants are tested:
;    - the memory guards at the head and tail of the tree 
;      information block are intact
;    - the number of nodes indicated in the tree information block
;      correspond to the number of nodes in the tree
;    - the memory guards at the head and tail of each tree node are intact
;    - each tree node points to the correct tree information block
;    - each node is ``greater than'' its left child and ``smaller than''
;      its right child, relative to the comparison routine of the tree
;    - the number of black nodes along a path from the root to any leaf
;      is constant across the tree.
;    - each node in the tree is labeled as red or black
;    - each child points to its correct parent
;    - the child of a red node must be coloured black
;
; in:
;   theTree : RBTREE_TreeType -- the tree to audit
;
; out:
;   returns : Boolean -- True if all the properties hold for the tree
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
Boolean
RBTREE_Audit (RBTREE_TreeType theTree)
{
  Boolean  auditPassed = False;
  UInt32   nodeCount = 0;
  UInt32   blackDepth = 0;

  if (theTree == RBTREE_NullTree) {
    auditPassed = True;
  } else {

#ifdef paranoid
    /* Get a lock on the tree so that no changes can occur
       while the audit is in progress. */

    if (ReadAccessSemaphore (&(theTree->treeLock)) == True) {

      /* Check the memory guards on the tree itself. */

      if ((theTree->headGuard != _RBTREE_TreeHeadTag) ||
          (theTree->tailGuard != _RBTREE_TreeTailTag)) {
#ifdef enableAlarms 
        AL_SoftwareAlarm (AL_Id_RBTREE_MemoryGuards, AL_Fn_RBTREE_Audit,
                          theTree->headGuard, theTree->tailGuard, 0, 0);
#endif /* enableAlarms */
      } else {
#endif /* paranoid */

        if (RecursiveNodeAudit(theTree, theTree->head->rightPtr, theTree->head,
                               &nodeCount, &blackDepth) == True) {

          /* Lastly, check the node tallys. */

          if (nodeCount != theTree->count) {
#ifdef enableAlarms
            AL_SoftwareAlarm (AL_Id_RBTREE_NodeCountOff, AL_Fn_RBTREE_Audit,
                          (UInt32) nodeCount, (UInt32) theTree->count, 0, 0);
#endif /* enableAlarms */
          } else {

            /* The tree is honkey dorey. */

            auditPassed = True;

          } /* node count check */
        } /* recursive check on nodes */
#ifdef paranoid
      } /* memory guard check on tree. */

      UnlockSemaphore (&(theTree->treeLock));
    } /* get read semaphore */
#endif /* paranoid */
  }

  return auditPassed;
}

/******************************************************************
; routine:  RBTREE_Parent
;
; description:
;   Returns the parent node in the red-black tree of a given node.
;   The parent of the RBTREE_NullNode is the RBTREE_NullNode.
;
; in:
;   theTree : RBTREE_TreeType -- the tree that contains the nodes
;   currentNode : RBTREE_NodeType -- the node whose parent we want
;
; out:
;   returns : RBTREE_NodeType -- the parent node of currentNode
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
RBTREE_NodeType 
RBTREE_Parent (RBTREE_TreeType theTree, RBTREE_NodeType currentNode)
{
  RBTREE_NodeType  parentPtr = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit(theTree) == True) {
    if ((currentNode != RBTREE_NullNode) && 
       (currentNode->parentTreePtr != theTree)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_RBTREE_NodeInWrongTree, AL_Fn_RBTREE_Parent, 
                        (UInt32) currentNode, (UInt32) theTree, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoidCheck */

	  if ((currentNode == RBTREE_NullNode) || 
		  (currentNode == theTree->nilNode) ||
		  (currentNode->parentPtr == theTree->head)) {
		parentPtr = RBTREE_NullNode;
	  } else {
		parentPtr = currentNode->parentPtr;
	  }

#ifdef paranoidCheck
    } /* parentage check */
  } /* structure audit */
#endif /* paranoidCheck */

  return parentPtr;
}

/******************************************************************
; routine:  RBTREE_LeftChild
;
; description:
;   Returns the left child node in the red-black tree of a given node.
;   The left child of RBTREE_NullNode is the root of the red-black tree.
;
; in:
;   theTree : RBTREE_TreeType -- the tree that contains the nodes
;   currentNode : RBTREE_NodeType -- the node whose left child we want
;
; out:
;   returns : RBTREE_NodeType -- the left child of currentNode
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
RBTREE_NodeType 
RBTREE_LeftChild (RBTREE_TreeType theTree, RBTREE_NodeType currentNode)
{
  RBTREE_NodeType  childPtr = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit(theTree) == True) {
    if ((currentNode != RBTREE_NullNode) && 
       (currentNode->parentTreePtr != theTree)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_RBTREE_NodeInWrongTree, AL_Fn_RBTREE_LeftChild, 
                        (UInt32) currentNode, (UInt32) theTree, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoidCheck */

	  if (currentNode == RBTREE_NullNode) {
		childPtr = theTree->head->rightPtr;
	  } else {
		childPtr = currentNode->leftPtr;
	  }

	  if (childPtr == theTree->nilNode) {
		childPtr = RBTREE_NullNode;
	  }

#ifdef paranoidCheck
    } /* parentage check */
  } /* structure audit */
#endif /* paranoidCheck */

  return childPtr;
}

/******************************************************************
; routine:  RBTREE_RightChild
;
; description:
;   Returns the right child node in the red-black tree of a given node.
;   The right child of RBTREE_NullNode is the root of the red-black tree.
;
; in:
;   theTree : RBTREE_TreeType -- the tree that contains the nodes
;   currentNode : RBTREE_NodeType -- the node whose right child we want
;
; out:
;   returns : RBTREE_NodeType -- the right child of currentNode
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
RBTREE_NodeType 
RBTREE_RightChild (RBTREE_TreeType theTree, RBTREE_NodeType currentNode)
{
  RBTREE_NodeType  childPtr = RBTREE_NullNode;

#ifdef paranoidCheck
  if (RBTREE_Audit(theTree) == True) {
    if ((currentNode != RBTREE_NullNode) && 
       (currentNode->parentTreePtr != theTree)) {
#ifdef enableAlarms
      AL_SoftwareAlarm (AL_Id_RBTREE_NodeInWrongTree, AL_Fn_RBTREE_RightChild, 
                        (UInt32) currentNode, (UInt32) theTree, 0, 0);
#endif /* enableAlarms */
    } else {
#endif /* paranoidCheck */

	  if (currentNode == RBTREE_NullNode) {
		childPtr = theTree->head->rightPtr;
	  } else {
		childPtr = currentNode->rightPtr;
	  }
	
	  if (childPtr == theTree->nilNode) {
		childPtr = RBTREE_NullNode;
	  }

#ifdef paranoidCheck
    } /* parentage check */
  } /* structure audit */
#endif /* paranoidCheck */

  return childPtr;
}

/******************************************************************
; routine:  AllocateNode
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.03.28 / M. McAllister / Data pointer should initialize to NULL
;   95.10.23 / M. McAllister / Field subtreeSize added to tree node
*******************************************************************/
static RBTREE_NodeType
AllocateNode(RBTREE_TreeType theTree)
{
  RBTREE_NodeType  theNode;

  theNode = (RBTREE_NodeType) malloc (sizeof (_RBTREE_NodeInfoType));
  if (theNode == NULL) {
    theNode = RBTREE_NullNode;
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_NoNodeMemory, AL_Fn_NullFunction, 0,0,0,0);
#endif /* enableAlarms */
  } else {
#ifdef paranoid

    /* Initialize all the memory guards */

    theNode->headGuard = _RBTREE_NodeHeadTag;
    theNode->tailGuard = _RBTREE_NodeTailTag;

#endif /* paranoid */

    /* Initialize all the pointers of the node */

    theNode->parentTreePtr = theTree;
    theNode->dataPtr       = NULL;
    theNode->parentPtr     = theTree->nilNode;
    theNode->leftPtr       = theTree->nilNode;
    theNode->rightPtr      = theTree->nilNode;
    theNode->subtreeSize   = 1;

    theNode->colour = _RBTREE_Black;
  }

  return theNode;
}

/******************************************************************
; routine:  FreeNode
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static void 
FreeNode (RBTREE_NodeType theNode)
{
#ifdef paranoidCheck

  if ((theNode->headGuard != _RBTREE_NodeHeadTag) ||
      (theNode->tailGuard != _RBTREE_NodeTailTag)) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_MemoryGuards, AL_Fn_RBTREE_FreeNode,
               theNode->headGuard, theNode->tailGuard, (UInt32) theNode, 0);
#endif /* enableAlarms */
  } else {
#endif /* paranoidCheck */

#ifdef paranoid

    /* Clear the memory guards so subsequent audits on the node will fail */

    theNode->headGuard = 0;
    theNode->tailGuard = 0;

    /* Clear all pointers in the node so existing references to the node
       cannot use it anymore */

    theNode->parentPtr     = NULL;
    theNode->leftPtr       = NULL;
    theNode->rightPtr      = NULL;
    theNode->parentTreePtr = NULL;
    theNode->dataPtr       = NULL;

#endif /* pranoid */

    /* The actual release of the memory -- the only thing that happens 
       outside of paranoid mode. */

    free (theNode);

#ifdef paranoidCheck
  } /* memory guard check */
#endif /* paranoidCheck */
}

#ifdef paranoid

/******************************************************************
; routine:  InitSemaphore
;
; description:
;   Initialize the data structure semaphore.
;
; in:
;   theSem : SemaphoreType * -- the semaphore to be initialized
;
; out:
;   returns : Boolean -- True if initialization succeeded.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static Boolean
InitSemaphore (SemaphoreType *theSem)
{
  *theSem = 0;
  return True;
}

/******************************************************************
; routine:  DestroySempahore
;
; description:
;   Invalidate a data structure semaphore.
;
; in:
;   theSem : SemaphoreType * -- the semaphore to be initialized
;
; out:
;   none
;
; implementation note:
;   The semaphores aren't really managed right now so the best we
;   can do is reset its value to 0.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static void
DestroySemaphore (SemaphoreType *theSem)
{
  *theSem = 0;
}

/******************************************************************
; routine:  ReadAccessSemaphore
;
; description:
;   Obtain read access to the red-black tree data structure.
;
; in:
;   theSem : SemaphoreType * -- the semaphore for the tree to which
;                           we want access
;
; out:
;   returns : Boolean -- True if read access is granted, False otherwise
;
; implementation note:
;   The semaphore semantics always grant read access.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static Boolean 
ReadAccessSemaphore (SemaphoreType *theSem)
{
  *theSem += 1;
  return True;
}

/******************************************************************
; routine:  ModifyAccessSemaphore
;
; description:
;   Obtain write access to the red-black tree data structure.
;
; in:
;   theSem : SemaphoreType * -- the semaphore for the tree to which
;                           we want access
;
; out:
;   returns : Boolean -- True if write access is granted, False otherwise
;
; implementation note:
;   The semaphore semantics grant write access only if no other
;   entity claims a lock on the semaphore.  i.e. the counting
;   semaphore is 0.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static Boolean 
ModifyAccessSemaphore (SemaphoreType *theSem)
{
  Boolean  granted = False;

  if (*theSem != 0) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_UnableToGetSemaphore, 
                      AL_Fn_RBTREE_ModifyAccess, (UInt32)(*theSem), 0, 0, 0);
#endif /* enableAlarms */
  } else {
    *theSem += 1;
    granted = True;
  }

  return granted;
}

/******************************************************************
; routine:  UnlockSemaphore
;
; description:
;   Release read or write access to the red-black tree semaphore.
;   The routine does not make a distinction between the read and
;   write accesses, nor does it track claim/release threads so
;   semaphores can be released by threads that did not claim the lock.
;
; in:
;   theSem : SemaphoreType * -- the semaphore for the tree to release
;
; out:
;   none
;
; implementation note:
;   The counting semaphore is not allowed to get a negative value.
;
; history:
;   94.12.02 / M. McAllister / Created
*******************************************************************/
static void 
UnlockSemaphore (SemaphoreType *theSem)
{
  if (*theSem <= 0) {
#ifdef enableAlarms
    AL_SoftwareAlarm (AL_Id_RBTREE_UnlockFreeSemaphore, AL_Fn_NullFunction, 
                      (UInt32)(*theSem), 0, 0, 0);
#endif /* enableAlarms */
  } else {
    *theSem -= 1;
  }
}

#endif /* paranoid */

