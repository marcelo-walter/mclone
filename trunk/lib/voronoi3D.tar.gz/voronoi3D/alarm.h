
#ifndef _alarm_h_
#define _alarm_h_

#include "globals.h"

/* Some macros to show that everybody is working on the same level. */

#define AL_BaseAlarm(A)      ((A)<<16)
#define AL_BaseFunction(A)   ((A)<<16)

/* Alarm data types. */

typedef UInt32 AL_AlarmCodeType;
typedef UInt32 AL_FunctionCodeType;

/* When the alarm code is unique, the caller can use the following
   function code to identify himself. */

#define AL_Fn_NullFunction  (0x0)

/* All alarm codes must have the form AL_Id_<module><error>.  All
   function codes must have the form AL_Fn_<module><error> */

#define AL_Id_NoError        (0x0)

#ifdef __cplusplus
extern "C" {
#endif

void AL_SoftwareAlarm (AL_AlarmCodeType theAlarm, 
                       AL_FunctionCodeType theFunction, 
                       UInt32 arg1, UInt32 arg2, UInt32 arg3, UInt32 arg4);

void AL_GetLastAlarm (AL_AlarmCodeType *alarmPtr, 
                      AL_FunctionCodeType *functionPtr, 
                      UInt32 *arg1, UInt32 *arg2, UInt32 *arg3, UInt32 *arg4);
                     
Boolean AL_Initialise (void);
void    AL_Destroy (void); 

#ifdef __cplusplus
}
#endif

#endif

