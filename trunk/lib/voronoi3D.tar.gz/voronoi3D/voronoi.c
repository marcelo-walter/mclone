
#include <math.h>
#include <stdio.h>

#include "globals.h"
#include "geometry.h"
#include "polygon.h"
#include "voronoi.h"
#include "distance.h"
#include "sweep.h"

void
ptNearestPgonLine(Pt *point, Pgon *line, int startindex, Pt *nearest)
{
	Line	original;

	LineOf(&(line->points[startindex]), &(line->points[
		(startindex+1)%line->numPoints]), &original);
	ptNearestLine (point, &original, nearest);
}

Boolean
nearestPointOnSegment(Pt *queryPt, Pt *seg1, Pt *seg2)
{
	Line	segment, normal1, normal2;
	Pt		testPoint;

	if (PointAtInfinity(*queryPt)) {
		if (PointAtInfinity(*seg1) || PointAtInfinity(*seg2))
			return (True);
		else
			return (False);
	}

	PointAssign(testPoint, *queryPt);
	if (testPoint.w < 0) {
		testPoint.w *= -1;
		testPoint.x *= -1;
		testPoint.y *= -1;
	}

	LineOf(seg1, seg2, &segment);
	perpRightTurnLine(seg1, &segment, &normal1);
	perpRightTurnLine(seg2, &segment, &normal2);

	if ((LineSide (&normal1, &testPoint) == LeftSide) &&
		(LineSide (&normal2, &testPoint) == RightSide))
		return (True);
	else
		return (False);
}

void
spokeToSegment (Pt *origin, Pgon *object, int index1, int index2, 
	spokeInfo *spoke)
{
	Real		dist0, dist1;
	Line		compareLine;

	if (index1 == index2) {
		PointAssign(spoke->attachment, object->points[index1]);
		spoke->attachIndex = 2*index1;
	}
	else {
		if (nearestPointOnSegment(origin, &(object->points[index1]),
				&(object->points[index2])) == True) {
			ptNearestPgonLine(origin, object, index1, &(spoke->attachment));
			LineOf(&(object->points[index1]), &(object->points[index2]),
				&compareLine);
			if (LineSide(&compareLine, origin) == RightSide) {
				spoke->attachIndex = 2*index1 + 1;
			}
			else {
				spoke->attachIndex = 2*index2 + 1;
			}
		}
		else {
			squarePointDistance(origin, &(object->points[index1]), &dist0);
			squarePointDistance(origin, &(object->points[index2]), &dist1);

			if (Less(dist0, dist1)) {
				PointAssign(spoke->attachment, object->points[index1]);
				spoke->attachIndex = 2*index1;
			}
			else {
				PointAssign(spoke->attachment, object->points[index2]);
				spoke->attachIndex = 2*index2;
			}
		}
	}
}

void
findSpoke(Pt *origin, Pgon *object, spokeInfo *spoke)
{
	int			start, end, mid;

	/*	The first point of the spoke can be our origin itself. */

	PointAssignPtr(&(spoke->otherPt), origin);
	spoke->attachPolygon = object;

	if (object->numPoints == 1)
		start = end = 0;
	else if (object->numPoints == 2) {
		start = 0;
		end = 1;
	}
	else {
		Line	pgonLine, testNorm;
		int		diff;

		/*	Find myself a starting point.  I want a point on the polygon
			that is on the other side from the query point. */

		end = object->leftmost;
		start = (end + 1) % object->numPoints;
		LineOf(&(object->points[end]), &(object->points[start]), &pgonLine);
		if ((LineSide(&pgonLine, origin) == RightSide) ||
				(OnTheLine(&pgonLine, origin))) {
			end = object->rightmost;
			start = (end + 1) % object->numPoints;
			LineOf(&(object->points[end]), &(object->points[start]), &pgonLine);
			if ((LineSide(&pgonLine, origin) == RightSide) ||
					(OnTheLine(&pgonLine, origin))) {
				end = object->upper;
				start = (end + 1) % object->numPoints;
				LineOf(&(object->points[end]), &(object->points[start]), 
					&pgonLine);
				if ((LineSide(&pgonLine, origin) == RightSide) ||
						(OnTheLine(&pgonLine, origin))) {
					/*	We've got a really messed up polygon here. */
					end = object->lower;
					start = (end + 1) % object->numPoints;
				}
			}
		}

		/*	Do a binary search across the polygon using the normals
			to the edges of the polygon. */

		while (end != ((start + 1)% object->numPoints)) {
			diff = (end - start + object->numPoints) % object->numPoints;
			mid = (start + (int)(diff / 2)) % object->numPoints;
			LineOf(&(object->points[mid]), 
				&(object->points[(mid+1)%object->numPoints]), 
				&pgonLine);
			perpRightTurnLine(&(object->points[mid]), &pgonLine, &testNorm);
			if (LineSide(&testNorm, origin) == LeftSide)
				start = mid;
			else
				end = mid;
		}
	}
	
	spokeToSegment (origin, object, start, end, spoke);
}

void
ptNearestPgon(Pt *query, Pgon *poly, Pt *nearest)
{
    spokeInfo   spoke;

    findSpoke(query, poly, &spoke);
    PointAssignPtr(nearest, &(spoke.attachment));
}

/*	Uses the points (a,b,c) and (d,e,f) in homogeneous coordinates. */

void
pointBisector(Pt *p1, Pt *p2, Line *l)
{
	double	cd, af, bf, ce, bd, ae, ad;

	/*	Taking the bisector of (a,b,c) with (d,e,f) */

	cd = (double) p1->y * p2->w;
	af = (double) p1->w * p2->y;
	bf = (double) p1->x * p2->y;
	ce = (double) p1->y * p2->x;
	bd = (double) p1->x * p2->w;
	ae = (double) p1->w * p2->x;
	ad = (double) p1->w * p2->w;

	/*	With these pre-processed values, create the bisector */

	l->w = (Coordinate)((ae*ae) - (bd*bd) - (cd*cd) + (af*af));
	l->x = (Coordinate)(2.0*ad*(bd - ae));
	l->y = (Coordinate)(2.0*ad*(cd - af));
}

void
lineBisectors(Line *ln1, Line *ln2, Line *bisect1, Line *bisect2)
{
	Pt		intPt, otherPt1, otherPt2;

	IntersectionOf(ln1, ln2, &intPt);

	if (LineSlopePtr(ln1) == LineSlopePtr(ln2)) {
		/*	Parallel lines -- only one bisector for these. */

		bisect1->w = ln1->w * ln2->y + ln1->y * ln2->w;
		bisect1->x = 2 * ln1->x * ln2->y;
		bisect1->y = 2 * ln1->y * ln2->y;

		PointAssignPtr(bisect2, bisect1);
	}
	else if (((ln1->x == 0) && (ln2->y == 0)) || 
			 ((ln1->y == 0) && (ln2->x == 0))) {

		/*	The lines are both parallel to different coordinate axes. */

		PointAssign(otherPt1, intPt);
		PointAssign(otherPt2, intPt);

		otherPt1.x += otherPt1.w;
		otherPt1.y += otherPt1.w;

		otherPt2.x -= otherPt2.w;
		otherPt2.y += otherPt2.w;

		LineOf(&intPt, &otherPt1, bisect1);
		LineOf(&intPt, &otherPt2, bisect2);
	}
	else {

		double sign, len1, len2;
		Pt midp;

#define SGN(x) (x < 0 ? -1 : 1)
		 
		sign = SGN(intPt.w);
		len1 =   sign * sqrt(ln1->x * ln1->x + ln1->y * ln1->y);
		len2 = - sign * sqrt(ln2->x * ln2->x + ln2->y * ln2->y);

		midp.w = 0.0;
		midp.x = ln1->x / len1 + ln2->x / len2;
		midp.y = ln1->y / len1 + ln2->y / len2;

		LineOf(&intPt, &midp, bisect1);
		PointAssignPtr(bisect2, bisect1);
		perpendicularLine(&intPt, bisect1, bisect2);
	}
}

void
getEventPoint (Pt *vorPoint, Pt *attach, Pt *eventPt)
{
	Real	spokeLength;

	PointAssignPtr(eventPt, vorPoint);
	pointDistance(attach, vorPoint, &spokeLength);
	eventPt->x += eventPt->w * spokeLength;
}


#define DifferentPoints(A,B,C) !(\
	SamePoint(A,B) || SamePoint(A,C) || SamePoint(B,C))

Boolean
pointsCCW(Pt *a, Pt *b, Pt *c)
{
	return((Greater(Det3(a,b,c), 0) ? True : False) || !DifferentPoints(a,b,c));
}

Boolean
pointsCCWAllowSame(Pt *a, Pt *b, Pt *c)
{
	return((Greater(Det3(a,b,c), 0) ? True : False) || DifferentPoints(a,b,c));
}

Boolean
objectsOnHull(Pt *pt1, Pt *pt21, Pt *pt22, Pt *pt3, Pt *vorPt, Pt *eventPt, 
	spokeInfo *spoke)
{
	Pt			vect1, vect2;
	Pt			resultant;
	Line		tangent;
	Real		len1, len2;
	int			direction;

	PointAssign(spoke->attachment, *pt21);
	spoke->attachIndex = -1;		/*	Don't care about this now.  */
	LineOf(pt1, pt21, &tangent);
	if ((OnTheLine(&tangent, pt22) == True) && 
		(OnTheLine(&tangent, pt3) == True)) {
		/*	The tangents are collinear! */
		if (YValPtr(pt1) != YValPtr(pt21)) {
			if (YValPtr(pt1) > YValPtr(pt21))
				direction = 1;
			else
				direction = -1;

			(spoke->otherPt).w = pt21->w * tangent.x;
			(spoke->otherPt).x = tangent.x *
			(pt21->x + pt21->w * direction);
			(spoke->otherPt).y = pt21->y * tangent.x +
				direction * pt21->w * tangent.y;
		}
		else {
			(spoke->otherPt).w = pt21->w;
			(spoke->otherPt).x = pt21->x;
			if (XValPtr(pt1) < XValPtr(pt21))
				(spoke->otherPt).y = pt21->y + 1;
			else
				(spoke->otherPt).y = pt21->y - 1;
		}
	}
	else {
		/*	Give up on elegance -- use some square roots for now. */

		SubPoints(*pt21, *pt1, vect1);
		SubPoints(*pt22, *pt3, vect2);
		vectorLength(&vect1, &len1);
		vectorLength(&vect2, &len2);
		vect1.w *= len1;
		vect2.w *= len2;
		AddPoints(vect1, vect2, resultant);
		AddPoints(*pt21, resultant, spoke->otherPt);
	}

	/*	The event point is at infinity. */

	eventPt->w = 0;
	eventPt->x = 1.0;
	eventPt->y = 0;

	vorPt->w = 0;
	vorPt->x = 0.0;
	vorPt->y = 0;

	return (False);
}

