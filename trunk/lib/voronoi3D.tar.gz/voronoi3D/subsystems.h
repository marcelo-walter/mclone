
#ifndef _subsystems_h_

#define _subsystems_h_

#define SYS_Pool         (0x1)
#define SYS_Heap         (0x2)
#define SYS_RedBlackTree (0x3)
#define SYS_SweepFront   (0x4)
#define SYS_VoronoiSweep (0x5)
#define SYS_CircularList (0x6)

#endif

