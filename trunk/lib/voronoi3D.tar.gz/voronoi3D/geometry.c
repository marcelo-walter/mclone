
#include <math.h>

#include "globals.h"
#include "geometry.h"
#include "distance.h"

void
perpendicularLine (Pt *point, Line *line, Line *perp)
{
    perp->w = (point->x)*(line->y) - (point->y)*(line->x);
    perp->x = (point->w)*(line->y)*-1;
    perp->y = (point->w)*(line->x);
}

void
perpRightTurnLine (Pt *point, Line *line, Line *perp)
{
	/*	Give the point a positive w value. */

	if (point->w < 0) {
		point->w *= -1;
		point->x *= -1;
		point->y *= -1;
	}

	/*	Get the perpendicular line, right turn from "line". */

    perp->w = (point->y)*(line->x) - (point->x)*(line->y);
    perp->x = (point->w)*(line->y);
    perp->y = (point->w)*(line->x)*-1;

	/*	Lastly, translate the line so that it passes through the point.  */

	/*	The above set-up also moved the line to the point. */

}

void
ptNearestLine(Pt *point, Line *line, Pt *nearest)
{
	Line	perp;

	perpendicularLine (point, line, &perp);
    IntersectionOf(line, &perp, nearest);
	RoundPoint(*nearest);
}

Boolean
pastSegmentBounds(Pt *point, Pt *start, Pt *end, int *closerEnd)
{
  Line     theLine, perpStart, perpEnd;
  Boolean  retVal = False;
  Real     dist0, dist1;

  LineOf (start, end, &theLine);
  perpendicularLine(start , &theLine, &perpStart);
  perpendicularLine(end , &theLine, &perpEnd);

  if ((LineSide (&perpStart, end) != LineSide (&perpStart, point)) ||
      (LineSide (&perpEnd, start) != LineSide (&perpEnd, point)) ) {
    retVal = True;

    /*  Both direction vectors go in the same direction so
        the "nearest" point does not lie between the start and end. */

    squarePointDistance(point, start, &dist0);
    squarePointDistance(point, end, &dist1);
    if (Less(dist0, dist1)) 
      *closerEnd = 0;
    else 
      *closerEnd = 1;
  } 

  return retVal;
}

void
ptNearestSegment(Pt *point, Pt *start, Pt *end, Pt *nearest)
{
	Line	fullLine;
	int		nearEnd;

	LineOf(start,end,&fullLine);
	ptNearestLine(point, &fullLine, nearest);

	/*	Now, check to see if we have gone beyond the endpoints. */

	if (pastSegmentBounds(nearest, start, end, &nearEnd) == True) {

        /*  Both direction vectors go in the same direction so
            the "nearest" point does not lie between the start and end. */

        if (nearEnd == 0) {
			PointAssignPtr(nearest, start);
		}
        else {
			PointAssignPtr(nearest, end);
		}
    }
}

void
createParabola(Pt *focus, Line *directrix, Parabola *para)
{
	Pt		nearPt, transfocus;
	double	twoFocalLength;
	Line	perp;

#ifdef DEBUG_GEOM
	printf ("geom: find parabola of focus %f %f %f and line %f %f %f\n",
		focus->w, focus->x, focus->y,
		directrix->w, directrix->x, directrix->y);
#endif

	if (OnTheLine(directrix, focus) == False) {
		para->scale = 1.0;
		para->offset = 0.0;
		para->sqCoeff = 1;
		ptNearestLine (focus, directrix, &nearPt);
		pointDistance(focus, &nearPt, &twoFocalLength);

		MidPointPtr(focus, &nearPt, &(para->centre));
		RoundPoint(para->centre);
		PointAssignPtr(&(para->focus), focus);
		PointAssignPtr(&(para->directrix), directrix);
		para->directrix.w = 0.0;
		RoundPoint(para->focus);

		para->focalLength = (Real)(twoFocalLength / 2);
			/*	For the sine of the angle, we shuld multiply by -1 to get
				the cosine (due to the 90 degree angle difference), but
				I want the negative of the sine, so two multiplications by
				-1 cancel each other out. */
		para->dirSin = 
			(Real) MyAbs(((XValPtr(focus) - XVal(nearPt)) /twoFocalLength));
		para->dirCos = 
			(Real) MyAbs(((YValPtr(focus) - YVal(nearPt)) /twoFocalLength));

		transfocus.w = focus->w * nearPt.w;
		transfocus.x = focus->x * nearPt.w - focus->w * nearPt.x;
		transfocus.y = focus->y * nearPt.w - focus->w * nearPt.y;

		if ((XVal(transfocus) >= 0) && (YVal(transfocus) > 0)) {
		}
		else if ((XVal(transfocus) < 0) && (YVal(transfocus) > 0)) {
			para->dirSin *= -1;
		}
		else if ((XVal(transfocus) < 0) && (YVal(transfocus) <= 0)) {
			para->dirSin *= -1;
			para->dirCos *= -1;
		}
		else {
			para->dirCos *= -1;
		}
	}
	else {
		para->scale = 1.0;
		para->offset = 0.0;
		para->sqCoeff = 0;

		PointAssignPtr(&(para->focus), focus);
		PointAssignPtr(&(para->directrix), directrix);
		para->directrix.w = 0.0;
		PointAssignPtr(&(para->centre), focus);
		RoundPoint(para->centre);
		RoundPoint(para->focus);

		/*	Encode the perpendicular line in the focal length and
			direction parameters. */

		perpendicularLine(focus, directrix, &perp);

		para->focalLength = (Real) perp.w;
		para->dirSin = (Real) perp.x;
		para->dirCos = (Real) perp.y;
	}
	PointAssign(para->scalePt[0], para->centre);
	PointAssign(para->scalePt[1], para->centre);
}

Real
parabolaParam(Parabola *para, Pt *pt)
{
	return((Real) ((XValPtr(pt) - XVal(para->centre)) * para->dirCos -
			(YValPtr(pt) - YVal(para->centre)) * para->dirSin));
}

void
parabolaPoint(Parabola *para, Real param, Pt *pt)
{
	pt->w = 1.0;
	pt->x = param*(para->dirCos + param * para->dirSin / (4*para->focalLength))
			+ XVal(para->centre);
	pt->y = param*(param * para->dirCos / (4*para->focalLength) - para->dirSin)
			+ YVal(para->centre);
}

void
intersectLineParabola(Line *line, Parabola *para, Pt *point1, Pt *point2)
{
	Real	a,b,c, soln1, soln2, discriminant, rootDisc;
	Real	squared; 
	Line	perp, trans;

	if (para->sqCoeff == 0) {
		/*	We have a degenerate parabola.  The intersection is easy. */
		perp.w = para->focalLength;
		perp.x = para->dirSin;
		perp.y = para->dirCos;

		IntersectionOf(line, &perp, point1);
		PointAssignPtr(point2, point1);	
	}
	else {
		/*	The intersection is characterised by a quadratic equation
			constraint on the parameter for the parabola.  Start by 
			setting out the coefficients for this quadratic equation:
				a*t^2 + b*t + c = 0			*/

		a = (line->x * para->dirSin + line->y * para->dirCos) / 
				(4 * para->focalLength);
		b = line->x * para->dirCos - line->y * para->dirSin;
		c = line->w + (line->x * XVal(para->centre)) + 
				(line->y * YVal(para->centre));
		PointAssignPtr(&trans, line);
		trans.w = 0;

		if ((!Zero(a)) && (!Zero(DotProd(&trans, &(para->directrix))))) {
			/*	Find the discriminant of the equation.  We assume that some
				intersection will occur, so we use a zero discriminant if
				it turns out to be negative. */

			discriminant = b*b -4*a*c;
			discriminant = (Zero(discriminant) ? Max(discriminant, 0) :
								discriminant);

			/*	mjm's hack for now. */
			discriminant = Max(discriminant, 0);

			if (discriminant >= 0) {
				rootDisc = sqrt((double)discriminant);
				soln1 = (b * -1 + rootDisc) / (a * 2);
				soln2 = (b * -1 - rootDisc) / (a * 2);

#ifdef DEBUG_GEOM
				printf ("geo: coefficients are a %2.2f, b %2.2f, c %2.2f\n", 
					a, b, c);
				printf ("geo: discriminant is %2.2f with solutions %f and %f\n",
					discriminant, soln1, soln2);
#endif

				/*	Find the solution points. */

				parabolaPoint(para, soln1, point1);
				parabolaPoint(para, soln2, point2);

#ifdef DEBUG_GEOM
				printf ("geo: candidate points are %2.2f %2.2f "
					"and %2.2f %2.2f\n", XValPtr(point1), YValPtr(point1), 
					XValPtr(point2), YValPtr(point2));
#endif
			}
			else {
				/* mjm to fill in later. */
			}
		}
		else {
			soln1 = c * -1 / b;

			squared = soln1 * soln1;
			point1->w = 1.0;
			point1->x = soln1* para->dirCos + squared * para->dirSin /
						(para->focalLength * 4) + XVal(para->centre);
			point1->y = squared * para->dirCos / (para->focalLength * 4) - 
						soln1 * para->dirSin + YVal(para->centre);

			PointAssignPtr(point2, point1);

#ifdef DEBUG_GEOM
			printf ("geo: single parameter solution at %f, point %f %f %f\n",
				soln1, point1->w, point1->x, point1->y);
#endif

		}
	}
}


#define ScreenLimits    10000000.0

/*  Find a point along driveLine that is to the right side of
    testLine and is off the displayable screen. */

void
awayPoint(Line *driveLine, Line *testLine, Pt *testPt)
{
    Line    highLine, lowLine;

    if (MyAbs(LineSlope(*driveLine)) < 1) {
        highLine.w = ScreenLimits;
        highLine.x = 1.0;
        highLine.y = 0.0;

        IntersectionOf(&highLine, driveLine, testPt);
        if (testPt->w < 0) {
            testPt->w *= -1; testPt->x *= -1; testPt->y *= -1;
        }
        if (LineSide (testLine, testPt) == LeftSide) {
            lowLine.w = ScreenLimits;
            lowLine.x = -1.0;
            lowLine.y = 0.0;

            IntersectionOf(&lowLine, driveLine, testPt);
            if (testPt->w < 0) {
                testPt->w *= -1; testPt->x *= -1; testPt->y *= -1;
            }
        }
    }
    else {
        highLine.w = ScreenLimits;
        highLine.x = 0.0;
        highLine.y = -1.0;

        IntersectionOf(&highLine, driveLine, testPt);
        if (testPt->w < 0) {
            testPt->w *= -1; testPt->x *= -1; testPt->y *= -1;
        }
        if (LineSide(testLine, testPt) == LeftSide) {
            lowLine.w = ScreenLimits;
            lowLine.x = 0.0;
            lowLine.y = 1.0;

            IntersectionOf(&lowLine, driveLine, testPt);
            if (testPt->w < 0) {
                testPt->w *= -1; testPt->x *= -1; testPt->y *= -1;
            }
        }
    }
}

