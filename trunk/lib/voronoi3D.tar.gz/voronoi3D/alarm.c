
#include <stdio.h>

#include "globals.h"
#include "alarm.h"

#ifdef storeAlarm
static AL_AlarmCodeType    _AL_errno;
static AL_FunctionCodeType _AL_function;
static UInt32              _AL_arg1;
static UInt32              _AL_arg2;
static UInt32              _AL_arg3;
static UInt32              _AL_arg4;
#endif

void 
AL_SoftwareAlarm (AL_AlarmCodeType theAlarm, AL_FunctionCodeType theFunction, 
                  UInt32 arg1, UInt32 arg2, UInt32 arg3, UInt32 arg4)
{
#ifdef storeAlarm
  _AL_errno = theAlarm;
  _AL_function = theFunction;
  _AL_arg1 = arg1;
  _AL_arg2 = arg2;
  _AL_arg3 = arg3;
  _AL_arg4 = arg4;
#endif

  fprintf (stderr, "Alarm %x, function %x, args %x %x %x %x\n",
           (int)theAlarm, (int)theFunction, (int)arg1, (int)arg2, 
           (int)arg3, (int)arg4);
}

void 
AL_GetLastAlarm (AL_AlarmCodeType *alarmPtr, AL_FunctionCodeType *functionPtr, 
                 UInt32 *arg1, UInt32 *arg2, UInt32 *arg3, UInt32 *arg4)
{
#ifdef storeAlarm
  *alarmPtr = _AL_errno;
  *functionPtr = _AL_function;
  *arg1 = _AL_arg1;
  *arg2 = _AL_arg2;
  *arg3 = _AL_arg3;
  *arg4 = _AL_arg4;
#endif
}
                     
Boolean 
AL_Initialise (void)
{

#ifdef storeAlarm
  /* Set all the data to "no problem" conditions. */

  _AL_errno = AL_Id_NoError;
  _AL_function = AL_Fn_NullFunction;
  _AL_arg1 = 0;
  _AL_arg2 = 0;
  _AL_arg3 = 0;
  _AL_arg4 = 0;
#endif

  return True;
}

void    
AL_Destroy (void)
{
}


