
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "globals.h"
#include "geometry.h"
#include "polygon.h"
#include "distance.h"

/*	Allocate memory space for a new polygon.  The sequence of vertices
	are copied to the polygon data structure and the 'vertices' 
	parameter can be used for something else. */
Pgon 
*newPolygon(int numPoints, Pt *vertices)
{
	Pgon	*poly;
	Pt		*pt;
	int		i;
	Coordinate	extrL, extrR, extrH, extrB;
	Coordinate	myX, myY;
	
	poly = (Pgon *) malloc (sizeof(Pgon));
	pt = (Pt *) malloc (sizeof(Pt) * numPoints);

	if ((poly != NULL) && (pt != NULL)) {
		poly->points = pt;
		poly->numPoints = numPoints;

		/*	Set up default bounding box values. */

		poly->leftmost = 0;
		poly->rightmost = 0;
		poly->upper = 0;
		poly->lower = 0;
		poly->voronoiCount = 0;
		/*poly->voronoiList[0] = NULL;*/ /* change from original code */

		extrL = XVal(vertices[0]);
		extrR = extrL;
		extrH = YVal(vertices[0]);
		extrB = extrH;

		/*	Copy all the points to the polygon structure, watching for
			the maximum and minimum value entries. */

		for (i = 0; i < numPoints; i++) {
			PointAssign(poly->points[i], vertices[i]);
			myX = XVal(vertices[i]);
			myY = YVal(vertices[i]);

			if (myX > extrR) {
				poly->rightmost = i; extrR = myX;
			} 
			else if ((myX < extrL) || 
			((myX == extrL) && (myY > YVal(vertices[poly->leftmost])))) {
				poly->leftmost = i; extrL = myX;
			}

			if (myY > extrH) {
				poly->upper = i; extrH = myY;
			} 
			else if (myY < extrB) {
				poly->lower = i; extrB = myY;
			}
		}
	}
	else if (poly != NULL)
		free (poly);

	return (poly);
}

/*	Release the memory associated with a polygon */
void 
killPolygon(Pgon **polygon)
{
	if (*polygon != NULL) {
		(*polygon)->numPoints = 0;	/* In case there is a handle lying about */
		free ((*polygon)->points);
		free (*polygon);
		*polygon = NULL;
	}
}


/*	Possible answers:
		0:  point right of both lines.
		1:	point left of ln1, right of ln2.
		2:	point right of ln1, left of ln2.
		3:	point left of both lines.
*/

int 
pointConfig(Line *ln1, Line *ln2, Pt *testPt)
{
	int	ans;

	ans = 0;

	if (LineSide(ln1, testPt) == LeftSide)
		ans += 1;
	if (LineSide(ln2, testPt) == LeftSide)
		ans += 2;

	return (ans);
}

#define modPt(A,B) ((A)->points[(B)%(A)->numPoints])

void 
nearestPoints (Pgon *p, Pgon *q, Pt *ppt, Pt *qpt, int *pidx, int *qidx)
{
  Line	pccwNorm, pcwNorm, qccwNorm, qcwNorm, tmpLine;
  int		phigh, plow, pmid, qhigh, qlow, qmid, result;
  Pt		ignoreme;
  Boolean   tan1Okay = True, tan2Okay = True;

  tan1Okay = outerCommonTangent (p,q,&ignoreme,&ignoreme,&plow,&qhigh);
  tan2Okay = outerCommonTangent (q,p,&ignoreme,&ignoreme,&qlow,&phigh);
  if (tan1Okay && tan2Okay) {
	if (plow >= phigh)
		phigh += p->numPoints;
	if (qlow >= qhigh)
		qhigh += q->numPoints;

	while ( (phigh - plow > 1) ||
			(qhigh - qlow > 1) ) {
		pmid = (plow + phigh) / 2;
		qmid = (qlow + qhigh) / 2;

		/*	Get the normals at pmid. */

		LineOf(&(modPt(p, pmid-1 + p->numPoints)), &(modPt(p, pmid)), &tmpLine);
		perpRightTurnLine(&(modPt(p, pmid)), &tmpLine, &pccwNorm);

		LineOf(&(modPt(p, pmid)), &(modPt(p, pmid+1)),&tmpLine);
		perpRightTurnLine(&(modPt(p, pmid)), &tmpLine, &pcwNorm);

		/*	Get the normals at qmid. */

		LineOf(&(modPt(q, qmid-1 + q->numPoints)), &(modPt(q, qmid)), &tmpLine);
		perpRightTurnLine(&(modPt(q, qmid)), &tmpLine, &qccwNorm);

		LineOf(&(modPt(q, qmid)), &(modPt(q, qmid+1)),&tmpLine);
		perpRightTurnLine(&(modPt(q, qmid)), &tmpLine, &qcwNorm);

		/*	Narrow down the binary search interval. */

		result = pointConfig(&pccwNorm, &pcwNorm, &(modPt(q, qmid)))*4 + 
			pointConfig(&qccwNorm, &qcwNorm, &(modPt(p, pmid)));
		switch (result) {
			case 0: case 4: case 8:
				plow = pmid;
				break;
			case 5: case 6: case 7: case 11: case 15:
				phigh = pmid;
				break;
			case 1: case 2: case 3: case 9:
				qlow = qmid;
				break;
			case 12: case 13: case 14:
				qhigh = qmid;
				break;
			case 10:
				plow = pmid; phigh = pmid;
				qlow = qmid; qhigh = qmid;
				break;
			default:
				printf ("Reached an unexpected case in finding nearest "
						"points of polygons %d.\n", result);
				plow = pmid; phigh = pmid;
				qlow = qmid; qhigh = qmid;
				break;
		}
	}

	/*	We're down to two line segments to handle in the worst case. */

	phigh = phigh % p->numPoints;
	plow = plow % p->numPoints;
	qhigh = qhigh % q->numPoints;
	qlow = qlow % q->numPoints;

	if (phigh == plow) {
		ptNearestSegment (&(p->points[plow]), &(q->points[qlow]),
			&(q->points[qhigh]), qpt);
		PointAssignPtr(ppt, &(p->points[plow]));
		*pidx = plow;
		*qidx = qlow;
	} 
	else if (qhigh == qlow) {
		ptNearestSegment (&(q->points[qlow]), &(p->points[plow]),
			&(p->points[phigh]), ppt);
		PointAssignPtr(qpt, &(q->points[qlow]));
		*pidx = plow;
		*qidx = qlow;
	}
	else {
		Real	dists[4], maxdist;
		Pt		actual[4], near[4], start[2], end[2];	
		int		i, maxidx;

		/*	Really brute force for now. */
	
		PointAssign(actual[0], p->points[plow]);
		PointAssign(actual[1], p->points[phigh]);
		PointAssign(actual[2], q->points[qlow]);
		PointAssign(actual[3], q->points[qhigh]);

		PointAssign(start[0], q->points[qlow]);
		PointAssign(start[1], p->points[plow]);
		PointAssign(end[0], q->points[qhigh]);
		PointAssign(end[1], p->points[phigh]);

		for (i = 0; i < 4; i++) {
			ptNearestSegment (&(actual[i]), &(start[i/2]),
				&(end[i/2]), &(near[i]));
			squarePointDistance(&(actual[i]), &(near[i]), &(dists[i]));
		}

		maxidx = -1;
		for (i = 3; i >= 0; i--) {
			if ((maxidx == -1) || (dists[i] < maxdist)) {
				maxidx = i;
				maxdist = dists[i];
			}
		}

		if (maxidx == -1) {
			printf ("Trouble -- nobody close enough to take the blame\n");
		}
		else {
			if (maxidx < 2) {
				PointAssignPtr(ppt, &(actual[maxidx]));
				PointAssignPtr(qpt, &(near[maxidx]));
			}
			else {
				PointAssignPtr(qpt, &(actual[maxidx]));
				PointAssignPtr(ppt, &(near[maxidx]));
			}
		}

		/*	Sluff these off for now. */

		*pidx = plow;
		*qidx = qlow;
	}
  } else {
    /* The polygons share a point.  This must really be _the_ closest
       point between them. */

    if (tan1Okay == False) {
      *pidx = plow;
      *qidx = qhigh;
    } else {
      *pidx = phigh;
      *qidx = qlow;
    }

    PointAssignPtr(ppt, &(p->points[*pidx]));
    PointAssignPtr(qpt, &(q->points[*qidx]));
  }
}

Boolean
polygonsShareVtx (Pgon *upperPgon, Pgon *lowerPgon, 
                  UInt16 *upIdx, UInt16 *lowIdx)
{
  Boolean  share = False;
#if 1
#else
  UInt16   i, j;
  Real     farthest, upperPos, lowerPos;
  SInt16   upperLimit, lowerLimit;
#endif

  if (upperPgon != lowerPgon) {
#if 1
    /* Brute force for line segments only. */

    if ((upperPgon->numPoints == 2) && (lowerPgon->numPoints == 2)) {
      if (SamePoint (&(upperPgon->points[0]), &(lowerPgon->points[0]))) {
        share = True; *upIdx = 0; *lowIdx = 0;
      } else if (SamePoint (&(upperPgon->points[0]), &(lowerPgon->points[1]))) {
        share = True; *upIdx = 0; *lowIdx = 1;
      } else if (SamePoint (&(upperPgon->points[1]), &(lowerPgon->points[1]))) {
        share = True; *upIdx = 1; *lowIdx = 1;
      } else if (SamePoint (&(upperPgon->points[1]), &(lowerPgon->points[0]))) {
        share = True; *upIdx = 1; *lowIdx = 0;
      }
    }
#else
	i = upperPgon->leftmost;
	j = lowerPgon->leftmost;

    upperLimit = upperPgon->rightmost + 
                (i > upperPgon->rightmost ? upperPgon->numPoints : 0);
    lowerLimit = lowerPgon->rightmost - 
                (j > lowerPgon->rightmost ? lowerPgon->numPoints : 0);

	farthest = Min(XVal(RightPoint(upperPgon)), XVal(RightPoint(lowerPgon)));
	upperPos = XVal(upperPgon->points[i]);
	lowerPos = XVal(lowerPgon->points[j]);

	/* In case both polygons have their rightmost points as their last
	   ones, handle a comparison of rightmost points separately.  Lame,
	   but it'll work for now. */

#if 0
	while ((i < upperLimit) && (j > lowerLimit) &&
#endif
	while (((upperPos < farthest) || (lowerPos < farthest)) 
        && (share == False)) {
	  if (SamePoint(&(upperPgon->points[i]), &(lowerPgon->points[j])) == True) {
		share = True;
		*upIdx = i;
		*lowIdx = j;
	  } else {
		if (upperPos < lowerPos) {
		  i = (i + 1) % upperPgon->numPoints;
		  upperPos = XVal(upperPgon->points[i]);
          if (i == 0) {
            upperLimit = upperPgon->rightmost;
          }
		} else {
		  j = (j - 1 + lowerPgon->numPoints) % lowerPgon->numPoints;
		  lowerPos = XVal(lowerPgon->points[j]);
          if (j == lowerPgon->numPoints - 1) {
            lowerLimit = lowerPgon->rightmost;
          }
		}
	  }
	}

	if (share == False) {
	  /* Compare rightmost points. */

	  if (SamePoint(&(upperPgon->points[i]), &(lowerPgon->points[j])) == True) {
		share = True;
		*upIdx = i;
		*lowIdx = j;
	  }
	}
#endif
  }

  return share;
}

