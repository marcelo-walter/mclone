
/******************************************************************
; Module:  Sweep Front for Voronoi Vertices
;
; description:
;   This module implements a sweep front for a dynamic sweep algorithm
;   that finds all Voronoi vertices of a set of polygonal sites.
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.02.07 / M. McAllister / ArcFree
;   95.02.21 / M. McAllister / ArcCreate, FRONT_LoadSite, FRONT_NewSite
;   95.03.13 / M. McAllister / FRONT_LoadSite
;   95.03.18 / M. McAllister / FRONT_TopArc
;   95.03.28 / M. McAllister / ScheduleForMiddleArc, NewArcEvents, FRONT_NewSite
;   95.05.07 / M. McAllister / FRONT_NewSite
;   95.05.08 / M. McAllister / Created FRONT_PreviousArc and FRONT_NextArc
;   95.10.10 / M. McAllister / GetLineSiteToProjectPt 
;   95.10.27 / M. McAllister / FRONT_LoadSite, FRONT_NewSite,
;                              FRONT_RemoveArc, NewArcEvents
;   95.12.13 / M. McAllister / ScheduleForMiddleArc
;   96.03.04 / M. McAllister / GetPgonValueInRange, ArcCompare
;   96.03.29 / M. McAllister / NewArcEvents
;   96.11.26 / M. McAllister / FRONT_NewSite
*******************************************************************/

#include "stdlib.h"

#include "globals.h"
#include "geometry.h"
#include "heap.h"
#include "frontDefs.h"
#include "front.h"
#include "polygon.h"
#include "schedule.h"
#include "frontAlarms.h"
#include "alarm.h"
#include "distance.h"

#define SweepLimits (10000)
#if 0
#define DEBUG 1
#endif

/*****************************************************************
; Forward declaration of all local routines.
******************************************************************/

static FRONT_ArcType ArcCreate (FRONT_FrontType theFront, Pgon *theGenerator, 
                                Ptr userDataPtr);

static Boolean ArcFree (Ptr theArc, Ptr dummy);

static Boolean FindProjectionPt (FRONT_ArcType theArc, Real sweepPosition, 
                                 Pt *thePoint);

static SInt16 ArcCompare (Ptr arc1, Ptr arc2);

static void GetLineSiteToProjectPt (spokeInfo *spokePtr, Line *linePtr);

static Boolean ScheduleVoronoiEvent (FRONT_ArcType top, FRONT_ArcType middle, 
                              FRONT_ArcType bottom, HEAP_Heap circles, 
                              spokeInfo *midSpokePtr);

static Boolean ScheduleForMiddleArc (FRONT_FrontType theFront, 
                                     FRONT_ArcType topArc, 
                                     FRONT_ArcType middleArc, 
                                     FRONT_ArcType bottomArc, 
                                     HEAP_Heap circles, 
                                     HEAP_Heap merges, 
                                     spokeInfo *midSpokePtr, Line *linePtr);

static Boolean NewArcEvents (FRONT_FrontType theFront, 
                             FRONT_ArcType upperArc, FRONT_ArcType newArc, 
                             FRONT_ArcType lowerArc, HEAP_Heap circles,
                             HEAP_Heap merges, Boolean lowerInFront);

static Real GetPgonValueInRange (Pgon *poly, UInt16 startIdx, 
                                  UInt16 endIdx, Real matchX);


/*****************************************************************
; Begin with the actual routines now.
******************************************************************/

/******************************************************************
; routine:  FRONT_Create
;
; description:
;   Create an empty sweep front.  The sweep front contains no
;   front arcs; these must be loaded via the FRONT_LoadSite
;   routine before the front is allowed to move.
;
; in:
;   configRoutines : FRONT_UserRoutineType * -- a set of user 
;                        routines that the front will invoke when
;                        it searches across the front (a shortcut for
;                        algorithm animation)
;
; out:
;   theFront : FRONT_FrontType * -- the allocated sweep front or
;                        FRONT_NullFront if the allocation failed.
;   returns : Boolean -- False if the sweep front could not be created,
;                        True otherwise
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

Boolean 
FRONT_Create (FRONT_UserRoutineType *configRoutines, FRONT_FrontType *theFront)
{
  Boolean  frontCreated = False;

  *theFront = (FRONT_FrontType) malloc (sizeof(_FRONT_FrontInfoType));
  if (*theFront == NULL) {
    *theFront = FRONT_NullFront;
    AL_SoftwareAlarm (AL_Id_FRONT_NoMainMemory, AL_Fn_NullFunction, 0, 0, 0, 0);
  } else {

    /* Get a red-black tree for all the front arcs. */

    (*theFront)->balancedTree = RBTREE_Alloc(ArcCompare, "Front");
    if ((*theFront)->balancedTree == RBTREE_NullTree) {

      /* Can't go on without a red-black tree.  Get rid of what we have.  */

      free (*theFront);
      *theFront = FRONT_NullFront;
    } else {
#ifdef paranoid
      /* Set up memory guards for the structure. */

      (*theFront)->headGuard = _FRONT_HeadTag;
      (*theFront)->tailGuard = _FRONT_TailTag;
#endif

      /* Initialise the remaining fields of the structure. */

      (*theFront)->configRoutines.spokeSearchRtn = 
                                                configRoutines->spokeSearchRtn;
      (*theFront)->configRoutines.vorVtxSearchRtn = 
                                                configRoutines->vorVtxSearchRtn;
      (*theFront)->loadStage = _FRONT_Empty;
      (*theFront)->sweepXVal = 0;

      frontCreated = True;
    }
  }

  return frontCreated;
}

/******************************************************************
; routine:  FRONT_Free
;
; description:
;   Destroy all the allocations for a sweep front.
;
;   The caller is responsible for free'ing all data stored in the
;   front before calling this routine; this routine will not release
;   user-allocated data space.
;
;   The caller is responsible for not using the sweep front id
;   after the free call.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to release.
;
; out:
;   none
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

void 
FRONT_Free (FRONT_FrontType theFront)
{
  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_Free, 0, 0, 0, 0);
  } else {

    /* Get rid of all the front arcs. */

    RBTREE_ForEachNode (theFront->balancedTree, ArcFree, 0);
    RBTREE_Free (theFront->balancedTree);
    theFront->balancedTree = RBTREE_NullTree;

    /* Make the sweep front data structure invalid. */

    theFront->loadStage = _FRONT_Empty;
#ifdef paranoid
    theFront->headGuard = 0;
    theFront->tailGuard = 0;
#endif
    
    /* Get rid of the front. */

    free (theFront);
  }
}

/******************************************************************
; routine:  FRONT_Advance
;
; description:
;   Indicate to the data structure that the sweep front has
;   moved to a new position.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front that is advancing
;   newPos : Real -- the new position of the sweep front
;
; out:
;   returns : Boolean -- False if the sweep front data structure cannot
;                        recognize the advance as valid
;
; implementation note:
;   The main purpose for this routine is to provide a means for
;   clearing intermediate data if ever value caching is performed
;   and that caching involves data that changes with the sweep line.
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

Boolean 
FRONT_Advance(FRONT_FrontType theFront, Real newPos)
{
  Boolean  advanced = False;

  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_Advance, 0, 0, 0, 0);
  } else {
#ifdef paranoidCheck
    if (newPos < theFront->sweepXVal) {
      AL_SoftwareAlarm (AL_Id_FRONT_MoveBadDirection, AL_Fn_NullFunction, 
                        0, 0, 0, 0);
    } else {
#endif
	  theFront->sweepXVal = newPos;
	  theFront->loadStage = _FRONT_MovingFront;
	  advanced = True;
#ifdef paranoidCheck
	}
#endif
  }

  return advanced;
}

/******************************************************************
; routine:  FRONT_LoadSite
;
; description:
;   Add a front arc / site to the sweep front.  This site should not
;   break any existing front arcs; instead the front arc is simply
;   inserted into its appropriate order within the sweep front and
;   appropriate circle events are scheduled for it.
;
;   This routine is used to initialise the sweep front with all
;   of the leftmost polygons of the set of sites.  A site is
;   acceptable if
;     - the sweep front's state is still accepting initialization data
;       (i.e. the sweep front has not moved yet)
;     - the inserted site has its leftmost point at the same
;       x coordinate as all other sites already in the sweep front.
;
;   If the routine returns a value of False then the state of the
;   sweep front and the schedule of events cannot be trusted.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to which the site is added
;   site : Pgon * -- the site to add
;   circles : HEAP_Heap -- the schedule of circle events
;   merges : HEAP_Heap -- the schedule of site merging events
;   siteData : Ptr -- user-supplied data that goes with the added site
;
; out:
;   circles -- events may be added or deleted from the schedule
;   merges -- events may be added or deleted from the schedule
;   theArc : FRONT_ArcType * -- the front arc created for the site.
;                        Its value is FRONT_NullArc if the no arc
;                        could be created
;   returns : Boolean -- False if the site could not be added to the
;                        sweep front; True otherwise
;
; history:
;   95.02.21 / M. McAllister / Created
;   95.03.13 / M. McAllister / Mistakingly compring loadStage with X position
;   95.10.27 / M. McAllister / Use RBTREE next and previous data functions
*******************************************************************/

Boolean 
FRONT_LoadSite (FRONT_FrontType theFront, Pgon *site, HEAP_Heap circles, 
                HEAP_Heap merges, Ptr siteData, FRONT_ArcType *theArc)
{
  Boolean loadOkay = False;
  Ptr     dummyPtr;

  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_LoadSite, 0, 0, 0, 0);
  } else {
    if (site == NULL) {
      AL_SoftwareAlarm (AL_Id_FRONT_NullSite, AL_Fn_FRONT_LoadSite, 0, 0, 0, 0);
    } else {
      if (theFront->loadStage == _FRONT_MovingFront) {
        AL_SoftwareAlarm (AL_Id_FRONT_BadLoadState, AL_Fn_FRONT_LoadSite, 
                          (UInt32) theFront->loadStage, 0, 0, 0);
      } else {

		/* If this is the first site then record where the sweepline 
           is starting. */

		if (theFront->loadStage == _FRONT_Empty) {
		  theFront->sweepXVal = XVal(LeftPoint(site));
		  theFront->loadStage = _FRONT_FirstSites;
		}

		/* Make sure that the site to add is really a leftmost one, within 
		   tolerance. */

		if (Equal(theFront->sweepXVal, XVal(LeftPoint(site)))) {

		  /* Add it in! */

		  *theArc = ArcCreate (theFront, site, siteData);
		  if (*theArc != FRONT_NullArc) {

			/* The create routine has already set up a spoke for the 
			   arc so that the red-black tree comparison routine will work
			   on the arc. */

			if (RBTREE_Add (theFront->balancedTree, (Ptr) *theArc,
							&((*theArc)->treeNode)) == False) {
			  /* Something went wrong -- we won't keep the arc around. */

			  ArcFree (*theArc, &dummyPtr);
			  *theArc = FRONT_NullArc;
			} else {

			  /* Correct the event schedule for the new arc. */

			  loadOkay = NewArcEvents (theFront, (FRONT_ArcType) 
                   RBTREE_PreviousData (theFront->balancedTree,
                   (*theArc)->treeNode), *theArc, (FRONT_ArcType) 
                   RBTREE_NextData (theFront->balancedTree,
                   (*theArc)->treeNode), circles, merges, True);
			}
		  }
		}
      }  /* check for front state */
    }  /* check for null site */
  } /* check for null front */

  return loadOkay;
}

/******************************************************************
; routine:  FRONT_NewSite
;
; description:
;   Add a front arc / site to the sweep front once the sweep front
;   is in motion.
;
;   This routine will locate the nearest front arc to the new site
;   and will split that front arc into two pieces, inserting the
;   new site between the two ends.  Circle events are added and
;   deleted from the schedule to reflect the change in the 
;   sweep front.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to which the site is added
;   site : Pgon * -- the site to add
;   circles : HEAP_Heap -- the schedule of circle events
;   merges : HEAP_Heap -- the schedule of site merging events
;   newSiteData : Ptr -- user-supplied data that goes with the new site
;   splitArcData : Ptr -- user-supplied data that will go with the lower
;                         half of the split arc.  The upper half of
;                         the split arc inherits the data pointer from
;                         the arc before the split.
;
; out:
;   circles -- events may be added or deleted from the schedule
;   merges -- events may be added or deleted from the schedule
;   newSiteArc : FRONT_ArcType * -- the front arc created for the new site.
;                        Its value is FRONT_NullArc if the no arc
;                        could be created
;   lowerSplitArc : FRONT_ArcType * -- the front arc created as the
;                        bottom half of the split arc (thus the upper
;                        half can be found with the PrevArcForSite routine).
;   returns : Boolean -- False if the site could not be added to the
;                        sweep front; True otherwise
;
; history:
;   95.02.21 / M. McAllister / Created
;   95.03.28 / M. McAllister / Add arc events before putting nodes into
;                              the rbtree.  This way, the tree passes audits.
;   95.05.07 / M. McAllister / When splitting an arc, copy the heap ref
;                              when arc is at top of triple to the lower arc
;   95.10.27 / M. McAllister / Use RBTREE next and previous data functions
;   96.11.26 / M. McAllister / Use GEOM_EPSILON to avoid name conflict
*******************************************************************/

Boolean 
FRONT_NewSite(FRONT_FrontType theFront, Pgon *site, HEAP_Heap circles, 
              HEAP_Heap merges,
              Ptr newSiteData, Ptr splitArcData, FRONT_ArcType *newSiteArc, 
              FRONT_ArcType *lowerSplitArc)
{
  Boolean          addOkay = False;
  RBTREE_NodeType  prevNode;
  FRONT_ArcType    prevArc;
  FRONT_ArcType    nextArc;
  FRONT_ArcType    arcToSplit;
  Boolean          ignoreResult;
  Ptr              dummyPtr;
  scheduleInfo     *aCircleEvent;

  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_NewSite, 0, 0, 0, 0);
  } else {
    if (site == NULL) {
      AL_SoftwareAlarm (AL_Id_FRONT_NullSite, AL_Fn_FRONT_NewSite, 0, 0, 0, 0);
    } else {
      if (theFront->loadStage == _FRONT_Empty) {
        AL_SoftwareAlarm (AL_Id_FRONT_BadLoadState, AL_Fn_FRONT_NewSite, 
                          (UInt32) theFront->loadStage, 0, 0, 0);
      } else {

		/* The basic conditions check out. */

		theFront->loadStage = _FRONT_MovingFront;

		/* Create new arcs and find where to insert it.  The comparison
		   routine for the red-black tree will give us two candidates
		   (the arc returned and its successor). */

		*newSiteArc = ArcCreate(theFront, site, newSiteData);
		if (*newSiteArc != FRONT_NullArc) {
		  ignoreResult = RBTREE_FindNode(theFront->balancedTree, 
              (Ptr)*newSiteArc, &prevNode);

		  if (prevNode == RBTREE_NullNode) {
			/* We are breaking the topmost arc. */
			prevNode = RBTREE_Next(theFront->balancedTree, RBTREE_NullNode);
		  }

		  prevArc = (FRONT_ArcType) RBTREE_GetData(prevNode);
		  nextArc = (FRONT_ArcType) RBTREE_NextData(
							  theFront->balancedTree, prevNode);

		  if (prevArc == FRONT_NullArc) {
			arcToSplit = nextArc;
		  } else if (nextArc == FRONT_NullArc) {
			arcToSplit = prevArc;
		  } else {
            /* What follows is one giant hack that needs to be replaced.  
               mjm TBD */

            /* Look for some easy degenerate cases right at the start.  */

            if (Equal(XVal(LeftPoint(prevArc->generator)),theFront->sweepXVal)){
              arcToSplit = nextArc;
            } else if (Equal(XVal(LeftPoint(nextArc->generator)),
                             theFront->sweepXVal)) {
              arcToSplit = prevArc;
            } else if (SamePoint(&(RightPoint(nextArc->generator)),
                             &(LeftPoint(site)))) {
              arcToSplit = nextArc;
            } else if (SamePoint(&(RightPoint(prevArc->generator)),
                             &(LeftPoint(site)))) {
              arcToSplit = prevArc;
            } else {
			  Pgon      *sweepLine;
			  Pt        linePts[2];
			  Pt        vorPt, eventPt;
			  spokeInfo sweepSpoke;
			  Boolean   dontCare;
			  Pt        projectPt;
              Real     newLimit;

			  /* Find the Voronoi vertex between the two sites that 
				 generate the front arcs and the sweep line.  We have to
				 pull a bit of a trick by shortening the sweepline
				 whenever the sweepline crosses one of the sites. */

			  /* Make my sweep line -- a temporary measure. */

			  linePts[0].w = 1.0; linePts[0].x = theFront->sweepXVal; 
			  dontCare = FindProjectionPt (nextArc, theFront->sweepXVal, &projectPt);
			  linePts[0].y = YVal(projectPt); /*(-1 * SweepLimits);*/
			  linePts[1].w = 1.0; linePts[1].x = theFront->sweepXVal; 
			  dontCare = FindProjectionPt (prevArc, theFront->sweepXVal, &projectPt);
			  linePts[1].y = YVal(projectPt); /*SweepLimits;*/

              arcToSplit = NULL;
              if (Equal(linePts[1].y, YVal(LeftPoint(site)))) {
                arcToSplit = prevArc;
              } else if (Equal(linePts[0].y, YVal(LeftPoint(site)))) {
                arcToSplit = nextArc;
              } else {
			    /* See if the limits need to be adjusted.  If the sweepline
				   cuts through one of the polygons then trim the sweepline.  */

				if (XVal(RightPoint(nextArc->generator)) > theFront->sweepXVal) {
				  /* Adjust linePts[0] but it must remain the lower point */

				  newLimit = GetPgonValueInRange (nextArc->generator, 
						 nextArc->generator->rightmost, 
						 nextArc->generator->leftmost, 
						 theFront->sweepXVal) + GEOM_EPSILON;
				  if (newLimit <= linePts[1].y) {
					linePts[0].y = newLimit;
				  }
				}

				if (XVal(RightPoint(prevArc->generator)) > theFront->sweepXVal) {
				  /* Adjust linePts[1] while it remains the higher point */

				  newLimit = GetPgonValueInRange (prevArc->generator, 
						 prevArc->generator->leftmost, 
						 prevArc->generator->rightmost, 
						 theFront->sweepXVal) - GEOM_EPSILON;
				  if (newLimit >= linePts[0].y) {
					linePts[1].y = newLimit;
				  }
				}

			    sweepLine = newPolygon (2, &(linePts[0]));

			    /* Find the Voronoi vertex and base the judgement on that spot.  */

			    dontCare = voronoiVertex(nextArc->generator, sweepLine, 
				   prevArc->generator, &vorPt, &eventPt, &sweepSpoke);

			    if (theFront->configRoutines.vorVtxSearchRtn != NULL) {
				  (*(theFront->configRoutines.vorVtxSearchRtn))
				   (nextArc->generator, prevArc->generator, theFront->sweepXVal,
				    &vorPt);
			    }

  			    killPolygon (&sweepLine);
              }

#ifdef Hack
              if ((arcToSplit == NULL) &&
                  (SamePoint(&(LeftPoint(nextArc->generator)),
                            &(RightPoint(prevArc->generator))) ||
                  SamePoint(&(RightPoint(nextArc->generator)),
                            &(LeftPoint(prevArc->generator))) )) {

                Pt  nearestNext, nearestPrev, commonPt, cand1, cand2;
                Pt  *otherNext, *otherPrev, *farPoint, *intersect;
                Real distNext, distPrev;
                FRONT_ArcType nearArc, farArc;
                Line  line, perp, sweep;
                Parabola  para;

                if (SamePoint(&(LeftPoint(nextArc->generator)),
                              &(RightPoint(prevArc->generator)))) {
                  PointAssign (commonPt, LeftPoint(nextArc->generator));
                  otherNext = &(RightPoint(nextArc->generator));
                  otherPrev = &(LeftPoint(prevArc->generator));
                } else {
                  PointAssign (commonPt, LeftPoint(prevArc->generator));
                  otherNext = &(LeftPoint(nextArc->generator));
                  otherPrev = &(RightPoint(prevArc->generator));
                }
                              
                ptNearestSegment(&vorPt, &(LeftPoint(nextArc->generator)),
                               &(RightPoint(nextArc->generator)), &nearestNext);
                ptNearestSegment(&vorPt, &(LeftPoint(prevArc->generator)),
                               &(RightPoint(prevArc->generator)), &nearestPrev);
                if (SamePoint (&nearestNext, &commonPt) ||
                    SamePoint (&commonPt, &nearestPrev)) {

                  /* Find which line the new site is nearest. */
				  ptNearestSegment(&(LeftPoint(site)), &commonPt,
								   otherNext, &nearestNext);
				  squarePointDistance (&(LeftPoint(site)), &nearestNext, 
									   &distNext);
				  ptNearestSegment(&(LeftPoint(site)), &commonPt,
								   otherPrev, &nearestPrev);
				  squarePointDistance (&(LeftPoint(site)), &nearestPrev, 
									   &distPrev);
				  if (distNext < distPrev) {
					nearArc = nextArc; 
					farArc = prevArc;
					farPoint = otherPrev;
				  } else {
					nearArc = prevArc; 
					farArc = nextArc;
					farPoint = otherNext;
				  }
				  LineOf (&commonPt, farPoint, &line);
				  perpendicularLine (&commonPt, &line, &perp);
				  sweep.w = theFront->sweepXVal; sweep.x = -1.0; sweep.y = 0.0;
				  createParabola (&commonPt, &sweep, &para);
				  intersectLineParabola (&perp, &para, &cand1, &cand2);
				  if (((YVal(commonPt) < YVal(*farPoint)) && 
					   (YVal(commonPt) < YVal(cand1))) ||
					  ((YVal(commonPt) > YVal(*farPoint)) && 
					   (YVal(commonPt) > YVal(cand1))) ) {
					intersect = &cand2;
				  } else {
					intersect = &cand1;
				  }
				  if ((YVal(*intersect) - YVal(LeftPoint(site))) *
                      (YVal(LeftPoint(site)) - YVal(commonPt)) > 0) {
                    arcToSplit = nearArc;
                  } else {
                    arcToSplit = farArc;
                  }
                }
              }

#endif
              if (arcToSplit == NULL) {
			    if (YVal(vorPt) > YVal(LeftPoint(site))) {
			  	arcToSplit = nextArc;
			    } else {
			  	arcToSplit = prevArc;
			    }
			  }
			}
		  }

		  /* We now know what arc to split.  Make the split. */

		  *lowerSplitArc = ArcCreate(theFront, arcToSplit->generator, 
                                     splitArcData);
		  if (*lowerSplitArc == FRONT_NullArc) {
			/* Big trouble.  Get rid of the arc that we did manage
			   to claim and the abandon ship.  ArcCreate had better
               complain about the error. */

			ArcFree (*newSiteArc, &dummyPtr);
			*newSiteArc = FRONT_NullArc;
		  } else {

			/* Make the split arc ends adjacent in the linked list. */

			(*lowerSplitArc)->prevArc = arcToSplit;
			(*lowerSplitArc)->nextArc = arcToSplit->nextArc;
			if (arcToSplit->nextArc != NULL) {
			  arcToSplit->nextArc->prevArc = *lowerSplitArc;
			}
			arcToSplit->nextArc = *lowerSplitArc;

            /* The new lower half of the split arc inherits the
               Voronoi event where it is at the top of the triple. */

            (*lowerSplitArc)->vorEvents[_FRONT_IAmTopArc] =
                                    arcToSplit->vorEvents[_FRONT_IAmTopArc];
            if (arcToSplit->vorEvents[_FRONT_IAmTopArc] != HEAP_NullHeapId) {
              HEAP_PeekNamed (circles, arcToSplit->vorEvents[_FRONT_IAmTopArc], 
                              (Ptr *)(&aCircleEvent));
              aCircleEvent->frontArcs[_FRONT_IAmTopArc] = *lowerSplitArc;
            }

            /* Do the last bits of rescheduling for the new arcs. */

            if (NewArcEvents (theFront, arcToSplit, *newSiteArc, 
                              *lowerSplitArc, circles, merges, False) == True) {

			  /* Put the new front arcs into the sweep front. */

			  addOkay = RBTREE_AddAfterNode(theFront->balancedTree, 
                            arcToSplit->treeNode, (Ptr)*newSiteArc, 
                            &((*newSiteArc)->treeNode)) &&
				RBTREE_AddAfterNode(theFront->balancedTree, 
					        (*newSiteArc)->treeNode, (Ptr)*lowerSplitArc, 
					        &((*lowerSplitArc)->treeNode));

			}
		  }
		}
      }  /* check for front state */
    }  /* check for null site */
  } /* check for null front */

  return addOkay;
}

/******************************************************************
; routine:  FRONT_RemoveArc
;
; description:
;   Remove a front arc from the sweep front.  The removal will cause
;   circle events to be added and deleted from the event schedule.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front that is losing an arc
;   theArc : FRONT_ArcType -- the arc that should be removed
;   circles : HEAP_Heap -- the schedule of circle events
;   merges : HEAP_Heap -- the schedule of merging site events
;
; out:
;   circles -- events may be added or deleted from the schedule
;   merges -- events may be added or deleted from the schedule
;   returns : Boolean -- False if the arc could not be removed; True otherwise
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.10.27 / M. McAllister / Use next and previous data functions for RBTREE
*******************************************************************/

Boolean 
FRONT_RemoveArc (FRONT_FrontType theFront, FRONT_ArcType theArc, 
                 HEAP_Heap circles, HEAP_Heap merges, 
                 Boolean removeMiddleVoronoi)
{
  Boolean       arcIsGone = False;
  FRONT_ArcType predecessor;
  FRONT_ArcType successor;
  Ptr           deadPtr;
  Ptr           deadPtr2;

  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_RemoveArc, 0, 0, 0, 0);
  } else {
    if (theArc == FRONT_NullArc) {
      AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_RemoveArc, 0, 0, 0, 0);
    } else {
      if (theArc->myFront != theFront) {
        AL_SoftwareAlarm (AL_Id_FRONT_ArcInWrongFront, AL_Fn_FRONT_RemoveArc, 
                          (UInt32) theArc, (UInt32) theFront, 0, 0);
      } else {

		/* Remember where the node sits in the front. */

		predecessor = (FRONT_ArcType) RBTREE_PreviousData(
		                    		  theFront->balancedTree, theArc->treeNode);
		successor = (FRONT_ArcType) RBTREE_NextData(
				                      theFront->balancedTree, theArc->treeNode);

		if (RBTREE_Delete (theArc->treeNode) == True) {

		  /* Unlink the arc from its peers (of the same site) */

		  if (theArc->prevArc != NULL) {
			theArc->prevArc->nextArc = theArc->nextArc;
		  }
		  if (theArc->nextArc != NULL) {
			theArc->nextArc->prevArc = theArc->prevArc;
		  }

		  /* Get rid of circle events that it may be involved in. */

		  deadPtr = NULL;
		  if ((theArc->vorEvents[_FRONT_IAmTopArc] == HEAP_NullHeapId) ||
				(HEAP_PopNamed (circles, theArc->vorEvents[_FRONT_IAmTopArc], 
							  &deadPtr))) {
			if (deadPtr != NULL) {
			  freeSchedule((scheduleInfo **)(&deadPtr));
			  deadPtr = NULL;
			}
#ifdef Hack
		  if ((removeMiddleVoronoi == False) ||
              ((theArc->vorEvents[_FRONT_IAmMiddleArc] == HEAP_NullHeapId) ||
				(HEAP_PopNamed (circles, theArc->vorEvents[_FRONT_IAmMiddleArc],
							  &deadPtr)))) {
			if (deadPtr != NULL) {
			  freeSchedule((scheduleInfo **)(&deadPtr));
			  deadPtr = NULL;
			}
#endif

			if ((theArc->vorEvents[_FRONT_IAmBottomArc] == HEAP_NullHeapId) ||
				 (HEAP_PopNamed (circles,theArc->vorEvents[_FRONT_IAmBottomArc],
								 &deadPtr))) {

			  if (deadPtr != NULL) {
				freeSchedule((scheduleInfo **)(&deadPtr));
		        deadPtr = NULL;
			  }

              deadPtr2 = NULL;
              if(((theArc->mergeEvent == HEAP_NullHeapId) ||
                  HEAP_PopNamed (merges, theArc->mergeEvent, &deadPtr)) &&
                 ((predecessor == NULL) || 
                  (predecessor->mergeEvent == HEAP_NullHeapId) || 
                  HEAP_PopNamed (merges, predecessor->mergeEvent,&deadPtr2))) {

			    if (deadPtr != NULL) {
				  freeSchedule((scheduleInfo **)(&deadPtr));
			    }
			    if (deadPtr2 != NULL) {
				  freeSchedule((scheduleInfo **)(&deadPtr2));
			    }

                theArc->mergeEvent = HEAP_NullHeapId;
                if (predecessor != NULL) {
                  predecessor->mergeEvent = HEAP_NullHeapId;
                }

                ArcFree (theArc, &deadPtr);
              
				/* Reschedule the world. */

				if (((predecessor == FRONT_NullArc) || 
					 (ScheduleForMiddleArc (theFront, 
					 (FRONT_ArcType)RBTREE_PreviousData (theFront->balancedTree,
							predecessor->treeNode),
							predecessor, 
							successor,
							circles, merges, &(predecessor->spoke),
							&(predecessor->lineToProjectPt)) == True)) &&
					((successor == FRONT_NullArc) || 
					 (ScheduleForMiddleArc (theFront, 
							predecessor,
							successor, 
					 (FRONT_ArcType) RBTREE_NextData (theFront->balancedTree,
							successor->treeNode),
							circles, merges, &(successor->spoke),
							&(successor->lineToProjectPt)) == True))) {
				  arcIsGone = True;
				}
              }
            }
#ifdef Hack
            }
#endif
		  }
		}
      } /* check for arc belonging to the front */
    } /* check for null arc */
  } /* check for null front */

  return arcIsGone;
}

/******************************************************************
; routine:  FRONT_TopArc
;
; description:
;   Returns with the identifier for the highest (in y-coordinates)
;   front arc in the sweep front.  If the sweep front is empty or
;   is FRONT_NullFront then FRONT_NullArc is returned.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front
;
; out:
;   returns : FRONT_ArcType -- the highest front arc of the sweep front
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.03.18 / M. McAllister / Use RBTREE_Next, not "previous" to get top arc
*******************************************************************/

FRONT_ArcType 
FRONT_TopArc (FRONT_FrontType theFront)
{
  FRONT_ArcType    topArc = FRONT_NullArc;
  RBTREE_NodeType  topNode;

  if (theFront != FRONT_NullFront) {
    topNode = RBTREE_Next(theFront->balancedTree, RBTREE_NullNode);
    if (topNode != RBTREE_NullNode) {
      topArc = (FRONT_ArcType) RBTREE_GetData(topNode);
    }
  }

  return topArc;
}

/******************************************************************
; routine:  FRONT_BottomArc
;
; description:
;   Returns with the identifier for the lowest (in y-coordinates)
;   front arc in the sweep front.  If the sweep front is empty or
;   is FRONT_NullFront then FRONT_NullArc is returned.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front
;
; out:
;   returns : FRONT_ArcType -- the lowest front arc of the sweep front
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

FRONT_ArcType 
FRONT_BottomArc (FRONT_FrontType theFront)
{
  FRONT_ArcType    bottomArc = FRONT_NullArc;
  RBTREE_NodeType  bottomNode;

  if (theFront != FRONT_NullFront) {
    bottomNode = RBTREE_Previous(theFront->balancedTree, RBTREE_NullNode);
    if (bottomNode != RBTREE_NullNode) {
      bottomArc = (FRONT_ArcType) RBTREE_GetData(bottomNode);
    }
  }

  return bottomArc;
}

/******************************************************************
; routine:  FRONT_PreviousArc
;
; description:
;   Returns with the identifier for the next higher (in y-coordinates)
;   front arc in the sweep front.  If the sweep front is empty,
;   is FRONT_NullFront, or the given arc is FRONT_NullArc then 
;   FRONT_NullArc is returned.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front
;   theArc : FRONT_ArcType -- the arc for which we want the predecessor
;
; out:
;   returns : FRONT_ArcType -- the predecessor of 'theArc' in the sweep front
;
; history:
;   95.05.08 / M. McAllister / Created
*******************************************************************/
FRONT_ArcType 
FRONT_PreviousArc (FRONT_FrontType theFront, FRONT_ArcType theArc)
{
  FRONT_ArcType    prevArc = FRONT_NullArc;
  RBTREE_NodeType  prevNode;

  if ((theFront != FRONT_NullFront)  && (theArc != FRONT_NullArc)) {
    prevNode = RBTREE_Previous(theFront->balancedTree, theArc->treeNode);
    if (prevNode != RBTREE_NullNode) {
      prevArc = (FRONT_ArcType) RBTREE_GetData(prevNode);
    }
  }

  return prevArc;
}

/******************************************************************
; routine:  FRONT_NextArc
;
; description:
;   Returns with the identifier for the next lower (in y-coordinates)
;   front arc in the sweep front.  If the sweep front is empty,
;   is FRONT_NullFront, or the given arc is FRONT_NullArc then 
;   FRONT_NullArc is returned.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front
;   theArc : FRONT_ArcType -- the arc for which we want the successor
;
; out:
;   returns : FRONT_ArcType -- the successor of 'theArc' in the sweep front
;
; history:
;   95.05.08 / M. McAllister / Created
*******************************************************************/
FRONT_ArcType 
FRONT_NextArc  (FRONT_FrontType theFront, FRONT_ArcType theArc)
{
  FRONT_ArcType    nextArc = FRONT_NullArc;
  RBTREE_NodeType  nextNode;

  if ((theFront != FRONT_NullFront)  && (theArc != FRONT_NullArc)) {
    nextNode = RBTREE_Next(theFront->balancedTree, theArc->treeNode);
    if (nextNode != RBTREE_NullNode) {
      nextArc = (FRONT_ArcType) RBTREE_GetData(nextNode);
    }
  }

  return nextArc;
}

/******************************************************************
; routine:  FRONT_PrevArcForSite
;
; description:
;   Given a front arc, the routine returns with the identifier
;   for the next highest front arc in the sweep front that is
;   generated by the same site.
;
;   If the sweep front is empty or null values appear for either
;   the sweep front or the front arc then the routine returns with
;   FRONT_NullArc.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to search in
;   theArc : FRONT_ArcType -- the arc whose site we want to match
;
; out:
;   returns : FRONT_ArcType -- the next highest front arc to theArc 
;                              generated by the same site as theArc
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

FRONT_ArcType 
FRONT_PrevArcForSite (FRONT_FrontType theFront, FRONT_ArcType theArc)
{
  FRONT_ArcType prevArc = FRONT_NullArc;

  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_PrevForSite,0,0,0,0);
  } else {
    if (theArc == FRONT_NullArc) {
      AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_PrevForSite,0,0,0,0);
    } else {
      if (theArc->myFront != theFront) {
        AL_SoftwareAlarm (AL_Id_FRONT_ArcInWrongFront, AL_Fn_FRONT_PrevForSite, 
                          (UInt32) theArc, (UInt32) theFront, 0, 0);
      } else {

        /* Everything checks out -- get the previous arc. */

        prevArc = (theArc->prevArc != NULL ? theArc->prevArc : FRONT_NullArc);

      } /* check arc in the front */
    } /* check for null arc */
  } /* check null front */

  return prevArc;
}

/******************************************************************
; routine:  FRONT_NextArcForSite
;
; description:
;   Given a front arc, the routine returns with the identifier
;   for the next lower front arc in the sweep front that is
;   generated by the same site.
;
;   If the sweep front is empty or null values appear for either
;   the sweep front or the front arc then the routine returns with
;   FRONT_NullArc.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to search in
;   theArc : FRONT_ArcType -- the arc whose site we want to match
;
; out:
;   returns : FRONT_ArcType -- the next lower front arc to theArc 
;                              generated by the same site as theArc
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

FRONT_ArcType 
FRONT_NextArcForSite (FRONT_FrontType theFront, FRONT_ArcType theArc)
{
  FRONT_ArcType nextArc = FRONT_NullArc;

  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_NextForSite,0,0,0,0);
  } else {
    if (theArc == FRONT_NullArc) {
      AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_NextForSite,0,0,0,0);
    } else {
      if (theArc->myFront != theFront) {
        AL_SoftwareAlarm (AL_Id_FRONT_ArcInWrongFront, AL_Fn_FRONT_NextForSite, 
                          (UInt32) theArc, (UInt32) theFront, 0, 0);
      } else {

        /* Everything checks out -- get the next arc. */

        nextArc = (theArc->nextArc != NULL ? theArc->nextArc : FRONT_NullArc);

      } /* check arc in the front */
    } /* check for null arc */
  } /* check null front */

  return nextArc;
}

/******************************************************************
; routine:  FRONT_Traverse
;
; description:
;   Invoke the given routine for each front arc in the swee front.
;   The called routine is supplied with the front arc identifier 
;   of each front arc and the common data in dataPtr supplied by the
;   caller.
;
;   The traversal stops immediately if ever the user-routine returns
;   with a value of False.  That False value is then returned to the
;   caller.  Otherwise, the traversal routine returns with the value of
;   True.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to traverse
;   rtn : Boolean (*)(FRONT_ArcType, Ptr) -- the procedure to invoke
;                         for each front arc
;   dataPtr : Ptr -- data to supply to each invocation of rtn so that
;                    the caller can maintain some context over the 
;                    set of invocations.
;
; out:
;   returns : Boolean -- True if all calls to rtn returned with True;
;                        False if the traversal was prematurely aborted.
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

Boolean 
FRONT_Traverse (FRONT_FrontType theFront, 
                Boolean (*rtn)(FRONT_ArcType theArc, Ptr dataPtr), Ptr dataPtr)
{
  return RBTREE_ForEachNode (theFront->balancedTree, 
                             (Boolean(*)(Ptr, Ptr)) rtn, dataPtr);
}

/******************************************************************
; routine:  FRONT_GetData
;
; description:
;   Retrieve the user-data stored with a front arc.  If a null front
;   arc is supplied then the routine returns a value of NULL.
;
; in:
;   theArc : FRONT_ArcType -- the arc whose data we wish to extract
;
; out:
;   returns : Ptr -- the user data (possibly NULL)
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

Ptr 
FRONT_GetData (FRONT_ArcType theArc)
{
  Ptr   dataPtr = NULL;

  if (theArc != FRONT_NullArc) {
    dataPtr = theArc->dataPtr;
  }

  return dataPtr;
}

/*****************************************************************
; Return to the local, static routines that really do all the work
******************************************************************/

/******************************************************************
; routine:  ArcCreate
;
; description:
;   Create an instance of a front arc and initialize its fields.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to which the arc
;                                 belongs (may be FRONT_NullFront)
;   theGenerator : Pgon * -- the site that is generating the front arc
;                            (may be NULL)
;   userDataPtr : Ptr -- user data associated with the front arc
;
; out:
;   returns : FRONT_ArcType -- the identifier for the allocated 
;                front arc.  If the allocation fail then a value
;                of FRONT_NullArc is returned.
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.02.21 / M. McAllister / Make default spoke valid rather than zeros.
*******************************************************************/

static FRONT_ArcType 
ArcCreate (FRONT_FrontType theFront, Pgon *theGenerator, Ptr userDataPtr)
{
  FRONT_ArcType  newArcPtr;
  Vector         spokeToVertical;

  newArcPtr = (FRONT_ArcType) malloc(sizeof(_FRONT_ArcInfoType));
  if (newArcPtr == NULL) {
    AL_SoftwareAlarm (AL_Id_FRONT_NoArcMemory, AL_Fn_NullFunction, 0, 0, 0, 0);
  } else {

#ifdef paranoid
    /* Memory guards for the structure. */

    newArcPtr->headGuard = _FRONT_ArcHeadTag;
    newArcPtr->tailGuard = _FRONT_ArcTailTag;
#endif

    /* Store the supplied data for the arc. */

    newArcPtr->myFront   = theFront;
    newArcPtr->generator = theGenerator;
    newArcPtr->dataPtr   = userDataPtr;

    /* Fill the rest of the structure with default values. */

    newArcPtr->treeNode = RBTREE_NullNode;
    newArcPtr->prevArc  = NULL;
    newArcPtr->nextArc  = NULL;

    newArcPtr->vorEvents[_FRONT_IAmTopArc]    = HEAP_NullHeapId;
    newArcPtr->vorEvents[_FRONT_IAmMiddleArc] = HEAP_NullHeapId;
    newArcPtr->vorEvents[_FRONT_IAmBottomArc] = HEAP_NullHeapId;

    newArcPtr->mergeEvent = HEAP_NullHeapId;

    /* Create a spoke for the arc that goes from the rightmost point
       of the site along the spoke to a vertical line to the right
       of the site.  We do this rather than a line from the leftmost
       point to the rightmost point so that point-sites and vertical
       line sites can be handled without special cases. */

    PointAssign(newArcPtr->spoke.attachment, RightPoint(theGenerator));

    getSweeplineTan (&spokeToVertical);
    AddPoints(newArcPtr->spoke.attachment, spokeToVertical, 
              newArcPtr->spoke.otherPt);

    GetLineSiteToProjectPt (&(newArcPtr->spoke), &(newArcPtr->lineToProjectPt));
  }

  return newArcPtr;
}

/******************************************************************
; routine:  ArcFree
;
; description:
;   Release the memory allocated to a front arc. 
;
; in:
;   theArc : Ptr -- the arc to be deletedd
;   dummy : Ptr -- an unused parameter -- see interface note
;
; out:
;   returns : Boolean -- always returns True; what can you do
;                        if the free function fails?
;
; interface note:
;   The interface for this function has been made to match that
;   required by RBTREE_ForEachNode.  This red-black tree routine is
;   used to release all front arcs in a sweep front by FRONT_Free.
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.02.07 / M. McAllister / Changed interface to suit RBTREE_ForEachNode
*******************************************************************/

static Boolean 
ArcFree (Ptr theArc, Ptr dummy)
{
  FRONT_ArcType  anArc;

  /* theArc parameter is really a front arc. */

  anArc = (FRONT_ArcType) theArc;

  if (anArc == FRONT_NullArc) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_ArcFree, 0, 0, 0, 0);
  } else {
#ifdef paranoid
    /* Erase the memory guards so nobody ever things that this
       entry is actually active anymore. */

    anArc->headGuard = 0;
    anArc->tailGuard = 0;
#endif

    /* Get rid of the memory for the arc. */

    free (anArc);
  }

  /* Always succeed. */

  return True;
}

/******************************************************************
; routine:  FindProjectionPt
;
; description:
;   Each front arc has a spoke that is guaranteed to traverse the
;   arc.  Compute the attachment point from this intersection point
;   on the front arc to the sweep line.
;
; in:
;   theArc : FRONT_ArcType -- the arc whose spoke we will use
;   sweepPostion : Real -- the x-coordinate of the vertical sweepline
;
; out:
;   thePoint : Pt * -- the attachment point on the sweepline
;   returns : Boolean -- True if thePoint can be trusted as a valid result
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

static Boolean 
FindProjectionPt (FRONT_ArcType theArc, Real sweepPosition, Pt *thePoint)
{
  Line     sweepline, shootline;
  Pt       *leftPt, *rightPt;
  Boolean  findOkay = False;

  if (theArc == FRONT_NullArc) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_FindProjection,0,0,0,0);
  } else {

    findOkay = True;

    /* Set up the sweepline */

    sweepline.w = sweepPosition;
    sweepline.x = -1.0;
    sweepline.y = 0.0;

    rightPt = &(RightPoint(theArc->generator));
    leftPt = &(LeftPoint(theArc->generator));

    if (Less(XVal(theArc->spoke.attachment), sweepPosition)) {

      /* The projection point is the intersection of the sweepline and
         any line that goes through the front arc. */

      IntersectionOf(&sweepline, &(theArc->lineToProjectPt), thePoint);
    } else {

      if (Equal(XVal(*rightPt), XVal(*leftPt))) {
  
        /* We have a single point or a vertical line -- the point
           itself can be the image on the sweepline. */

        PointAssign(*thePoint, *leftPt);
      } else {
        /* We actually have a polygon, not just a single point. */

        LineOf(rightPt, leftPt, &shootline);
        IntersectionOf(&sweepline, &shootline, thePoint);
      }
    }
  }

  return findOkay;
}

/******************************************************************
; routine:  ArcCompare
;
; description:
;   Compare the relative position of two front arcs based on the
;   spokes that go through each arc.
;
;   The routine returns
;     a negative value if arc2 is above arc1
;     zero if the spokes for arc1 and arc2 meet the sweepline at the
;          same place
;     a positive value if arc2 is below arc1
;
;   The comparison routine must have valid spokes stored in each
;   front arc.
;
; in:
;   arc1 : FRONT_ArcType -- the first arc in the comparison
;   arc2 : FRONT_ArcType -- the second arc in the comparison
;
; out:
;   returns : SInt16 -- the relationship of arc1 with respect to arc2
;
; history:
;   95.02.05 / M. McAllister / Created
;   96.03.04 / M. McAllister / Take differences in Y value into a float
;                              before finding its sign (else overflow occurs)
*******************************************************************/

static SInt16 
ArcCompare (Ptr arc1, Ptr arc2)
{
  Real           sweepPosition;
  SInt16         compare = 0;
  FRONT_ArcType  theArc1, theArc2;
  Pt             int1, int2;
  Line           separator;
  Real           difference;

  /* Get the parameters into a recognizable data type. */

  theArc1 = (FRONT_ArcType) arc1;
  theArc2 = (FRONT_ArcType) arc2;

  if ((theArc1 == FRONT_NullArc) || (theArc2 == FRONT_NullArc)) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_ArcCompare,
                      (UInt32) arc1, (UInt32) arc2, 0, 0);
  } else {

    sweepPosition = theArc2->myFront->sweepXVal;

    /* Locate the projection points for each arc onto the sweep line. */

    if ((FindProjectionPt (theArc1, sweepPosition, &int1) == True) &&
        (FindProjectionPt (theArc2, sweepPosition, &int2) == True)) {

      /* Figure out which arc is the highest, taking "equality"
         modulo some tolerance. */

      difference = YVal(int2) - YVal(int1);
      compare = Sign(difference);
      if (Zero(compare)) {
        compare = 0;
#ifdef Hack
        if ((theArc1->generator->numPoints > 1) &&
            (theArc2->generator->numPoints > 1)) {
          /* Go for comparing the line from the leftmost point to the
             rightmost point. */

          LineOf(&(LeftPoint(theArc1->generator)),
                 &(RightPoint(theArc1->generator)), &separator);
          if (! OnTheLine(&separator, &(RightPoint(theArc2->generator)))) {
            compare = (LineSide (&separator, &(RightPoint(theArc2->generator)))
                       == LeftSide ? 1 : -1);
          }
        }
#endif
      }

      /* Now that the comparison is done, let the user know that
         we compared some stuff. */

      if (theArc2->myFront->configRoutines.spokeSearchRtn != NULL) {
         (*(theArc2->myFront->configRoutines.spokeSearchRtn))
                 (theArc1->generator, &(theArc1->spoke), &int1, 
                  theArc2->generator, &(theArc2->spoke), &int2, sweepPosition);
      }
    }
  }

  return compare;
}

/******************************************************************
; routine:  GetLineSiteToProjectPt
;
; description:
;   Given a spoke (that presumably crosses a front arc at point p), compute
;   the equation of the line that starts at the attachment point
;   of the spoke and will go through the projection of point p onto the
;   sweep line.  
;
;   It's cute to notice that this line is independent of the position
;   of the sweep line.
;
; in:
;   spokePtr : spokeInfo * -- the spoke leading across the front arc
;
; out:
;   linePtr : Line * -- the equation of the line
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.10.10 / M. McAllister / Handle sweep tangent parallel to spoke.
*******************************************************************/

static void 
GetLineSiteToProjectPt (spokeInfo *spokePtr, Line *linePtr)
{
  Pt      exitPt;
  Line    shootline;
  Vector  sweepTangent;

  getSweeplineTan (&sweepTangent);

  /* Get the line that shoots across the sweepline.  What we do
     is find the line through the convex distance function, from
     the attachment point of the spoke to the tangency point of the
     sweepline.  The line we want is parallel to that one.  Then,
     we translate this line to the desired position.  */

  getExitPoint(&(spokePtr->otherPt), &(spokePtr->attachment), &exitPt);
  LineOf(&sweepTangent, &exitPt, &shootline);

  /* If shootline is all zeroes then the sweep tangent and the spoke
     are parallel.  The spoke itself is the line that we want. */

  if ((shootline.w == 0.0) && (shootline.x == 0.0) && (shootline.y == 0.0)) {
    LineOf (&(spokePtr->attachment), &(spokePtr->otherPt), linePtr);
  } else {
	/* shootline has the correct slope, but it is positioned
	   relative to the distance function centred at 0.  Finish
	   by shifting its y-intercept so the line goes through the
	   spoke's attachment point. */

	/* All parallel lines have equal .x and .y components.
	   We only need to adjust the y-intercept. */

	linePtr->w = (Coordinate) -(spokePtr->attachment.y * shootline.y 
						   + spokePtr->attachment.x * shootline.x);
	linePtr->x = (Coordinate) shootline.x * spokePtr->attachment.w;
	linePtr->y = (Coordinate) shootline.y * spokePtr->attachment.w;
  }
}

/******************************************************************
; routine:  ScheduleVoronoiEvent
;
; description:
;   Given three consecutive front arcs (at least, we assume that
;   they are consecutive), compute the Voronoi vertex corresponding
;   to the three arcs (as if they appeared in the top, middle, bottom
;   counterclockwise order around the vertex).  If that Voronoi vertex
;   is finite then add a corresponding circle event to the schedule and
;   return the spoke from the Voronoi vertex to the middle arc.
;
;   If the Voronoi vertex is infinite, return a spoke extending 
;   horizontally (with respect to the distance function) to the
;   right of the rightmost point of the generator for "middle".
;
; in:
;   top : FRONT_ArcType -- the topmost front arc in the triple of 3 arcs
;   middle : FRONT_ArcType -- the middle front arc in the triple of 3 arcs
;   bottom : FRONT_ArcType -- the lowest front arc in the triple of 3 arcs
;   circles : HEAP_Heap -- the event schedule
;
; out:
;   circles -- an event may be added to the event schedule
;   midSpokePtr : spokeInfo * -- a spoke that is guaranteed to cross
;                        through the "middle" front arc
;   returns : Boolean -- True if the circle event could be scheduled;
;                        False if the Voronoi point could not be
;                        found or the insertion to the schedule failed
;
; history:
;   95.02.05 / M. McAllister / Created
*******************************************************************/

static Boolean 
ScheduleVoronoiEvent (FRONT_ArcType top, FRONT_ArcType middle, 
                      FRONT_ArcType bottom, HEAP_Heap circles, 
                      spokeInfo *midSpokePtr)
{
  Pgon         *first, *second, *third;
  Pt           vorPoint, eventPoint;
  Boolean      success = False;
  HEAP_HeapId  schedKey;
  scheduleInfo *circleEventPtr;

  if ((top == FRONT_NullFront) || (middle == FRONT_NullFront) ||
      (bottom == FRONT_NullFront)) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_ScheduleVoronoi,
                      (UInt32) top, (UInt32) middle, (UInt32) bottom, 0);
  } else {
    /*	Extract the polygons involved in the operation. */

    first  = top->generator;
    second = middle->generator;
    third  = bottom->generator;

    /*	Get the appropriate Voronoi vertex and spokes. */
  
    if ((first != third) && 
        (voronoiVertex(first, second, third, &vorPoint, &eventPoint, 
                       midSpokePtr) == True)) {
  
      /* There was a Voronoi vertex so create a circle event for it. */
  
      circleEventPtr = newSchedule();
      circleEventPtr->whatEvent = EVT_CircleEvent;

      PointAssign(circleEventPtr->eventPt, eventPoint);
      PointAssign(circleEventPtr->eventCentre, vorPoint);

      circleEventPtr->poly[EVT_TopElement]    = first;
      circleEventPtr->poly[EVT_MiddleElement] = second;
      circleEventPtr->poly[EVT_BottomElement] = third;
  
      circleEventPtr->frontArcs[EVT_TopElement]    = top;
      circleEventPtr->frontArcs[EVT_MiddleElement] = middle;
      circleEventPtr->frontArcs[EVT_BottomElement] = bottom;

      /* Copy the spoke over. */

      circleEventPtr->midSpoke.attachPolygon = midSpokePtr->attachPolygon;
      circleEventPtr->midSpoke.attachIndex = midSpokePtr->attachIndex;
      PointAssign(circleEventPtr->midSpoke.attachment, midSpokePtr->attachment);
      PointAssign(circleEventPtr->midSpoke.otherPt, midSpokePtr->otherPt);

      success = HEAP_Add(circles, (Ptr) circleEventPtr, &schedKey);
    } else {
      /* Voronoi vertices at infinity aren't stored in the schedule. */
      schedKey = HEAP_NullHeapId;
      success = True;

      if (first == third) {
        /* the spoke, voronoi point, and event point have not been set-up. */

        midSpokePtr->attachPolygon = second;
        PointAssign(midSpokePtr->attachment, RightPoint(second));

        PointAssign(midSpokePtr->otherPt, RightPoint(second));
        midSpokePtr->otherPt.x += midSpokePtr->otherPt.w;
      }
    }

    top->vorEvents[_FRONT_IAmTopArc]       = schedKey;
    middle->vorEvents[_FRONT_IAmMiddleArc] = schedKey;
    bottom->vorEvents[_FRONT_IAmBottomArc] = schedKey;
  }

  return success;
}

/******************************************************************
; routine:  ScheduleForMiddleArc
;
; description:
;   Try to schedule a circle event for the sweep front where the arc
;   supplied is the middle of three.  The possibilities are:
;     - the arc is the only one in the front -- no scheduling done
;          and the spoke is horizontal (with respect to the distance
;          function)
;     - the arc is the topmost or bottommost -- no scheduling done
;          and the spoke is perpendicular to the outer common
;          tangent to its neighbour on the sweep front
;     - the arc is in the middle of the front -- something to
;          schedule.
;
;   The routine always returns a spoke that will cross the given front
;   arc as well as the line induced by the spoke that projects a point
;   on the front arc onto the sweep line.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front to which the arc belongs.
;   middleArc : FRONT_ArcType -- the arc we want to treat as the middle of 3
;   circles : HEAP_Heap -- the event schedule for circle events
;   merges : HEAP_Heap -- the event schedule for merging site events
;
; out:
;   circles -- may have an event added to it
;   merges -- may have an event added to it
;   midSpokePtr : spokeInfo * -- a spoke guaranteed to cross 
;                    front arc "middleArc"
;   linePtr : Line * -- the projection line induced by midSpokePtr
;   returns : Boolean -- False if either the spoke or line cannot
;                        be trusted or the circle event could not
;                        be computed.
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.03.28 / M. McAllister / Add top and bottom arc parameters so the
;                              node need not be in the tree yet.
;   95.12.13 / M. McAllister / Handle cases where outerCommonTangent
;                              may fail (polygons share a common point)
*******************************************************************/

static Boolean 
ScheduleForMiddleArc (FRONT_FrontType theFront, FRONT_ArcType topArc, 
                      FRONT_ArcType middleArc,
                      FRONT_ArcType bottomArc,
                      HEAP_Heap circles, HEAP_Heap merges, 
                      spokeInfo *midSpokePtr, Line *linePtr)
{
  Pt          start, end, *tanPt;
  Line        tangent, perp;
  int         headIdx, tailIdx;
  Boolean     opsOkay = False;
  Boolean     sitesDistinct = True;

  /* If I have neighbours above and below me then it's a regular
     circle event. */

  if ((topArc == FRONT_NullArc) && (bottomArc == FRONT_NullArc)) {
    opsOkay = True;
  } else {
    if ((topArc != FRONT_NullArc) && (bottomArc != FRONT_NullArc)) {
      opsOkay = ScheduleVoronoiEvent (topArc, middleArc, bottomArc, 
                                      circles, midSpokePtr);
    } else {
      if (middleArc == FRONT_NullArc) {
        AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_ScheduleMiddle, 
                          0, 0, 0, 0);
      } else {

        /* Get the tangent between the middle arc (which is actually
           on one of the ends of the front) and its neighbour. */
  
        if (topArc != FRONT_NullArc) {
          sitesDistinct = 
             outerCommonTangent(middleArc->generator, topArc->generator,
                                &start, &end, &headIdx, &tailIdx);
          tanPt = &start; 
        } else {
          sitesDistinct = 
             outerCommonTangent(bottomArc->generator, middleArc->generator,
                                &start, &end, &headIdx, &tailIdx);
          tanPt = &end; 
        }
  
        PointAssign(midSpokePtr->attachment, *tanPt);

        if (sitesDistinct) {
          /* The away point on for the spoke is along the line perpendicular
             to the tangent and that leads away from the sites. */

          LineOf(&start, &end, &tangent);
          perpendicularLine(tanPt, &tangent, &perp);
  
          awayPoint(&perp, &tangent, &(midSpokePtr->otherPt));
        } else {
          Line  theEdge, perp;
          Pt    *commonPt, *otherPt;
          UInt16 midSize;

          if (topArc != FRONT_NullArc) {
            commonPt = &(middleArc->generator->points[headIdx]);
            midSize = middleArc->generator->numPoints;
            otherPt = &(middleArc->generator->points[
                                     (headIdx - 1 + midSize) % midSize]);
          } else {
            commonPt = &(bottomArc->generator->points[headIdx]);
            otherPt = &(middleArc->generator->points[(tailIdx + 1) % 
                                      middleArc->generator->numPoints]);
          }

          /* Assume no vertical lines for now. */
          LineOf (otherPt, commonPt, &theEdge);
          perpRightTurnLine (commonPt, &theEdge, &perp);
          PointAssign (midSpokePtr->otherPt, *commonPt);
          midSpokePtr->otherPt.x -= midSpokePtr->otherPt.w; /* subtract 1 */
          midSpokePtr->otherPt.y = midSpokePtr->otherPt.w *
                  SolveLineForY (&perp, XVal(*commonPt)-1);
        }

        /* No circle events are scheduled when we are going with the 
           outer common tangents. */

        middleArc->vorEvents[_FRONT_IAmMiddleArc] = HEAP_NullHeapId;
        if (topArc != FRONT_NullArc) {
          topArc->vorEvents[_FRONT_IAmTopArc] = HEAP_NullHeapId;
        }
        if (bottomArc != FRONT_NullArc) {
          bottomArc->vorEvents[_FRONT_IAmBottomArc] = HEAP_NullHeapId;
        }

        opsOkay = True;
      }
    }
  }

  /* Derive the last return parameter from the spoke that we computed. */

  if (opsOkay == True) {
    GetLineSiteToProjectPt (midSpokePtr, linePtr);
  }

  return opsOkay;
}

/******************************************************************
; routine:  NewArcEvents
;
; description:
;   A new front arc has appeared on the sweep front.  Delete
;   circle events where its predecessor and successor in the sweep
;   front were adjacent and then schedule all new circle events
;   that involve the new front arc.
;
; in:
;   theFront : FRONT_FrontType -- the sweep front with the new arc
;   newArc : FRONT_ArcType -- the new kid on the block
;   circles : HEAP_Heap -- the schedule of circle events
;   merges : HEAP_Heap -- the schedule of merging site events
;
; out:
;   circles -- may have events added or deleted.
;   merges -- may have events added or deleted.
;   returns : Boolean -- True if all additions and deletions went
;                        according to plan.  False if the scheduling
;                        went awry and things can't be trusted anymore
;
; history:
;   95.02.05 / M. McAllister / Created
;   95.03.28 / M. McAllister / Add upper and lower arc parameters so the
;                              node need not be in the tree yet.
;   95.10.27 / M. McAllister / Use RBTREE next and previous data functions
;   96.03.29 / M. McAllister / Free schedule items when taken out of the heap
*******************************************************************/

static Boolean 
NewArcEvents (FRONT_FrontType theFront, FRONT_ArcType upperArc, 
              FRONT_ArcType newArc, FRONT_ArcType lowerArc,
              HEAP_Heap circles, HEAP_Heap merges, Boolean lowerInFront)
{
  Boolean          success = False;
  scheduleInfo     *circleEventPtr;

  if (theFront == FRONT_NullFront) {
    AL_SoftwareAlarm (AL_Id_FRONT_NullFront, AL_Fn_FRONT_NewArcEvents,0,0,0,0);
  } else {
    if (newArc == FRONT_NullArc) {
      AL_SoftwareAlarm (AL_Id_FRONT_NullArc, AL_Fn_FRONT_NewArcEvents,0,0,0,0);
    } else {
      if (newArc->myFront != theFront) {
        AL_SoftwareAlarm (AL_Id_FRONT_ArcInWrongFront, AL_Fn_FRONT_NewArcEvents,
                          (UInt32) newArc, (UInt32) theFront, 0, 0);
      } else {

		/* Get rid of old circle events that are no longer valid */

        circleEventPtr = NULL;
		if ((upperArc == NULL) ||
			(upperArc->vorEvents[_FRONT_IAmMiddleArc] == HEAP_NullHeapId) ||
			(HEAP_PopNamed(circles, upperArc->vorEvents[_FRONT_IAmMiddleArc],
						   (Ptr *)&circleEventPtr) == True)) {
          if (circleEventPtr != NULL) {
            freeSchedule(&circleEventPtr);
            circleEventPtr = NULL;
          }

		  if ((lowerArc == NULL) ||
			  (lowerArc->vorEvents[_FRONT_IAmMiddleArc] == HEAP_NullHeapId) ||
			  (HEAP_PopNamed(circles, lowerArc->vorEvents[_FRONT_IAmMiddleArc],
							 (Ptr *)&circleEventPtr) == True)) {

            if (circleEventPtr != NULL) {
              freeSchedule(&circleEventPtr);
            }

			/* Schedule events for when each of upperArc, lowerArc, and
			   parameter newArc are each the middle arc.  The called
			   routine should also set-up spokes for each arc when it is
			   in the middle. */

			if ((upperArc == NULL) || 
				(ScheduleForMiddleArc (theFront, (FRONT_ArcType) 
                    RBTREE_PreviousData (theFront->balancedTree,
                    upperArc->treeNode), upperArc, newArc, circles, merges,
					&(upperArc->spoke), &(upperArc->lineToProjectPt)) == True)){
			  if (ScheduleForMiddleArc (theFront, upperArc, newArc, lowerArc,
                circles, merges, &(newArc->spoke), 
                &(newArc->lineToProjectPt)) == True){
				if (lowerArc == NULL) {
				  success = True;
				} else {
				  success = ScheduleForMiddleArc (theFront, newArc, lowerArc, 
                               (FRONT_ArcType) RBTREE_NextData (
                               theFront->balancedTree,
                               (lowerInFront == True ? 
                                     lowerArc->treeNode : upperArc->treeNode)),
                               circles, merges, &(lowerArc->spoke), 
                               &(lowerArc->lineToProjectPt));
				}
			  }
			}
		  }
		}
      } /* check arc belongs to front */
    } /* check arc is not null */
  } /* check front is not null */

  return success;
}


static Real 
GetPgonValueInRange (Pgon *poly, UInt16 startIdx, 
                     UInt16 endIdx, Real matchX)
{
  Real    yValue = 0.0;
  UInt16  idx, leftIdx, rightIdx;
  Line    theLine;

  if (startIdx == endIdx) {
    yValue = YVal(poly->points[startIdx]);
  } else {
    /* Have to do a binary search. */

    if (startIdx > endIdx) {
      endIdx += poly->numPoints;
    }

    if (XVal(poly->points[startIdx]) < matchX) {
      leftIdx = startIdx;
      rightIdx = endIdx;
    } else {
      leftIdx = endIdx;
      rightIdx = startIdx;
    }

    while (MyAbs(leftIdx - rightIdx) > 1) {
      idx = (leftIdx + rightIdx) / 2;
      if (XVal(poly->points[idx % poly->numPoints]) < matchX) {
        leftIdx = idx;
      } else {
        rightIdx = idx;
      }
    }

    /* The line from leftIdx to rightIdx spans the matchX value.
       Extrapolate this segment to a full line and get the
       corresponding Y value from the line. */

    LineOf (&(poly->points[leftIdx % poly->numPoints]), 
            &(poly->points[rightIdx % poly->numPoints]), &theLine);
    yValue = SolveLineForY (&theLine, matchX);
  }

  return yValue;
}


