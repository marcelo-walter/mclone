
#ifndef POLYGON_DEFS

#define POLYGON_DEFS

#include "geometry.h"

typedef struct {
  int		numPoints;
  int		leftmost, rightmost;
  int		upper, lower;
  Pt		*points;
  int		voronoiList[50];
  int		voronoiCount;

  int     ccwStartIdx;
  Pt      normAtCcwStart;
  Ptr     origin;
}	Pgon;

#define LeftPoint(A) ((A)->points[(A)->leftmost])
#define RightPoint(A) ((A)->points[(A)->rightmost])

#ifdef __cplusplus
extern "C" {
#endif

Pgon *newPolygon(int	numPoints, Pt *vertices);
void killPolygon(Pgon **polygon);
void nearestPoints (Pgon *p, Pgon *q, Pt *ppt, Pt *qpt, int *pidx, int *qidx);

Boolean polygonsShareVtx (Pgon *upperPgon, Pgon *lowerPgon,
                          UInt16 *upIdx, UInt16 *lowIdx);
 
/*	These routines are just for printing the polygons */

void printPoly(int colour, Pgon *polygon);

#ifdef __cplusplus
}
#endif

#endif

