
#ifndef GEOMETRY_DEF

#define GEOMETRY_DEF

#include "globals.h"

#define GEOM_EPSILON 1.0e-13
#define PointPrec	1.0e-6
#define MyAbs(x) ( (x) >= 0 ? (x) : -(x))
#define Zero(x) (MyAbs(x) < GEOM_EPSILON)
#define Greater(A,B) ( ((A)-(B)) > GEOM_EPSILON)
#define Less(A,B) ( ((A)-(B)) < -GEOM_EPSILON)
#define Equal(A,B) Zero((A)-(B))
#define SignOfaLessb(A,B) (Zero((A)-(B)) ? 0 : ((A) > (B) ? 1 : -1))
#define Sign(A) (Zero(A) ? 0 : ((A) < 0 ? -1 : 1))

#define Coordinate	Real
#define RoundPoint(A)	{ \
		(A).x = (Coordinate)((float)(XVal(A))); \
		(A).y = (Coordinate)((float)(YVal(A))); \
		(A).w = 1.0; \
	}

typedef struct {
	Coordinate	w, x, y, z;
	}	Pt;

typedef Pt Line;
typedef Pt Vector;

typedef struct {
	Pt		centre, focus;
	Real	focalLength;
	Real	dirSin, dirCos;
	int		sqCoeff;
	Real	scale, offset;
	Line	directrix;
	Pt		scalePt[2];
	}	Parabola;

typedef enum {GEOM_CW, GEOM_CCW} GEOM_DirectionType;

#define CrossProd1(A,B) ((A)->x * (B)->y - (A)->y * (B)->x)
#define CrossProd2(A,B) ((A)->y * (B)->w - (A)->w * (B)->y)
#define CrossProd3(A,B) ((A)->w * (B)->x - (A)->x * (B)->w)

#define CrossProd(A,B,C) \
	(C)->w = CrossProd1((A),(B)); \
	(C)->x = CrossProd2((A),(B)); \
	(C)->y = CrossProd3((A),(B)); 

#define DotProd(A,B)	((A)->w * (B)->w + (A)->x * (B)->x + (A)->y * (B)->y)

#define Det3(A,B,C)		((A)->w * ((B)->x*(C)->y - (B)->y*(C)->x) - \
						 (A)->x * ((B)->w*(C)->y - (B)->y*(C)->w) + \
						 (A)->y * ((B)->w*(C)->x - (B)->x*(C)->w))
#define LeftSide 1
#define RightSide -1
#define LineSide(ln,pt) (Less(DotProd(ln,pt), 0) ? RightSide : LeftSide)
#define OnTheLine(ln,pt) (Zero(DotProd(ln,pt)) ? True : False)

#define PointAssign(A,B) \
	(A).w = (B).w; \
	(A).x = (B).x; \
	(A).y = (B).y; \
	(A).z = (B).z; 

#define PointAssignPtr(A,B) \
	(A)->w = (B)->w; \
	(A)->x = (B)->x; \
	(A)->y = (B)->y; \
	(A)->z = (B)->z; 

#define MidPoint(A,B,C) \
	(C).w = (A).w * (B).w * 2; \
	(C).x = (A).x * (B).w + (A).w * (B).x; \
	(C).y = (A).y * (B).w + (A).w * (B).y; \
	(C).z = (A).z * (B).w + (A).w * (B).z; 

#define MidPointPtr(A,B,C) \
	(C)->w = (A)->w * (B)->w * 2; \
	(C)->x = (A)->x * (B)->w + (A)->w * (B)->x; \
	(C)->y = (A)->y * (B)->w + (A)->w * (B)->y; \
	(C)->z = (A)->z * (B)->w + (A)->w * (B)->z; 

#define AddPoints(A,B,C) \
	(C).w = (A).w * (B).w;\
	(C).x = (A).x * (B).w + (A).w * (B).x;\
	(C).y = (A).y * (B).w + (A).w * (B).y;\
	(C).z = (A).z * (B).w + (A).w * (B).z;
	
#define SubPoints(A,B,C) \
	(C).w = (A).w * (B).w;\
	(C).x = (A).x * (B).w - (A).w * (B).x;\
	(C).y = (A).y * (B).w - (A).w * (B).y;\
	(C).z = (A).z * (B).w - (A).w * (B).z;

#define ScaleVector(Vector, Scale) \
	(Vector).x *= Scale;\
	(Vector).y *= Scale;

#define LineSlope(A) ((A).x / (A).y * -1)
#define LineSlopePtr(A) ((A)->x / (A)->y * -1)

#define LineOf(From,To,Ln) CrossProd(From,To,Ln)
#define IntersectionOf(A,B,C) CrossProd(A,B,C)
#define TranslateLine(Ln, Pt) \
			(Ln)->w = ((Ln)->x * (Pt)->x + (Ln)->y * (Pt)->y) * -1; \
			(Ln)->x = (Ln)->x * (Pt)->w; \
			(Ln)->y = (Ln)->y * (Pt)->w;

#define XVal(A) ((A).x / (A).w)
#define YVal(A) ((A).y / (A).w)
#define ZVal(A) ((A).z / (A).w)

#define XValPtr(A) ((A)->x / (A)->w)
#define YValPtr(A) ((A)->y / (A)->w)
#define ZValPtr(A) ((A)->z / (A)->w)

#ifdef __cplusplus
extern "C" {
#endif

#define SolveLineForY(Ln, X) ((-1*((Ln)->w + (Ln)->x * (X))/(Ln)->y))

#define PointAtInfinity(A)	((A).w == 0 ? True : False)
#define SamePoint(A,B) (Zero(XValPtr(A)-XValPtr(B)) && \
						Zero(YValPtr(A)-YValPtr(B)))

Boolean pastSegmentBounds(Pt *point, Pt *start, Pt *end, int *closerEnd);
void perpendicularLine(Pt *point, Line *line, Line *perpenducular);
void perpRightTurnLine (Pt *point, Line *line, Line *perp);
void ptNearestLine(Pt *point, Line *line, Pt *nearest);
void ptNearestSegment(Pt *point, Pt *start, Pt *end, Pt *nearest);
void createParabola(Pt *focus, Line *directrix, Parabola *para);
void intersectLineParabola(Line *line, Parabola *para, Pt *point1, Pt *point2);
Real parabolaParam(Parabola *para, Pt *pt);

void awayPoint(Line *driveLine, Line *testLine, Pt *testPt);


#ifdef __cplusplus
}
#endif

#endif

