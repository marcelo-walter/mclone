
#ifndef _voronoi_h_
#define _voronoi_h_

#include "geometry.h"
#include "polygon.h"
#include "sweepDefs.h"

typedef struct {
	Pt	attachment, otherPt;
	Pgon *attachPolygon;
	int	attachIndex;
	}	spokeInfo;

#define NormalVoronoi	1
#define InfiniteVoronoi	0

Boolean voronoiVertex(Pgon *a, Pgon *b, Pgon *c, Pt *vorPoint, Pt
	*eventPoint, spokeInfo *middleSpoke);

void ptNearestPgon (Pt *point, Pgon *poly, Pt *nearest);

void findSpoke(Pt *origin, Pgon *object, spokeInfo *spoke);
Boolean pointsCCW(Pt *a, Pt *b, Pt *c);

Boolean objectsOnHull(Pt *pt1, Pt *pt21, Pt *pt22, Pt *pt3, Pt *vorPt, 
                      Pt *eventPt, spokeInfo *spoke);

void getEventPoint (Pt *vorPoint, Pt *attach, Pt *eventPt);

#endif /* _voronoi_h_ */

