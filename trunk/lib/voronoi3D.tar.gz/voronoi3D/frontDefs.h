
#ifndef _frontDefs_h_
#define _frontDefs_h_

#include "globals.h"
#include "heap.h"
#include "polygon.h"
#include "rbtree.h"
#include "voronoi.h"

#ifdef paranoid
#define _FRONT_HeadTag GLBL_Tag('f', 'r', 'n', 'S')
#define _FRONT_TailTag GLBL_Tag('f', 'r', 'n', 'E')

#define _FRONT_ArcHeadTag GLBL_Tag('a', 'r', 'c', 'S')
#define _FRONT_ArcTailTag GLBL_Tag('a', 'r', 'c', 'E')
#endif

typedef enum {
      _FRONT_Empty
    , _FRONT_FirstSites
    , _FRONT_MovingFront
  } _FRONT_LoadStatusType;

typedef struct {
  void (*spokeSearchRtn)(Pgon *pgon1, spokeInfo *spoke1, Pt *onSweepPt1,
                         Pgon *pgon2, spokeInfo *spoke2, Pt *onSweepPt2,
                         Real sweepPosition);
  void (*vorVtxSearchRtn)(Pgon *pgon1, Pgon *pgon2, Real sweepPosition, 
                          Pt *computedVoronoiPoint);
  } FRONT_UserRoutineType;

typedef struct {
#ifdef paranoid
  UInt32                 headGuard;
#endif
  RBTREE_TreeType        balancedTree;
  FRONT_UserRoutineType  configRoutines;
  _FRONT_LoadStatusType  loadStage;
  Real                   sweepXVal;
#ifdef paranoid
  UInt32                 tailGuard;
#endif
  } _FRONT_FrontInfoType;

/* Index values for the field vorEvents in the FRONT_FrontArcInfoTYpe
   structure */

#define _FRONT_IAmTopArc    (0)
#define _FRONT_IAmMiddleArc (1)
#define _FRONT_IAmBottomArc (2)

typedef struct _FRONT_ArcInfoType {
#ifdef paranoid
  UInt32                      headGuard;
#endif
  _FRONT_FrontInfoType        *myFront;
  RBTREE_NodeType             treeNode;
  HEAP_HeapId                 vorEvents[3];
  HEAP_HeapId                 mergeEvent;  /* merges with the arc below.  */
  struct _FRONT_ArcInfoType   *prevArc;
  struct _FRONT_ArcInfoType   *nextArc;
  Pgon                        *generator;
  spokeInfo                   spoke;
  Line                        lineToProjectPt;
  Ptr                         dataPtr;
#ifdef paranoid
  UInt32                      tailGuard;
#endif
  } _FRONT_ArcInfoType;

#endif
	
