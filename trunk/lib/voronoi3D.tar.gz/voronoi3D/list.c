/*                                                                         
 * NAME    : TIN VAN NGUYEN                                                 
 * DATE    : July 13, 1995    
 * FILENAME: LIST.C
 * PROJECT : THE MEDIAL AXIS OF A N-SIMPLE POLYGON                          
 * PAPER   : This is an implementation of D.T. Lee's paper of the same      
 *           title published in IEEE Transactions on Pattern Analysis 
 *           and Machine Intelligence, Vol. PAMI-4, NO. 4, July 1982.
 *           
 *   This source file contains all necessary subroutines. 
 */

#include "tin.main.h"
#include <stdlib.h>

eleType *Emalloc()

/* allocates memory for a new element, returns address */
{
  eleType *temp = (eleType *) malloc(sizeof(eleType));
  if (temp != NULL)
    {
      ELEMENT_NEXT(temp) = NULL;
      ELEMENT_PRE(temp) = NULL;
      ELEMENT_VOHEAD(temp) = NULL;
      ELEMENT_VOTAIL(temp) = NULL;
      return temp;
    }
  else
    {
      printf ("Fail to allocate memory for a new element\n");
      exit(-1);
    }
}

/*-----------------------------------------------------------------*/

chType *Cmalloc()

/* allocates memory for a new chain, returns address */
{
  chType *temp = (chType *) malloc(sizeof(chType));
  if (temp != NULL) CHAIN_NEXT(temp) = NULL;
  else
    {
      printf ("Fail to allocate memory for a new chain\n");
      exit(-1);
    };
  
return temp;
}

/*-----------------------------------------------------------------*/

voType *Vmalloc()

/* allocates memory for a new voronoi edge, returns address 
 * preassumes this is a normal edge  
 */
{
  voType *temp = (voType *) malloc(sizeof(voType));
  if (temp != NULL) 
    {
      VORONOI_PRE(temp)  = NULL;
      VORONOI_NEXT(temp) = NULL;
      VORONOI_MODE(temp) = 0; 
      VORONOI_NEIGHBOR(temp) = 0;
      VORONOI_START(temp)[X] = VORONOI_START(temp)[Y] = 0.0;
      VORONOI_END(temp)[X] = VORONOI_END(temp)[Y] = 0.0;
      VORONOI_START(temp)[W] = VORONOI_END(temp)[W] = 0.0;
      return temp;
   }
  else
    {
      printf ("Fail to allocate memory for a new voronoi edge\n");
      exit(-1);
    }
}

/*-----------------------------------------------------------------*/

void Vfree(voType *v)

/* frees the list of allocated Voronoi edgess that v points to */
{
  voType *late, *cur = v;
  
  if (v == NULL) return;
  else late = VORONOI_NEXT(v);
  
  while (late != NULL)
    {
      free(cur);
      cur = late;
      late = VORONOI_NEXT(late);
    };

  free(cur);
}

/*-----------------------------------------------------------------*/

void Efree(eleType *e)

/* frees the list of allocated elements that e points to 
 * also frees lists of Voronoi edges in each element.
 */
{
  eleType *late, *cur = e;
  
  late = ELEMENT_NEXT(e);
  
  while (late != NULL)
    {
      Vfree(ELEMENT_VOHEAD(cur));
      free(cur);
      cur = late;
      late = ELEMENT_NEXT(late);
    };

  free(cur);
}
 
/*-----------------------------------------------------------------*/

void Cfree(chType *c)

/* frees the list of allocated chains that e points to */
{
  chType *late, *cur = c;
  
  late = CHAIN_NEXT(c);
  
  while (late != NULL)
    {
      free(cur);
      cur = late;
      late = CHAIN_NEXT(late);
    };

  free(cur);
}

/*-----------------------------------------------------------------*/

eleType *Eappend(eleType *i, eleType *j)

/* appends 2 lists of elements:: j's to the end of i's */
{
  eleType *tail = i;  /* points to the last element of i's list */
  if (i == NULL) return j;
  if (j == NULL) return i;
  while (ELEMENT_NEXT(tail) != NULL) tail = ELEMENT_NEXT(tail);

  ELEMENT_PRE(j) = tail;
  ELEMENT_NEXT(tail) = j;
  return i;
}
/*-----------------------------------------------------------------*/

chType *Cappend(chType *i, chType *j)

/* appends 2 list of chains:: j's to the end of i's */
{
  chType *tail = i;  /* points to the last element of i's list */
  
  if (tail == NULL) return j;
  while (CHAIN_NEXT(tail) != NULL) tail = CHAIN_NEXT(tail);

  CHAIN_NEXT(tail) = j;
  return i;
}
/*-----------------------------------------------------------------*/

voType *Vappend(voType *i, voType *j)

/* appends 2 lists of Voronoi edges:: j's to the end of i's */
{
  voType *tail = i;  /* points to the last element of i's list */
  
  if (i == NULL) return j;
  if (j == NULL) return i;
  while (VORONOI_NEXT(tail) != NULL) tail = VORONOI_NEXT(tail);

  VORONOI_PRE(j) = tail;
  VORONOI_NEXT(tail) = j;
  return i;
}

/*-----------------------------------------------------------------*/

void EQUATE_POINT(pType a, pType b)
{
  int i;
  for (i = X; i <= W; i++) a[i] = b[i];
}

/*----------------------------------------------------------------*/

int inside(pType start, pType end, pType test)
     
/* returns TRUE if the perpendicular image of 'test' on the line
 * defined by 'start' and 'end' falls between these points.
 */
{
  coType anpha, beta;

  if ((start[W] == 0.0) && (end[W] == 0.0)) return TRUE;
  
  anpha = end[X] - start[X];
  beta  = end[Y] - start[Y];

  if ((anpha*(start[X] - test[X]) + beta*(start[Y] - test[Y]))
      *(anpha*(end[X] - test[X]) + beta*(end[Y] - test[Y])) <= 0)
    return TRUE;
  else
    {
      if ((start[W] != 0.0) && (end[W] != 0.0))  return FALSE;
      else 
	{
	  coType minus = sDistance(test, start) - sDistance(test, end);

	  if (start[W] == 0.0)
	    {
	      if (minus < 0.0) return TRUE;
	      else return FALSE;
	    }
	  if (end[W] == 0.0)
	    {
	      if (minus < 0.0) return FALSE;
	      else return TRUE;
	    }
	}
    }

  /* All of the branches of the "if" clauses have a return to them.
     so if we make it here then we're really toast. */

  return FALSE;
}

/*----------------------------------------------------------------*/

coType sDistance (pType one, pType two)

/* returns square of the distance between 'one' and 'two', ignoring whether
 * the points are infinity or not.
 */
{
  return ((one[X] - two[X])*(one[X] - two[X]) 
	  + (one[Y] - two[Y])*(one[Y] - two[Y]));
}

/*------------------------- VORONOISEGMENT ----------------------------*/

void voronoiSegment(pType start, pType end, pType first, pType last)

/* constructs CCW-half Voronoi Diagram for a directed line segment */
{
  coType a, b, slope;

  first[W] = last[W] = 0.0; /* Infinite points */

  a = end[X] - start[X];
  b = end[Y] - start[Y];

  if (b == 0.0) /* Horizontal segment */
    {
      if (a < 0) /* segment points LEFT => V-D points downward */
	first[Y] = last[Y] = end[Y] - 10.0;
      else       /* segment points RIGHT => V-D points upward */ 
	first[Y] = last[Y] = end[Y] + 10.0;
  
      first[X] = end[X];
      last[X] = start[X];
    }
  else
    {
      if (b < 0.0) /* segment points DOWN => V-D points RIGHT */
	{
	  first[X] = end[X] + 10.0;
	  last[X] = start[X] + 10.0;
	}
      else  /* segment points UP => V-D points LEFT */
	{
	  first[X] = end[X] - 10.0;
	  last[X] = start[X] - 10.0;
	};

      slope = -a/b;

      first[Y] = slope*(first[X] - end[X]) + end[Y];
      last[Y] = slope*(last[X] - start[X]) + start[Y];
    }
}


/******************************************************************/
/*                 THIS IS THE END OF LIST.C                      */
/******************************************************************/








