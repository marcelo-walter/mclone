
#ifndef _globals_h_
#define _globals_h_

/* When doing paranoid checking of parameters, it subsumes that the
   paranoid data structures are enabled. */

#ifdef paranoidCheck
#ifndef paranoid
#define paranoid
#endif
#endif

/* Make sure that the NULL pointer is always defined. */

#ifndef NULL
#define NULL 0
#endif

#ifndef bool_defined
typedef enum {False, True} Boolean;
#define bool_defined
#endif
#define boolean Boolean  /* Eventually, everybody will be Boolean */
#define Real    double   /* temporary definition */

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

typedef void *Ptr;

/* Change from Michael's original code */
#ifdef BUS64
typedef long long     UInt32;
#else
typedef unsigned int UInt32;
#endif

typedef int            SInt32;
typedef unsigned short UInt16;
typedef short          SInt16;
typedef unsigned char  UInt8;
typedef char           SInt8;

typedef char           Byte;
typedef short          Word;
typedef long           LongWord;

typedef char           Char;

#define Min(A,B) ((A)<(B) ? (A) : (B))
#define Max(A,B) ((A)>(B) ? (A) : (B))

#define GLBL_Tag(A,B,C,D) ((((A) & 0xFF) << 24 ) | \
                           (((B) & 0xFF) << 16 ) | \
                           (((C) & 0xFF) <<  8 ) | \
                           (((D) & 0xFF)))

#endif

