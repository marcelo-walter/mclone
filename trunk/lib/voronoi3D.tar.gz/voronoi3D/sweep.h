
#ifndef _sweep_h_

#define _sweep_h_

#include "globals.h"
#include "clist.h"
#include "polygon.h"
#include "heap.h"
#include "front.h"
#include "sweepDefs.h"

typedef struct {
  Ptr  (*foundVorVtxRtn)(Pt *voronoiPoint, SWP_VoronoiVertexType type, Ptr context);
  void (*vorVtxForSiteRtn)(Pgon *theSite, Ptr vorVertexRef, Ptr context);
  void (*siteForVorVtxRtn)(Ptr vorVertexRef, Pgon *theSite, Ptr context);
  void (*convexHullRtn)(Pgon *theSite, Ptr context);
  void (*startSiteEventRtn)(Pgon *theSite, Real sweepXValue,
                            FRONT_FrontType theFront);
  void (*startCircleEventRtn)(Pt *theVoronoiPoint, Real sweepXValue,
                              FRONT_FrontType theFront);
  void (*sweepRtn)(FRONT_FrontType theFront, Real previousSweepXValue,
                   Real nextSweepXValue);
  void (*spokeSearchRtn)(Pgon *pgon1, spokeInfo *spoke1, Pt *onSweepPt1,
                         Pgon *pgon2, spokeInfo *spoke2, Pt *onSweepPt2,
                         Real sweepPosition);
  void (*vorVtxSearchRtn)(Pgon *pgon1, Pgon *pgon2, Real sweepPosition,
                          Pt *computedVoronoiPoint);
  Ptr  contextPtr;
  } SWP_UserRoutinesType;

typedef struct {
  CLIST_NodeType reference;
  CLIST_NodeType top;
  CLIST_NodeType bottom;
  Pgon           *generator;
  } _SWP_SiteOrderType;

typedef struct {
  Ptr                  infinitePointId;
  SWP_UserRoutinesType *routinePtrs;
  HEAP_Heap            circleEvents;
  FRONT_FrontType      theFront;
  } _SWP_InfiniteArcInfoType;

typedef struct {
  Ptr  voronoiVertexRef;
  void (*siteForVorVtxRtn)(Ptr vorVertexRef, Pgon *theSite);
  Ptr  contextPtr;
  } _SWP_VorVtxNotifyInfoType;

#ifdef __cplusplus
extern "C" {
#endif

Boolean SWP_FindVoronoiVertices(UInt16 numPolygons, Pgon **pgonArray,
                                SWP_UserRoutinesType *routinePtr);

#ifdef __cplusplus
}
#endif

#endif

