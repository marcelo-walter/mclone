
/******************************************************************
; Module:  Red-Black Trees
;
; description:
;   This module contains the private definitions for the red-black
;   tree module.  These definitions are not accessible outside
;   the red-black tree code.
;
; history:
;   94.12.02 / M. McAllister / Created
;   95.10.23 / M. McAllister / Added subtreeSize field to tree nodes
*******************************************************************/

#ifndef _rbtreeDefs_h_ 
#define _rbtreeDefs_h_ 

#include "globals.h"

#define _RBTREE_MaxNameSize  (10)

#define _RBTREE_TreeHeadTag GLBL_Tag('r', 'b', 'T', 's')
#define _RBTREE_TreeTailTag GLBL_Tag('r', 'b', 'T', 'e')

#define _RBTREE_NodeHeadTag GLBL_Tag('r', 'b', 'N', 's')
#define _RBTREE_NodeTailTag GLBL_Tag('r', 'b', 'N', 'e')


typedef enum {
     _RBTREE_Black
    ,_RBTREE_Red
  } _RBTREE_ColourType;

typedef UInt16 SemaphoreType;

/********************************************************************
;  The structure for each node of the red-black tree. 
*********************************************************************/

typedef struct _RBTREE_NodeInfoType {
#ifdef paranoid
  UInt32                      headGuard;      /* A memory guard. */
#endif

  /* The basic fields needed for the red-black tree */

  _RBTREE_ColourType          colour;         /* The colour of the node */
  struct _RBTREE_NodeInfoType *parentPtr;     /* The node's parent */
  struct _RBTREE_NodeInfoType *leftPtr;       /* The left child */
  struct _RBTREE_NodeInfoType *rightPtr;      /* The right child */
  UInt32                      subtreeSize;

  /* Fields for sanity-checking in the routines. */

  struct _RBTREE_TreeInfoType *parentTreePtr; /* The tree to which the 
                                                 node belongs */

  /* Fields so that the tree can actually store information. */

  Ptr                         dataPtr;        /* The data stored in the node */

#ifdef paranoid
  UInt32                      tailGuard;      /* A memory guard. */
#endif
} _RBTREE_NodeInfoType;


/********************************************************************
;  The structure that contains the head of the tree and all control
;  information for the tree. 
*********************************************************************/

typedef struct _RBTREE_TreeInfoType {
#ifdef paranoid
  UInt32               headGuard;      /* A memory guard. */
#endif

  /* Fields that provide the basic functions (with sentinels) for the
     red-black tree. */

  _RBTREE_NodeInfoType *head;          /* A dummy head for the tree */
  _RBTREE_NodeInfoType *nilNode;       /* The representative NULL node
                                          for the tree */
  SInt16               (*compareRoutine)(Ptr key1, Ptr key2);

  /* Fields for sanity-checking and debugging the routines. */

  UInt32               count;          /* The number of nodes in the tree */
  Char                 name[_RBTREE_MaxNameSize];  /* tree name for debugging */

#ifdef paranoid
  SemaphoreType        treeLock;       /* A counting semaphore for single 
                                            modifier access */
  UInt32               tailGuard;      /* A memory guard. */
#endif
} _RBTREE_TreeInfoType;

#endif

