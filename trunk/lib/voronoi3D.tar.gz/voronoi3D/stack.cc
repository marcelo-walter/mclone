
// A stack template


#include "memRoutines.h"
#include "Point.h"
#include "line_seg_ops.h"
#include "stack.h"


#if 0
template<class T>
inline void 
stack_push(T*& stack, T element)
{
  if (stack == NULL) {
    stack = Prealloc_Array( T, 10 );
  }
  stack = Grow_Array(T, 1, stack );
  stack[Size_Array(stack)-1] = element;
}

template<class T>
inline T 
stack_pop(T*& stack) 
{				/* assumes non-empty stack */
  Int32_t sp = Size_Array(stack);
  T element = stack[--sp];
  stack = Realloc_Array(T, sp, stack);
  return element;
}
#else
void 
int_stack_push(Int32_t*& stack, Int32_t element)
{
  if (stack == NULL) {
    stack = Prealloc_Array( Int32_t, 10 );
  }
  stack = Grow_Array(Int32_t, 1, stack );
  stack[Size_Array(stack)-1] = element;
}

Int32_t 
int_stack_pop(Int32_t*& stack) 
{				/* assumes non-empty stack */
  Int32_t sp = Size_Array(stack);
  Int32_t element = stack[--sp];
  stack = Realloc_Array(Int32_t, sp, stack);
  return element;
}

void 
point_stack_push(Point*& stack, Point element)
{
  if (stack == NULL) {
    stack = Prealloc_Array( Point, 10 );
  }
  stack = Grow_Array(Point, 1, stack );
  stack[Size_Array(stack)-1] = element;
}

Point 
point_stack_pop(Point*& stack) 
{				/* assumes non-empty stack */
  Int32_t sp = Size_Array(stack);
  Point element = stack[--sp];
  stack = Realloc_Array(Point, sp, stack);
  return element;
}

void 
line_stack_push(LineSegment2D*& stack, LineSegment2D element)
{
  if (stack == NULL) {
    stack = Prealloc_Array( LineSegment2D, 10 );
  }
  stack = Grow_Array(LineSegment2D, 1, stack );
  stack[Size_Array(stack)-1] = element;
}

LineSegment2D 
line_stack_pop(LineSegment2D*& stack) 
{				/* assumes non-empty stack */
  Int32_t sp = Size_Array(stack);
  LineSegment2D element = stack[--sp];
  stack = Realloc_Array(LineSegment2D, sp, stack);
  return element;
}
#endif


